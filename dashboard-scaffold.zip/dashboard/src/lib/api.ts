import type {
  ApiResponse,
  SwarmStatus,
  Agent,
  AgentDetail,
  WalletInfo,
  PnLData,
  Analytics,
  TradeResult,
  TradeEntry,
  Template,
  TradingStrategy,
  HealthReport,
  SupplyDistribution,
  TimelineEvent,
  SwarmConfig,
  Session,
  FundingTarget,
} from '@/types';

const BASE_URL = '/api';

// ─── Core Fetch Wrapper ──────────────────────────────────────

async function apiFetch<T>(
  path: string,
  options?: RequestInit,
): Promise<T> {
  const url = `${BASE_URL}${path}`;
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    throw new ApiError(
      (body as { error?: string }).error ?? `HTTP ${res.status}`,
      res.status,
    );
  }

  const envelope = (await res.json()) as ApiResponse<T>;
  if (!envelope.success) {
    throw new ApiError(envelope.error ?? 'Unknown API error', res.status);
  }

  return envelope.data;
}

async function apiPost<T>(path: string, body?: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: 'POST',
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
}

async function apiPut<T>(path: string, body: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: 'PUT',
    body: JSON.stringify(body),
  });
}

async function apiPatch<T>(path: string, body: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: 'PATCH',
    body: JSON.stringify(body),
  });
}

async function apiDelete<T>(path: string): Promise<T> {
  return apiFetch<T>(path, { method: 'DELETE' });
}

// ─── Error Class ─────────────────────────────────────────────

export class ApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

// ─── Swarm Control ───────────────────────────────────────────

export async function getSwarmStatus(): Promise<SwarmStatus> {
  return apiFetch<SwarmStatus>('/status');
}

export async function pauseSwarm(): Promise<void> {
  await apiPost('/actions/pause');
}

export async function resumeSwarm(): Promise<void> {
  await apiPost('/actions/resume');
}

export async function triggerExit(): Promise<void> {
  await apiPost('/actions/exit');
}

export async function emergencyStop(): Promise<void> {
  await apiPost('/actions/emergency-stop');
}

export async function startSwarm(config: Partial<SwarmConfig>): Promise<void> {
  await apiPost('/swarm/start', config);
}

export async function updateSwarmStrategy(
  strategy: Partial<TradingStrategy>,
): Promise<void> {
  await apiPut('/config', { strategy });
}

// ─── Agents ──────────────────────────────────────────────────

export async function getAgents(): Promise<Agent[]> {
  return apiFetch<Agent[]>('/agents');
}

export async function getAgent(id: string): Promise<AgentDetail> {
  return apiFetch<AgentDetail>(`/agents/${id}`);
}

export async function updateAgent(
  id: string,
  patch: Partial<AgentDetail>,
): Promise<void> {
  await apiPatch(`/agents/${id}`, patch);
}

export async function pauseAgent(id: string): Promise<void> {
  await apiPost(`/agents/${id}/pause`);
}

export async function resumeAgent(id: string): Promise<void> {
  await apiPost(`/agents/${id}/resume`);
}

export async function stopAgent(id: string): Promise<void> {
  await apiPost(`/agents/${id}/stop`);
}

// ─── Wallets ─────────────────────────────────────────────────

export async function getWallets(): Promise<WalletInfo[]> {
  return apiFetch<WalletInfo[]>('/wallets');
}

export async function createWallets(
  count: number,
  options?: { prefix?: string; randomNames?: boolean },
): Promise<WalletInfo[]> {
  return apiPost<WalletInfo[]>('/wallets/create', { count, ...options });
}

export async function importWallets(keys: string[]): Promise<WalletInfo[]> {
  return apiPost<WalletInfo[]>('/wallets/import', { keys });
}

export async function updateWalletLabel(
  address: string,
  label: string,
): Promise<void> {
  await apiPatch(`/wallets/${address}/label`, { label });
}

export async function fundWallet(
  address: string,
  lamports: string,
): Promise<string> {
  const result = await apiPost<{ txSignature: string }>('/wallets/fund', {
    address,
    lamports,
  });
  return result.txSignature;
}

export async function splitFunding(
  sourceAddress: string,
  totalLamports: string,
  targets: FundingTarget[],
): Promise<string[]> {
  const result = await apiPost<{ signatures: string[] }>('/wallets/split-fund', {
    sourceAddress,
    totalLamports,
    targets,
  });
  return result.signatures;
}

export async function getWalletHistory(
  address: string,
): Promise<{ transactions: Array<{ signature: string; timestamp: number; direction: 'in' | 'out'; amountLamports: string; counterparty: string }> }> {
  return apiFetch(`/wallets/${address}/history`);
}

export async function exportWallets(
  format: 'json' | 'csv' | 'csv-full',
): Promise<Blob> {
  const res = await fetch(`${BASE_URL}/wallets/export?format=${format}`);
  if (!res.ok) throw new ApiError('Export failed', res.status);
  return res.blob();
}

// ─── Trades ──────────────────────────────────────────────────

export async function getTrades(options?: {
  limit?: number;
  offset?: number;
  agent?: string;
  direction?: 'buy' | 'sell';
}): Promise<{ trades: TradeEntry[]; total: number; hasMore: boolean }> {
  const params = new URLSearchParams();
  if (options?.limit) params.set('limit', String(options.limit));
  if (options?.offset) params.set('offset', String(options.offset));
  if (options?.agent) params.set('agent', options.agent);
  if (options?.direction) params.set('direction', options.direction);
  return apiFetch(`/trades?${params.toString()}`);
}

export async function manualTrade(
  walletAddress: string,
  direction: 'buy' | 'sell',
  amountLamports: string,
): Promise<TradeResult> {
  return apiPost<TradeResult>('/trades/manual', {
    walletAddress,
    direction,
    amountLamports,
  });
}

// ─── Analytics & P&L ─────────────────────────────────────────

export async function getAnalytics(): Promise<Analytics> {
  return apiFetch<Analytics>('/analytics');
}

export async function getPnL(): Promise<PnLData> {
  return apiFetch<PnLData>('/pnl');
}

export async function getSupplyDistribution(): Promise<SupplyDistribution> {
  return apiFetch<SupplyDistribution>('/supply');
}

// ─── Health ──────────────────────────────────────────────────

export async function getHealth(): Promise<HealthReport> {
  return apiFetch<HealthReport>('/health');
}

// ─── Events ──────────────────────────────────────────────────

export async function getEvents(options?: {
  limit?: number;
  offset?: number;
  category?: string;
  severity?: string;
  agent?: string;
}): Promise<{ events: TimelineEvent[]; total: number }> {
  const params = new URLSearchParams();
  if (options?.limit) params.set('limit', String(options.limit));
  if (options?.offset) params.set('offset', String(options.offset));
  if (options?.category) params.set('category', options.category);
  if (options?.severity) params.set('severity', options.severity);
  if (options?.agent) params.set('agent', options.agent);
  return apiFetch(`/events?${params.toString()}`);
}

// ─── Config ──────────────────────────────────────────────────

export async function getConfig(): Promise<{ config: SwarmConfig; schema: unknown }> {
  return apiFetch('/config');
}

export async function updateConfig(config: Partial<SwarmConfig>): Promise<{
  success: boolean;
  config: SwarmConfig;
  changes: string[];
  warnings: string[];
  errors: string[];
  requiresRestart: boolean;
}> {
  return apiPut('/config', config);
}

// ─── Templates ───────────────────────────────────────────────

export async function getTemplates(): Promise<Template[]> {
  return apiFetch<Template[]>('/templates');
}

export async function saveTemplate(
  template: Omit<Template, 'id' | 'createdAt' | 'updatedAt'>,
): Promise<Template> {
  return apiPost<Template>('/templates', template);
}

export async function loadTemplate(id: string): Promise<Template> {
  return apiFetch<Template>(`/templates/${id}`);
}

export async function deleteTemplate(id: string): Promise<void> {
  await apiDelete(`/templates/${id}`);
}

// ─── Session ─────────────────────────────────────────────────

export async function createSession(walletAddress: string): Promise<Session> {
  return apiPost<Session>('/session', { walletAddress });
}

export async function getSession(): Promise<Session | null> {
  try {
    return await apiFetch<Session>('/session');
  } catch {
    return null;
  }
}

// ─── Export ──────────────────────────────────────────────────

export async function exportAll(): Promise<Blob> {
  const res = await fetch(`${BASE_URL}/export/full`);
  if (!res.ok) throw new ApiError('Export failed', res.status);
  return res.blob();
}

// ─── Metadata ────────────────────────────────────────────────

export async function uploadMetadataImage(file: File): Promise<{ uri: string }> {
  const formData = new FormData();
  formData.append('image', file);
  const res = await fetch(`${BASE_URL}/metadata/upload`, {
    method: 'POST',
    body: formData,
  });
  if (!res.ok) throw new ApiError('Upload failed', res.status);
  const envelope = (await res.json()) as ApiResponse<{ uri: string }>;
  return envelope.data;
}

export async function generateNarrative(
  name: string,
  symbol: string,
  description: string,
): Promise<{ narrative: string }> {
  return apiPost<{ narrative: string }>('/narrative/generate', {
    name,
    symbol,
    description,
  });
}
