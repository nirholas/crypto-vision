'use client';

import { usePnL } from '@/hooks/usePnL';
import { formatSol, formatNumber, formatUsd } from '@/lib/formatters';

export default function AnalyticsPage() {
  const { data: pnlData } = usePnL();
  const snapshot = pnlData?.current;

  return (
    <div className="space-y-6">
      {/* P&L Summary */}
      <div className="grid grid-cols-4 gap-4">
        <AnalyticCard
          label="Total P&L"
          value={snapshot ? formatSol(snapshot.totalPnlSol) : '—'}
          valueColor={snapshot && snapshot.totalPnlSol >= 0 ? 'text-brand-green' : 'text-brand-red'}
        />
        <AnalyticCard
          label="Realized"
          value={snapshot ? formatSol(snapshot.realizedPnlSol) : '—'}
        />
        <AnalyticCard
          label="Unrealized"
          value={snapshot ? formatSol(snapshot.unrealizedPnlSol) : '—'}
        />
        <AnalyticCard
          label="Total Cost"
          value={snapshot ? formatSol(snapshot.totalCostSol) : '—'}
        />
      </div>

      <div className="bg-surface/50 border border-border-subtle rounded-lg p-6">
        <h3 className="text-lg font-display font-semibold text-text-primary mb-4">
          P&L Over Time
        </h3>
        <div className="h-64 flex items-center justify-center text-text-muted text-sm">
          P&L chart will render here using Recharts when data is available.
        </div>
      </div>

      <div className="bg-surface/50 border border-border-subtle rounded-lg p-6">
        <h3 className="text-lg font-display font-semibold text-text-primary mb-4">
          Trade History
        </h3>
        <div className="text-sm text-text-muted text-center py-8">
          Trade history table will appear when swarm is active.
        </div>
      </div>
    </div>
  );
}

function AnalyticCard({
  label,
  value,
  valueColor,
}: {
  label: string;
  value: string;
  valueColor?: string;
}) {
  return (
    <div className="bg-surface/50 border border-border-subtle rounded-lg p-4">
      <div className="text-xs text-text-muted mb-1">{label}</div>
      <div className={`text-xl font-mono font-bold ${valueColor ?? 'text-text-primary'}`}>
        {value}
      </div>
    </div>
  );
}
