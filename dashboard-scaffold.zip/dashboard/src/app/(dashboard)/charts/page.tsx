'use client';

export default function ChartsPage() {
  return (
    <div className="space-y-6">
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-6">
        <h3 className="text-lg font-display font-semibold text-text-primary mb-4">
          Price Chart
        </h3>
        <div className="h-96 flex items-center justify-center text-text-muted text-sm">
          Price chart will render here using TradingView Lightweight Charts when swarm is active.
        </div>
      </div>
    </div>
  );
}
