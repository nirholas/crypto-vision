'use client';

import { useSwarmStore } from '@/stores/swarm.store';
import { useAgents } from '@/hooks/useAgents';
import { useAgentStore } from '@/stores/agent.store';
import {
  Pause,
  Play,
  OctagonX,
  LogOut as ExitIcon,
} from 'lucide-react';
import {
  pauseSwarm,
  resumeSwarm,
  emergencyStop,
  triggerExit,
} from '@/lib/api';
import { formatPhase, phaseColor, statusColor, formatSol } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

export default function SwarmPage() {
  const phase = useSwarmStore((s) => s.phase);
  const isRunning = useSwarmStore((s) => s.isRunning);
  const isPaused = useSwarmStore((s) => s.isPaused);
  const agents = useAgentStore((s) => s.agents);

  useAgents();

  const handlePause = async () => {
    try {
      await pauseSwarm();
      toast.success('Swarm paused');
    } catch {
      toast.error('Failed to pause');
    }
  };

  const handleResume = async () => {
    try {
      await resumeSwarm();
      toast.success('Swarm resumed');
    } catch {
      toast.error('Failed to resume');
    }
  };

  const handleExit = async () => {
    if (!confirm('Trigger exit strategy? This will begin selling all positions.')) return;
    try {
      await triggerExit();
      toast.success('Exit triggered');
    } catch {
      toast.error('Failed to trigger exit');
    }
  };

  const handleEmergencyStop = async () => {
    if (!confirm('EMERGENCY STOP: Halt all activity immediately?')) return;
    try {
      await emergencyStop();
      toast.success('Emergency stop executed');
    } catch {
      toast.error('Failed to execute emergency stop');
    }
  };

  return (
    <div className="space-y-6">
      {/* Control Bar */}
      <div className="flex items-center gap-3 bg-surface/50 border border-border-subtle rounded-lg p-4">
        <span className={cn('text-sm font-mono font-bold', phaseColor(phase))}>
          {formatPhase(phase)}
        </span>
        <div className="flex-1" />
        {isRunning && !isPaused && (
          <button
            onClick={handlePause}
            className="flex items-center gap-1.5 px-4 py-2 bg-warning/20 text-warning text-sm font-semibold rounded-md hover:bg-warning/30 transition-colors"
          >
            <Pause className="w-4 h-4" />
            Pause
          </button>
        )}
        {isPaused && (
          <button
            onClick={handleResume}
            className="flex items-center gap-1.5 px-4 py-2 bg-brand-green/20 text-brand-green text-sm font-semibold rounded-md hover:bg-brand-green/30 transition-colors"
          >
            <Play className="w-4 h-4" />
            Resume
          </button>
        )}
        {isRunning && (
          <button
            onClick={handleExit}
            className="flex items-center gap-1.5 px-4 py-2 bg-orange-500/20 text-orange-400 text-sm font-semibold rounded-md hover:bg-orange-500/30 transition-colors"
          >
            <ExitIcon className="w-4 h-4" />
            Exit
          </button>
        )}
        {isRunning && (
          <button
            onClick={handleEmergencyStop}
            className="flex items-center gap-1.5 px-4 py-2 bg-brand-red/20 text-brand-red text-sm font-semibold rounded-md hover:bg-brand-red/30 transition-colors"
          >
            <OctagonX className="w-4 h-4" />
            Emergency Stop
          </button>
        )}
      </div>

      {/* Agent Grid */}
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-6">
        <h3 className="text-lg font-display font-semibold text-text-primary mb-4">
          Agents ({agents.length})
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {agents.map((agent) => (
            <div
              key={agent.id}
              className="bg-bg border border-border-subtle rounded-lg p-4 space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono font-semibold text-text-primary">
                  {agent.id}
                </span>
                <span
                  className={cn(
                    'text-xs px-2 py-0.5 rounded-full font-medium',
                    statusColor(agent.status),
                  )}
                >
                  {agent.status}
                </span>
              </div>
              <div className="text-xs text-text-muted">
                {agent.type} · {agent.tradeCount} trades · P&L: {formatSol(agent.pnl)}
              </div>
            </div>
          ))}
          {agents.length === 0 && (
            <div className="col-span-full text-sm text-text-muted text-center py-8">
              No agents running. Configure and launch the swarm to see agents here.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
