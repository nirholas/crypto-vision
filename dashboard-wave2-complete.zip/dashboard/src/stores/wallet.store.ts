import { create } from 'zustand';
import type { WalletInfo } from '@/types';

interface WalletState {
  wallets: WalletInfo[];
  connectedWalletAddress: string | null;
  connectedWalletBalanceLamports: string;
  selectedWalletAddress: string | null;

  setWallets: (wallets: WalletInfo[]) => void;
  addWallets: (wallets: WalletInfo[]) => void;
  updateWallet: (address: string, patch: Partial<WalletInfo>) => void;
  removeWallet: (address: string) => void;
  setConnectedWallet: (address: string | null, balance?: string) => void;
  setConnectedBalance: (balanceLamports: string) => void;
  setSelectedWallet: (address: string | null) => void;
  getWalletByAddress: (address: string) => WalletInfo | undefined;
  getLowBalanceWallets: (thresholdLamports?: number) => WalletInfo[];
  reset: () => void;
}

const LOW_BALANCE_THRESHOLD = 50_000_000; // 0.05 SOL

export const useWalletStore = create<WalletState>()((set, get) => ({
  wallets: [],
  connectedWalletAddress: null,
  connectedWalletBalanceLamports: '0',
  selectedWalletAddress: null,

  setWallets: (wallets: WalletInfo[]) => set({ wallets }),

  addWallets: (newWallets: WalletInfo[]) =>
    set((state) => {
      const existing = new Set(state.wallets.map((w) => w.address));
      const unique = newWallets.filter((w) => !existing.has(w.address));
      return { wallets: [...state.wallets, ...unique] };
    }),

  updateWallet: (address: string, patch: Partial<WalletInfo>) =>
    set((state) => ({
      wallets: state.wallets.map((w) =>
        w.address === address ? { ...w, ...patch } : w,
      ),
    })),

  removeWallet: (address: string) =>
    set((state) => ({
      wallets: state.wallets.filter((w) => w.address !== address),
      selectedWalletAddress:
        state.selectedWalletAddress === address ? null : state.selectedWalletAddress,
    })),

  setConnectedWallet: (address: string | null, balance?: string) =>
    set({
      connectedWalletAddress: address,
      connectedWalletBalanceLamports: balance ?? '0',
    }),

  setConnectedBalance: (balanceLamports: string) =>
    set({ connectedWalletBalanceLamports: balanceLamports }),

  setSelectedWallet: (address: string | null) =>
    set({ selectedWalletAddress: address }),

  getWalletByAddress: (address: string) =>
    get().wallets.find((w) => w.address === address),

  getLowBalanceWallets: (threshold = LOW_BALANCE_THRESHOLD) =>
    get().wallets.filter(
      (w) =>
        w.status === 'active' &&
        Number(w.balanceLamports) < threshold,
    ),

  reset: () =>
    set({
      wallets: [],
      connectedWalletAddress: null,
      connectedWalletBalanceLamports: '0',
      selectedWalletAddress: null,
    }),
}));
