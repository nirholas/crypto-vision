import { create } from 'zustand';
import type { SwarmPhase, SwarmStatus } from '@/types';

interface SwarmState {
  phase: SwarmPhase;
  isRunning: boolean;
  isPaused: boolean;
  mint: string | null;
  totalTrades: number;
  totalVolumeSol: number;
  currentPnlSol: number;
  activeAgentCount: number;
  totalAgentCount: number;
  uptime: number;
  startedAt: number | null;

  setStatus: (status: SwarmStatus) => void;
  setPhase: (phase: SwarmPhase) => void;
  setMint: (mint: string | null) => void;
  updatePnl: (pnlSol: number) => void;
  updateTrades: (total: number, volume: number) => void;
  updateAgentCounts: (active: number, total: number) => void;
  reset: () => void;
}

const initialState = {
  phase: 'idle' as SwarmPhase,
  isRunning: false,
  isPaused: false,
  mint: null as string | null,
  totalTrades: 0,
  totalVolumeSol: 0,
  currentPnlSol: 0,
  activeAgentCount: 0,
  totalAgentCount: 0,
  uptime: 0,
  startedAt: null as number | null,
};

function deriveRunning(phase: SwarmPhase): { isRunning: boolean; isPaused: boolean } {
  const runningPhases: SwarmPhase[] = ['creating', 'bundling', 'trading', 'exiting', 'scouting'];
  return {
    isRunning: runningPhases.includes(phase),
    isPaused: phase === 'paused',
  };
}

export const useSwarmStore = create<SwarmState>()((set) => ({
  ...initialState,

  setStatus: (status: SwarmStatus) =>
    set({
      phase: status.phase as SwarmPhase,
      ...deriveRunning(status.phase as SwarmPhase),
      mint: status.tokenMint,
      totalTrades: status.totalTrades,
      totalVolumeSol: status.totalVolumeSol,
      currentPnlSol: status.currentPnl,
      activeAgentCount: status.activeAgents,
      totalAgentCount: status.totalAgents,
      uptime: status.uptime,
      startedAt: status.startedAt,
    }),

  setPhase: (phase: SwarmPhase) =>
    set({
      phase,
      ...deriveRunning(phase),
    }),

  setMint: (mint: string | null) => set({ mint }),

  updatePnl: (pnlSol: number) => set({ currentPnlSol: pnlSol }),

  updateTrades: (total: number, volume: number) =>
    set({ totalTrades: total, totalVolumeSol: volume }),

  updateAgentCounts: (active: number, total: number) =>
    set({ activeAgentCount: active, totalAgentCount: total }),

  reset: () => set(initialState),
}));
