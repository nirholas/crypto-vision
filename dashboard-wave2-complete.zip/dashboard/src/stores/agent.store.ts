import { create } from 'zustand';
import type { Agent, AgentDetail, TraderPersonality, AgentRole } from '@/types';

interface AgentState {
  agents: Agent[];
  selectedAgentId: string | null;
  agentDetails: Record<string, AgentDetail>;

  setAgents: (agents: Agent[]) => void;
  updateAgent: (id: string, patch: Partial<Agent>) => void;
  setAgentDetail: (id: string, detail: AgentDetail) => void;
  setSelectedAgent: (id: string | null) => void;
  updatePersonality: (id: string, personality: Partial<TraderPersonality>) => void;
  updateRole: (id: string, role: AgentRole) => void;
  getAgentById: (id: string) => Agent | undefined;
  getAgentsByType: (type: string) => Agent[];
  getActiveAgents: () => Agent[];
  getErrorAgents: () => Agent[];
  reset: () => void;
}

export const useAgentStore = create<AgentState>()((set, get) => ({
  agents: [],
  selectedAgentId: null,
  agentDetails: {},

  setAgents: (agents: Agent[]) => set({ agents }),

  updateAgent: (id: string, patch: Partial<Agent>) =>
    set((state) => ({
      agents: state.agents.map((a) => (a.id === id ? { ...a, ...patch } : a)),
    })),

  setAgentDetail: (id: string, detail: AgentDetail) =>
    set((state) => ({
      agentDetails: { ...state.agentDetails, [id]: detail },
    })),

  setSelectedAgent: (id: string | null) => set({ selectedAgentId: id }),

  updatePersonality: (id: string, personality: Partial<TraderPersonality>) =>
    set((state) => {
      const existing = state.agentDetails[id];
      if (!existing) return state;
      return {
        agentDetails: {
          ...state.agentDetails,
          [id]: {
            ...existing,
            personality: { ...existing.personality, ...personality },
          },
        },
      };
    }),

  updateRole: (id: string, role: AgentRole) =>
    set((state) => {
      const existing = state.agentDetails[id];
      if (!existing) return state;
      return {
        agentDetails: {
          ...state.agentDetails,
          [id]: { ...existing, role },
        },
      };
    }),

  getAgentById: (id: string) => get().agents.find((a) => a.id === id),

  getAgentsByType: (type: string) => get().agents.filter((a) => a.type === type),

  getActiveAgents: () => get().agents.filter((a) => a.status === 'active'),

  getErrorAgents: () => get().agents.filter((a) => a.status === 'error'),

  reset: () =>
    set({
      agents: [],
      selectedAgentId: null,
      agentDetails: {},
    }),
}));
