'use client';

import { useQuery } from '@tanstack/react-query';
import { useEffect } from 'react';
import { getSwarmStatus } from '@/lib/api';
import { useSwarmStore } from '@/stores/swarm.store';

export function useSwarmStatus() {
  const setStatus = useSwarmStore((s) => s.setStatus);

  const query = useQuery({
    queryKey: ['swarm-status'],
    queryFn: getSwarmStatus,
    refetchInterval: 1000,
    retry: 3,
    retryDelay: 1000,
  });

  useEffect(() => {
    if (query.data) {
      setStatus(query.data);
    }
  }, [query.data, setStatus]);

  return query;
}
