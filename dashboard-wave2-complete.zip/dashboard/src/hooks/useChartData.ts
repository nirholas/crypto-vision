'use client';

import { useQuery } from '@tanstack/react-query';
import { getTrades } from '@/lib/api';

export function useChartData(options?: {
  limit?: number;
  agent?: string;
  direction?: 'buy' | 'sell';
}) {
  return useQuery({
    queryKey: ['trades', options],
    queryFn: () => getTrades({ limit: options?.limit ?? 200, ...options }),
    refetchInterval: 3000,
    retry: 2,
  });
}
