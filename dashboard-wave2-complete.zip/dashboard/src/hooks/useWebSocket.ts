'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { getWSClient, type WSClient } from '@/lib/ws-client';
import type { DashboardEvent, DashboardEventType } from '@/types';

export function useWebSocket() {
  const clientRef = useRef<WSClient | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const client = getWSClient();
    clientRef.current = client;

    const unsub = client.onConnectionChange(setIsConnected);
    client.connect();

    return () => {
      unsub();
    };
  }, []);

  const subscribe = useCallback(
    (eventType: DashboardEventType | '*', handler: (event: DashboardEvent) => void): (() => void) => {
      const client = clientRef.current;
      if (!client) return () => {};

      const subId = client.on(eventType, handler);
      return () => client.off(subId);
    },
    [],
  );

  return { isConnected, subscribe };
}
