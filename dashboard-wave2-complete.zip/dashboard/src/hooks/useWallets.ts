'use client';

import { useQuery } from '@tanstack/react-query';
import { useEffect } from 'react';
import { getWallets } from '@/lib/api';
import { useWalletStore } from '@/stores/wallet.store';

export function useWallets() {
  const setWallets = useWalletStore((s) => s.setWallets);

  const query = useQuery({
    queryKey: ['wallets'],
    queryFn: getWallets,
    refetchInterval: 5000,
    retry: 2,
  });

  useEffect(() => {
    if (query.data) {
      setWallets(query.data);
    }
  }, [query.data, setWallets]);

  return query;
}
