'use client';

import { useQuery } from '@tanstack/react-query';
import { useEffect } from 'react';
import { getAgents } from '@/lib/api';
import { useAgentStore } from '@/stores/agent.store';

export function useAgents() {
  const setAgents = useAgentStore((s) => s.setAgents);

  const query = useQuery({
    queryKey: ['agents'],
    queryFn: getAgents,
    refetchInterval: 2000,
    retry: 2,
  });

  useEffect(() => {
    if (query.data) {
      setAgents(query.data);
    }
  }, [query.data, setAgents]);

  return query;
}
