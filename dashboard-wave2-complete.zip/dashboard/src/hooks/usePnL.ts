'use client';

import { useQuery } from '@tanstack/react-query';
import { getPnL } from '@/lib/api';

export function usePnL() {
  return useQuery({
    queryKey: ['pnl'],
    queryFn: getPnL,
    refetchInterval: 2000,
    retry: 2,
  });
}
