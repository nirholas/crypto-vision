'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useWallet } from '@solana/wallet-adapter-react';
import { motion } from 'framer-motion';
import { Bot, Gauge, BarChart3 } from 'lucide-react';
import { WalletConnect } from '@/components/landing/WalletConnect';
import { Hero } from '@/components/landing/Hero';

const features = [
  {
    icon: Bot,
    title: '100 Agent Wallets',
    description: 'Coordinate an army of autonomous agents trading in concert.',
  },
  {
    icon: Gauge,
    title: 'Real-Time Control',
    description: 'Pause, resume, and reconfigure agents live from one terminal.',
  },
  {
    icon: BarChart3,
    title: 'Full Analytics',
    description: 'P&L tracking, volume charts, and trade history at a glance.',
  },
];

export default function LandingPage() {
  const { connected } = useWallet();
  const router = useRouter();

  useEffect(() => {
    if (connected) {
      router.push('/dashboard');
    }
  }, [connected, router]);

  return (
    <div className="relative min-h-screen overflow-hidden bg-bg">
      <Hero />

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="text-center max-w-3xl mx-auto"
        >
          <h1 className="text-5xl md:text-6xl font-display font-bold tracking-tight text-text-primary mb-6">
            Swarm Intelligence for{' '}
            <span className="text-brand-green text-glow-green">Pump.fun</span>
          </h1>
          <p className="text-lg md:text-xl text-text-secondary mb-12 max-w-2xl mx-auto leading-relaxed">
            Coordinate up to 100 agent wallets trading in concert. Launch, volume boost, and exit — all from one terminal.
          </p>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <WalletConnect />
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mt-24"
        >
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + i * 0.15, duration: 0.5 }}
              className="bg-surface/50 border border-border-subtle rounded-lg p-6 backdrop-blur-sm hover:border-brand-green/30 transition-colors"
            >
              <feature.icon className="w-8 h-8 text-brand-green mb-4" />
              <h3 className="text-lg font-display font-semibold text-text-primary mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-text-secondary leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
