'use client';

import { useState } from 'react';
import { PnLCard } from '@/components/analytics/PnLCard';
import { VolumeChart } from '@/components/analytics/VolumeChart';
import { WalletBalances } from '@/components/analytics/WalletBalances';
import { TradeHistory } from '@/components/analytics/TradeHistory';
import { CostVsProfit } from '@/components/analytics/CostVsProfit';
import { saveCurrentSession } from '@/lib/api';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

type Tab = 'pnl' | 'volume' | 'wallets' | 'history';

const tabs: Array<{ id: Tab; label: string }> = [
  { id: 'pnl', label: 'P&L' },
  { id: 'volume', label: 'Volume' },
  { id: 'wallets', label: 'Wallets' },
  { id: 'history', label: 'History' },
];

export default function AnalyticsPage() {
  const [activeTab, setActiveTab] = useState<Tab>('pnl');

  const handleSaveSession = async () => {
    const name = prompt('Session name:');
    if (!name) return;
    try {
      await saveCurrentSession(name);
      toast.success('Session saved');
    } catch {
      toast.error('Failed to save session');
    }
  };

  return (
    <div className="space-y-6">
      {/* Tab bar + save session */}
      <div className="flex items-center justify-between">
        <div className="flex gap-1 bg-surface/50 border border-border-subtle rounded-lg p-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                'px-4 py-2 text-sm font-medium rounded-md transition-colors',
                activeTab === tab.id ? 'bg-brand-green/10 text-brand-green' : 'text-text-muted hover:text-text-secondary',
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <button
          onClick={handleSaveSession}
          className="px-4 py-2 bg-surface border border-border-subtle text-xs text-text-secondary rounded-md hover:text-text-primary transition-colors"
        >
          Save Session
        </button>
      </div>

      {/* Tab content */}
      <div className="flex gap-6">
        <div className="flex-1 min-w-0">
          {activeTab === 'pnl' && <PnLCard />}
          {activeTab === 'volume' && <VolumeChart />}
          {activeTab === 'wallets' && <WalletBalances />}
          {activeTab === 'history' && <TradeHistory />}
        </div>

        {/* Cost sidebar (shown on P&L and Volume tabs) */}
        {(activeTab === 'pnl' || activeTab === 'volume') && (
          <div className="w-72 flex-shrink-0">
            <CostVsProfit />
          </div>
        )}
      </div>
    </div>
  );
}
