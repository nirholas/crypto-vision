'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import {
  Activity,
  Bot,
  TrendingUp,
  BarChart3,
  Rocket,
  Settings,
} from 'lucide-react';
import { useSwarmStore } from '@/stores/swarm.store';
import { useAgentStore } from '@/stores/agent.store';
import { useAgents } from '@/hooks/useAgents';
import { useWebSocket } from '@/hooks/useWebSocket';
import {
  formatPhase,
  phaseColor,
  formatSol,
  formatNumber,
  formatUsd,
  relativeTime,
  statusColor,
} from '@/lib/formatters';
import { cn } from '@/lib/utils';
import type { DashboardEvent, TradeExecutedData, AgentType } from '@/types';

const agentTypeIcons: Record<string, string> = {
  creator: '🏗️',
  trader: '📈',
  'market-maker': '⚖️',
  volume: '🔊',
  accumulator: '🧲',
  exit: '🚪',
  sentinel: '🛡️',
  scanner: '🔍',
  narrative: '📝',
  sniper: '🎯',
  stability: '⚙️',
};

interface RecentTrade {
  id: string;
  agentLabel: string;
  direction: 'buy' | 'sell';
  solAmount: number;
  tokenAmount: number;
  timestamp: number;
}

export default function OverviewPage() {
  const router = useRouter();
  const phase = useSwarmStore((s) => s.phase);
  const activeAgentCount = useSwarmStore((s) => s.activeAgentCount);
  const totalAgentCount = useSwarmStore((s) => s.totalAgentCount);
  const pnl = useSwarmStore((s) => s.currentPnlSol);
  const totalVolume = useSwarmStore((s) => s.totalVolumeSol);
  const isRunning = useSwarmStore((s) => s.isRunning);
  const agents = useAgentStore((s) => s.agents);

  const [recentTrades, setRecentTrades] = useState<RecentTrade[]>([]);
  const { subscribe } = useWebSocket();

  // Load agents
  useAgents();

  // Subscribe to trade events
  useEffect(() => {
    const unsub = subscribe('trade:executed', (event: DashboardEvent) => {
      const data = event.data as unknown as TradeExecutedData;
      const trade: RecentTrade = {
        id: `${Date.now()}-${Math.random()}`,
        agentLabel: data.agentLabel ?? data.agentId ?? 'unknown',
        direction: data.direction,
        solAmount: data.solAmount,
        tokenAmount: data.tokenAmount,
        timestamp: Date.now(),
      };
      setRecentTrades((prev) => [trade, ...prev].slice(0, 20));
    });

    return unsub;
  }, [subscribe]);

  const handleQuickDeploy = useCallback(() => {
    // Could open modal - for now navigate to configure
    router.push('/dashboard/configure');
  }, [router]);

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      <div className="grid grid-cols-4 gap-4">
        <StatCard
          label="Current Phase"
          value={formatPhase(phase)}
          valueClass={phaseColor(phase)}
          icon={<Activity className="w-5 h-5" />}
        />
        <StatCard
          label="Active Agents"
          value={`${activeAgentCount}/${totalAgentCount}`}
          icon={<Bot className="w-5 h-5" />}
        />
        <StatCard
          label="Total P&L"
          value={formatSol(pnl)}
          valueClass={pnl >= 0 ? 'text-brand-green' : 'text-brand-red'}
          icon={<TrendingUp className="w-5 h-5" />}
        />
        <StatCard
          label="Volume 24h"
          value={formatSol(totalVolume)}
          icon={<BarChart3 className="w-5 h-5" />}
        />
      </div>

      {/* Middle Row */}
      <div className="grid grid-cols-2 gap-6">
        {/* Left: Quick Start or Live Summary */}
        <div className="bg-surface/50 border border-border-subtle rounded-lg p-6">
          {!isRunning ? (
            <div className="space-y-4">
              <h3 className="text-lg font-display font-semibold text-text-primary">
                Quick Start
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={handleQuickDeploy}
                  className="flex flex-col items-center gap-2 p-6 bg-brand-green/5 border border-brand-green/20 rounded-lg hover:bg-brand-green/10 transition-colors"
                >
                  <Rocket className="w-8 h-8 text-brand-green" />
                  <span className="text-sm font-semibold text-brand-green">
                    Quick Deploy
                  </span>
                </button>
                <button
                  onClick={() => router.push('/dashboard/configure')}
                  className="flex flex-col items-center gap-2 p-6 bg-surface border border-border-subtle rounded-lg hover:border-text-muted transition-colors"
                >
                  <Settings className="w-8 h-8 text-text-secondary" />
                  <span className="text-sm font-semibold text-text-secondary">
                    Configure & Launch
                  </span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-lg font-display font-semibold text-text-primary">
                Live Summary
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-text-muted">Bonding Curve</span>
                  <span className="text-text-primary">—</span>
                </div>
                <div className="w-full bg-surface rounded-full h-2">
                  <div
                    className="bg-brand-green h-2 rounded-full transition-all duration-500"
                    style={{ width: '0%' }}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-text-muted block">Token Price</span>
                    <span className="text-text-primary font-mono">—</span>
                  </div>
                  <div>
                    <span className="text-text-muted block">Market Cap</span>
                    <span className="text-text-primary font-mono">—</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right: Recent Trades Feed */}
        <div className="bg-surface/50 border border-border-subtle rounded-lg p-6">
          <h3 className="text-lg font-display font-semibold text-text-primary mb-4">
            Recent Trades
          </h3>
          <div className="space-y-1 max-h-64 overflow-y-auto">
            {recentTrades.length === 0 ? (
              <div className="text-sm text-text-muted text-center py-8">
                No trades yet. Start the swarm to see live trades.
              </div>
            ) : (
              recentTrades.map((trade) => (
                <motion.div
                  key={trade.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={cn(
                    'flex items-center gap-3 text-xs font-mono py-1.5 px-2 rounded border-l-2',
                    trade.direction === 'buy'
                      ? 'border-l-brand-green bg-brand-green/5'
                      : 'border-l-brand-red bg-brand-red/5',
                  )}
                >
                  <span className="text-text-muted w-20 truncate">
                    {trade.agentLabel}
                  </span>
                  <span
                    className={cn(
                      'font-semibold w-8',
                      trade.direction === 'buy'
                        ? 'text-brand-green'
                        : 'text-brand-red',
                    )}
                  >
                    {trade.direction.toUpperCase()}
                  </span>
                  <span className="text-text-primary">
                    {trade.solAmount.toFixed(4)} SOL
                  </span>
                  <span className="text-text-muted">
                    {formatNumber(Math.round(trade.tokenAmount))} tokens
                  </span>
                  <span className="text-text-muted ml-auto">
                    {relativeTime(trade.timestamp)}
                  </span>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Agent Health Grid */}
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-6">
        <h3 className="text-lg font-display font-semibold text-text-primary mb-4">
          Agent Health
        </h3>
        <div className="grid grid-cols-5 md:grid-cols-8 lg:grid-cols-10 gap-2">
          {agents.length === 0 ? (
            <div className="col-span-full text-sm text-text-muted text-center py-4">
              No agents configured yet.
            </div>
          ) : (
            agents.map((agent) => (
              <button
                key={agent.id}
                onClick={() => router.push('/dashboard/swarm')}
                className="flex flex-col items-center gap-1 p-2 rounded-md bg-bg border border-border-subtle hover:border-brand-green/30 transition-colors"
                title={`${agent.id} — ${agent.status}`}
              >
                <span className="text-lg">
                  {agentTypeIcons[agent.type as AgentType] ?? '🤖'}
                </span>
                <span className="text-[10px] text-text-muted truncate w-full text-center">
                  {agent.id.slice(0, 8)}
                </span>
                <span
                  className={cn(
                    'w-2 h-2 rounded-full',
                    agent.status === 'active'
                      ? 'bg-brand-green'
                      : agent.status === 'paused'
                        ? 'bg-warning'
                        : agent.status === 'error'
                          ? 'bg-brand-red animate-pulse'
                          : 'bg-zinc-600',
                  )}
                />
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  valueClass,
  icon,
}: {
  label: string;
  value: string;
  valueClass?: string;
  icon: React.ReactNode;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-surface/50 border border-border-subtle rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-text-muted font-medium">{label}</span>
        <span className="text-text-muted">{icon}</span>
      </div>
      <div className={cn('text-2xl font-mono font-bold', valueClass ?? 'text-text-primary')}>
        {value}
      </div>
    </motion.div>
  );
}
