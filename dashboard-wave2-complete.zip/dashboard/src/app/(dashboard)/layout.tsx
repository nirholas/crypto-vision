'use client';

import { type ReactNode, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useWallet } from '@solana/wallet-adapter-react';
import { Sidebar } from '@/components/layout/Sidebar';
import { TopBar } from '@/components/layout/TopBar';
import { useSwarmStatus } from '@/hooks/useSwarmStatus';

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const { connected } = useWallet();
  const router = useRouter();

  // Hydrate global swarm state from polling
  useSwarmStatus();

  useEffect(() => {
    if (!connected) {
      router.push('/');
    }
  }, [connected, router]);

  if (!connected) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <div className="text-text-muted font-mono text-sm">Connecting...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg">
      <Sidebar />
      <TopBar />
      <main className="ml-60 mt-14 p-6">{children}</main>
    </div>
  );
}
