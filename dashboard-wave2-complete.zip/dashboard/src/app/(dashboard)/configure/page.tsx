'use client';

import { useState } from 'react';
import { cn } from '@/lib/utils';

const tabs = [
  { id: 'token', label: 'Token' },
  { id: 'launch', label: 'Launch Mode' },
  { id: 'strategy', label: 'Strategy' },
  { id: 'agents', label: 'Agents' },
  { id: 'bundle', label: 'Bundle' },
  { id: 'exit', label: 'Exit' },
  { id: 'templates', label: 'Templates' },
];

export default function ConfigurePage() {
  const [activeTab, setActiveTab] = useState('token');

  return (
    <div className="flex gap-6">
      {/* Main content */}
      <div className="flex-1 min-w-0">
        {/* Tab bar */}
        <div className="flex gap-1 mb-6 bg-surface/50 border border-border-subtle rounded-lg p-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                'px-4 py-2 text-sm font-medium rounded-md transition-colors',
                activeTab === tab.id
                  ? 'bg-brand-green/10 text-brand-green'
                  : 'text-text-muted hover:text-text-secondary',
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="bg-surface/50 border border-border-subtle rounded-lg p-6">
          {activeTab === 'token' && <TokenTab />}
          {activeTab === 'launch' && <LaunchTab />}
          {activeTab === 'strategy' && <StrategyTab />}
          {activeTab === 'agents' && <AgentsTab />}
          {activeTab === 'bundle' && <BundleTab />}
          {activeTab === 'exit' && <ExitTab />}
          {activeTab === 'templates' && <TemplatesTab />}
        </div>
      </div>

      {/* Cost estimator sidebar */}
      <div className="w-72 flex-shrink-0">
        <CostEstimatorSidebar />
      </div>
    </div>
  );
}

// ─── Token Tab ───────────────────────────────────────────────

function TokenTab() {
  const [name, setName] = useState('');
  const [symbol, setSymbol] = useState('');
  const [description, setDescription] = useState('');
  const [imageUri, setImageUri] = useState('');

  return (
    <div className="space-y-5 max-w-lg">
      <h3 className="text-lg font-display font-semibold text-text-primary">Token Metadata</h3>

      <Field label="Token Name" maxLength={32}>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={32}
          placeholder="My Token"
          className="input-field"
        />
        <span className="text-xs text-text-muted mt-1 block">{name.length}/32</span>
      </Field>

      <Field label="Token Symbol" maxLength={10}>
        <input
          value={symbol}
          onChange={(e) => setSymbol(e.target.value.toUpperCase())}
          maxLength={10}
          placeholder="TKN"
          className="input-field"
        />
      </Field>

      <Field label="Description">
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          maxLength={500}
          rows={4}
          placeholder="Describe your token..."
          className="input-field resize-none"
        />
        <span className="text-xs text-text-muted mt-1 block">{description.length}/500</span>
      </Field>

      <Field label="Image URI">
        <input
          value={imageUri}
          onChange={(e) => setImageUri(e.target.value)}
          placeholder="https://..."
          className="input-field"
        />
      </Field>
    </div>
  );
}

// ─── Launch Mode Tab ─────────────────────────────────────────

function LaunchTab() {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-display font-semibold text-text-primary">Launch Mode</h3>
      <p className="text-sm text-text-secondary">
        Select which actions to execute during launch.
      </p>
      <div className="space-y-3">
        <CheckOption label="Create Token" description="Mint the token on Pump.fun" checked disabled />
        <CheckOption label="Dev Buy" description="Creator wallet buys at creation" />
        <CheckOption label="Bundle Buy" description="Additional wallets buy atomically" />
        <CheckOption label="Volume Generation" description="Run VolumeAgent after launch" />
        <CheckOption label="Market Making" description="Run MarketMakerAgent" />
        <CheckOption label="Auto Exit" description="Run ExitAgent when conditions are met" />
        <CheckOption label="Consolidate Profits" description="Consolidate SOL to master wallet after exit" />
      </div>
    </div>
  );
}

// ─── Strategy Tab ────────────────────────────────────────────

function StrategyTab() {
  const [preset, setPreset] = useState('organic');
  const [minInterval, setMinInterval] = useState(30);
  const [maxInterval, setMaxInterval] = useState(120);
  const [buySellRatio, setBuySellRatio] = useState(1.4);
  const [useJito, setUseJito] = useState(false);

  const buyPercent = Math.round((buySellRatio / (buySellRatio + 1)) * 100);

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-display font-semibold text-text-primary">Trading Strategy</h3>

      {/* Presets */}
      <div className="grid grid-cols-4 gap-3">
        {(['organic', 'volume', 'graduation', 'custom'] as const).map((p) => (
          <button
            key={p}
            onClick={() => setPreset(p)}
            className={cn(
              'p-3 rounded-lg border text-sm font-medium transition-colors text-center capitalize',
              preset === p
                ? 'border-brand-green bg-brand-green/10 text-brand-green'
                : 'border-border-subtle text-text-muted hover:border-text-muted',
            )}
          >
            {p}
          </button>
        ))}
      </div>

      {/* Sliders */}
      <div className="grid grid-cols-2 gap-6">
        <SliderField
          label="Min Interval"
          value={minInterval}
          onChange={setMinInterval}
          min={1}
          max={600}
          unit="s"
        />
        <SliderField
          label="Max Interval"
          value={maxInterval}
          onChange={setMaxInterval}
          min={1}
          max={600}
          unit="s"
        />
        <SliderField
          label="Buy/Sell Ratio"
          value={buySellRatio}
          onChange={setBuySellRatio}
          min={0.1}
          max={9}
          step={0.1}
          unit=""
          extra={`~${buyPercent}% buys`}
        />
        <div>
          <label className="flex items-center gap-3 text-sm text-text-secondary">
            <input
              type="checkbox"
              checked={useJito}
              onChange={() => setUseJito(!useJito)}
              className="rounded border-border-subtle accent-brand-green"
            />
            Use Jito Bundles
          </label>
        </div>
      </div>
    </div>
  );
}

// ─── Agents Tab ──────────────────────────────────────────────

function AgentsTab() {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-display font-semibold text-text-primary">Agent Configuration</h3>
      <p className="text-sm text-text-secondary">
        Configure individual agent personalities. Agents will be shown here after wallets are created.
      </p>
      <div className="grid grid-cols-4 gap-3">
        {(['Cautious', 'Balanced', 'Aggressive', 'Chaotic'] as const).map((p) => (
          <button
            key={p}
            className="p-3 rounded-lg border border-border-subtle text-sm text-text-muted hover:border-brand-green/30 hover:text-text-secondary transition-colors"
          >
            {p}
          </button>
        ))}
      </div>
      <div className="text-sm text-text-muted text-center py-8">
        Create wallets first, then configure agent personalities here.
      </div>
    </div>
  );
}

// ─── Bundle Tab ──────────────────────────────────────────────

function BundleTab() {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-display font-semibold text-text-primary">Bundle Planner</h3>
      <p className="text-sm text-text-secondary">
        Configure which wallets participate in the launch bundle buy.
      </p>
      <div className="bg-bg rounded-md p-4">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border-subtle">
              <th className="text-left text-xs text-text-muted py-2">Wallet</th>
              <th className="text-right text-xs text-text-muted py-2">Amount (SOL)</th>
              <th className="text-right text-xs text-text-muted py-2">Est. MC After</th>
              <th className="text-right text-xs text-text-muted py-2">Est. Tokens</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-border-subtle/50">
              <td className="py-2 text-text-primary">Creator (dev buy)</td>
              <td className="py-2 text-right font-mono text-text-secondary">0.50</td>
              <td className="py-2 text-right font-mono text-text-muted">—</td>
              <td className="py-2 text-right font-mono text-text-muted">—</td>
            </tr>
          </tbody>
        </table>
        <button className="mt-3 text-xs text-brand-green font-medium">
          + Add Bundle Wallet
        </button>
      </div>
    </div>
  );
}

// ─── Exit Tab ────────────────────────────────────────────────

function ExitTab() {
  const [strategy, setStrategy] = useState('gradual');

  return (
    <div className="space-y-5">
      <h3 className="text-lg font-display font-semibold text-text-primary">Exit Strategy</h3>

      <div className="grid grid-cols-4 gap-3">
        {[
          { id: 'gradual', label: 'Gradual', desc: 'Spread sells evenly' },
          { id: 'staged', label: 'Staged', desc: 'Sell at price targets' },
          { id: 'immediate', label: 'Immediate', desc: 'Sell everything ASAP' },
          { id: 'trailing-stop', label: 'Trailing Stop', desc: 'Follow price up' },
        ].map((s) => (
          <button
            key={s.id}
            onClick={() => setStrategy(s.id)}
            className={cn(
              'p-3 rounded-lg border text-left transition-colors',
              strategy === s.id
                ? 'border-brand-green bg-brand-green/10'
                : 'border-border-subtle hover:border-text-muted',
            )}
          >
            <div className={cn('text-sm font-medium', strategy === s.id ? 'text-brand-green' : 'text-text-secondary')}>
              {s.label}
            </div>
            <div className="text-xs text-text-muted mt-1">{s.desc}</div>
          </button>
        ))}
      </div>

      {strategy === 'immediate' && (
        <div className="bg-brand-red/10 border border-brand-red/20 rounded-md p-3 text-xs text-brand-red">
          Warning: High price impact. Only use for emergency exits.
        </div>
      )}
    </div>
  );
}

// ─── Templates Tab ───────────────────────────────────────────

function TemplatesTab() {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-display font-semibold text-text-primary">Templates</h3>
      <p className="text-sm text-text-secondary">
        Save and load configuration templates.
      </p>
      <div className="text-sm text-text-muted text-center py-8 border border-dashed border-border-subtle rounded-lg">
        No saved templates yet. Configure your settings and save them as a template.
      </div>
      <button className="w-full py-2.5 bg-brand-green/20 text-brand-green font-semibold text-sm rounded-lg hover:bg-brand-green/30 transition-colors">
        Save Current Config as Template
      </button>
    </div>
  );
}

// ─── Cost Estimator Sidebar ──────────────────────────────────

function CostEstimatorSidebar() {
  return (
    <div className="bg-surface/50 border border-border-subtle rounded-lg p-5 sticky top-20 space-y-4">
      <h3 className="text-sm font-display font-semibold text-text-primary border-b border-border-subtle pb-2">
        ESTIMATED COSTS
      </h3>
      <CostLine label="Dev Buy" value="0.50 SOL" />
      <CostLine label="Bundle Buys" value="0.00 SOL" />
      <CostLine label="Volume Budget" value="0.00 SOL" />
      <CostLine label="Transaction Fees" value="~0.05 SOL" />
      <CostLine label="Jito Tips" value="0.00 SOL" />
      <div className="border-t border-border-subtle pt-3 mt-3">
        <div className="flex justify-between text-sm font-semibold">
          <span className="text-text-secondary">TOTAL</span>
          <span className="text-brand-green font-mono">0.55 SOL</span>
        </div>
        <div className="text-xs text-text-muted text-right mt-1">~$0.00 est.</div>
      </div>
      <div className="border-t border-border-subtle pt-3 space-y-2">
        <CostLine label="Supply Control" value="—" />
        <CostLine label="Break-Even" value="—" />
      </div>
    </div>
  );
}

// ─── Shared UI Components ────────────────────────────────────

function Field({ label, children, maxLength }: { label: string; children: React.ReactNode; maxLength?: number }) {
  return (
    <div>
      <label className="text-sm text-text-secondary block mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function CheckOption({ label, description, checked, disabled }: {
  label: string;
  description: string;
  checked?: boolean;
  disabled?: boolean;
}) {
  const [isChecked, setIsChecked] = useState(checked ?? false);
  return (
    <label className="flex items-start gap-3 p-3 bg-bg rounded-md cursor-pointer hover:bg-surface/50 transition-colors">
      <input
        type="checkbox"
        checked={isChecked}
        disabled={disabled}
        onChange={() => !disabled && setIsChecked(!isChecked)}
        className="mt-0.5 rounded border-border-subtle accent-brand-green"
      />
      <div>
        <div className="text-sm font-medium text-text-primary">{label}</div>
        <div className="text-xs text-text-muted">{description}</div>
      </div>
    </label>
  );
}

function SliderField({ label, value, onChange, min, max, step, unit, extra }: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step?: number;
  unit: string;
  extra?: string;
}) {
  return (
    <div>
      <div className="flex justify-between mb-1.5">
        <label className="text-sm text-text-secondary">{label}</label>
        <span className="text-sm font-mono text-text-primary">
          {value}{unit}
          {extra && <span className="text-xs text-text-muted ml-1">({extra})</span>}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step ?? 1}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-brand-green"
      />
    </div>
  );
}

function CostLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-xs">
      <span className="text-text-muted">{label}</span>
      <span className="text-text-secondary font-mono">{value}</span>
    </div>
  );
}
