'use client';

import { useState, useEffect, useCallback } from 'react';
import { Download, ChevronDown } from 'lucide-react';
import { PriceChart } from '@/components/charts/PriceChart';
import { DexScreenerEmbed } from '@/components/charts/DexScreenerEmbed';
import { WalletTracker } from '@/components/charts/WalletTracker';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useSwarmStore } from '@/stores/swarm.store';
import { relativeTime, formatNumber } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import type { DashboardEvent, TradeExecutedData } from '@/types';

type ChartSource = 'ours' | 'dexscreener' | 'gmgn';

const timeframes = [
  { label: '1s', value: 1 },
  { label: '5s', value: 5 },
  { label: '15s', value: 15 },
  { label: '1m', value: 60 },
  { label: '5m', value: 300 },
  { label: '15m', value: 900 },
  { label: '1h', value: 3600 },
];

interface TradeLogEntry {
  id: string;
  timestamp: number;
  agentLabel: string;
  agentType: string;
  direction: 'buy' | 'sell';
  amountSol: number;
  tokens: number;
  price: number;
  signature: string;
}

export default function ChartsPage() {
  const [source, setSource] = useState<ChartSource>('ours');
  const [resolution, setResolution] = useState(60);
  const [showAgentMarkers, setShowAgentMarkers] = useState(true);
  const [showVolume, setShowVolume] = useState(true);
  const [showGraduation, setShowGraduation] = useState(true);
  const [tradeLog, setTradeLog] = useState<TradeLogEntry[]>([]);
  const [logCollapsed, setLogCollapsed] = useState(false);
  const mint = useSwarmStore((s) => s.mint);
  const { subscribe } = useWebSocket();

  useEffect(() => {
    const unsub = subscribe('trade:executed', (event: DashboardEvent) => {
      const data = event.data as unknown as TradeExecutedData;
      const entry: TradeLogEntry = {
        id: `${Date.now()}-${Math.random()}`,
        timestamp: Date.now(),
        agentLabel: data.agentLabel ?? data.agentId,
        agentType: 'T',
        direction: data.direction,
        amountSol: data.solAmount,
        tokens: data.tokenAmount,
        price: data.price,
        signature: data.signature ?? '',
      };
      setTradeLog((prev) => [entry, ...prev].slice(0, 50));
    });
    return unsub;
  }, [subscribe]);

  return (
    <div className="space-y-4 h-[calc(100vh-120px)] flex flex-col">
      {/* Controls Bar */}
      <div className="flex items-center gap-3 flex-shrink-0">
        {/* Source selector */}
        <div className="flex bg-surface/50 border border-border-subtle rounded-md overflow-hidden">
          {([['ours', 'Our Chart'], ['dexscreener', 'DexScreener'], ['gmgn', 'GMGN']] as const).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setSource(key as ChartSource)}
              className={cn('px-3 py-1.5 text-xs font-medium', source === key ? 'bg-brand-green/10 text-brand-green' : 'text-text-muted hover:text-text-secondary')}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Timeframe (only for our chart) */}
        {source === 'ours' && (
          <div className="flex bg-surface/50 border border-border-subtle rounded-md overflow-hidden">
            {timeframes.map((tf) => (
              <button
                key={tf.value}
                onClick={() => setResolution(tf.value)}
                className={cn('px-2 py-1.5 text-xs font-mono', resolution === tf.value ? 'bg-brand-green/10 text-brand-green' : 'text-text-muted')}
              >
                {tf.label}
              </button>
            ))}
          </div>
        )}

        {/* Overlay toggles */}
        {source === 'ours' && (
          <div className="flex items-center gap-3 ml-4">
            <label className="flex items-center gap-1.5 text-xs text-text-secondary cursor-pointer">
              <input type="checkbox" checked={showAgentMarkers} onChange={() => setShowAgentMarkers(!showAgentMarkers)} className="rounded accent-brand-green" />
              Agent Trades
            </label>
            <label className="flex items-center gap-1.5 text-xs text-text-secondary cursor-pointer">
              <input type="checkbox" checked={showGraduation} onChange={() => setShowGraduation(!showGraduation)} className="rounded accent-brand-green" />
              Graduation Line
            </label>
          </div>
        )}
      </div>

      {/* Main area */}
      <div className="flex gap-4 flex-1 min-h-0">
        {/* Chart */}
        <div className="flex-1 min-w-0 bg-bg rounded-lg border border-border-subtle overflow-hidden">
          {source === 'ours' && (
            <PriceChart
              resolution={resolution}
              showAgentMarkers={showAgentMarkers}
              showGraduationLine={showGraduation}
            />
          )}
          {source === 'dexscreener' && <DexScreenerEmbed />}
          {source === 'gmgn' && (
            mint ? (
              <iframe
                src={`https://gmgn.ai/sol/token/${mint}`}
                className="w-full h-full"
                sandbox="allow-same-origin allow-scripts allow-popups"
                title="GMGN"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-sm text-text-muted">
                Launch a token first
              </div>
            )
          )}
        </div>

        {/* Wallet Tracker */}
        <div className="w-[320px] flex-shrink-0">
          <WalletTracker />
        </div>
      </div>

      {/* Trade Log (collapsible) */}
      <div className={cn('flex-shrink-0 bg-surface/50 border border-border-subtle rounded-lg overflow-hidden transition-all', logCollapsed ? 'h-10' : 'h-[200px]')}>
        <button
          onClick={() => setLogCollapsed(!logCollapsed)}
          className="w-full flex items-center justify-between px-4 py-2 text-xs font-semibold text-text-secondary"
        >
          Trade Log ({tradeLog.length})
          <ChevronDown className={cn('w-3.5 h-3.5 transition-transform', logCollapsed && 'rotate-180')} />
        </button>
        {!logCollapsed && (
          <div className="overflow-y-auto h-[calc(100%-32px)] px-4 pb-2">
            <table className="w-full text-[11px] font-mono">
              <thead>
                <tr className="text-text-muted">
                  <th className="text-left py-1">Time</th>
                  <th className="text-left">Agent</th>
                  <th className="text-center">Dir</th>
                  <th className="text-right">SOL</th>
                  <th className="text-right">Tokens</th>
                  <th className="text-right">Price</th>
                  <th className="text-right">Tx</th>
                </tr>
              </thead>
              <tbody>
                {tradeLog.map((t) => (
                  <tr key={t.id} className={cn(t.direction === 'buy' ? 'text-brand-green/80' : 'text-brand-red/80')}>
                    <td className="py-0.5 text-text-muted">{relativeTime(t.timestamp)}</td>
                    <td>{t.agentLabel}</td>
                    <td className="text-center font-bold">{t.direction === 'buy' ? 'BUY' : 'SELL'}</td>
                    <td className="text-right">{t.amountSol.toFixed(4)}</td>
                    <td className="text-right">{formatNumber(Math.round(t.tokens))}</td>
                    <td className="text-right">{t.price > 0 ? t.price.toFixed(9) : '—'}</td>
                    <td className="text-right">
                      {t.signature && (
                        <a href={`https://solscan.io/tx/${t.signature}`} target="_blank" rel="noopener noreferrer" className="text-text-muted hover:text-brand-green">🔗</a>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
