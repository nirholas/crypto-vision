'use client';

import { useState, useCallback } from 'react';
import { Plus, Upload, Send, Download, AlertTriangle } from 'lucide-react';
import { useWallets } from '@/hooks/useWallets';
import { useWalletStore } from '@/stores/wallet.store';
import { WalletTable } from '@/components/wallets/WalletTable';
import { WalletCard } from '@/components/wallets/WalletCard';
import { CreateWalletsModal } from '@/components/wallets/CreateWalletsModal';
import { ImportWalletsModal } from '@/components/wallets/ImportWalletsModal';
import { FundingPanel } from '@/components/wallets/FundingPanel';
import { cn } from '@/lib/utils';

export default function WalletsPage() {
  const [showCreate, setShowCreate] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showFunding, setShowFunding] = useState(false);

  const selectedAddress = useWalletStore((s) => s.selectedWalletAddress);
  const lowBalanceWallets = useWalletStore((s) => s.getLowBalanceWallets());

  useWallets();

  return (
    <div className="space-y-4">
      {/* Low balance warning */}
      {lowBalanceWallets.length > 0 && (
        <div className="flex items-center gap-3 bg-warning/10 border border-warning/20 rounded-lg px-4 py-3">
          <AlertTriangle className="w-4 h-4 text-warning flex-shrink-0" />
          <span className="text-sm text-warning">
            {lowBalanceWallets.length} wallet{lowBalanceWallets.length > 1 ? 's are' : ' is'} running low on SOL. Active agents may fail.
          </span>
          <button
            onClick={() => setShowFunding(true)}
            className="ml-auto text-xs font-semibold text-warning hover:text-warning/80 transition-colors"
          >
            Auto-Top Up
          </button>
        </div>
      )}

      <div className="flex gap-6">
        {/* Left: Actions */}
        <div className="w-64 flex-shrink-0 space-y-2">
          <h3 className="text-sm font-semibold text-text-secondary mb-3">
            Actions
          </h3>
          <ActionButton icon={Plus} label="Create Wallets" onClick={() => setShowCreate(true)} />
          <ActionButton icon={Upload} label="Import Wallets" onClick={() => setShowImport(true)} />
          <ActionButton icon={Send} label="Fund Wallets" onClick={() => setShowFunding(true)} />
          <ActionButton icon={Download} label="Export All" onClick={() => {}} />
        </div>

        {/* Center: Table */}
        <div className="flex-1 min-w-0">
          <WalletTable />
        </div>

        {/* Right: Detail */}
        {selectedAddress && (
          <div className="w-80 flex-shrink-0">
            <WalletCard address={selectedAddress} />
          </div>
        )}
      </div>

      {/* Modals */}
      {showCreate && <CreateWalletsModal onClose={() => setShowCreate(false)} />}
      {showImport && <ImportWalletsModal onClose={() => setShowImport(false)} />}
      {showFunding && <FundingPanel onClose={() => setShowFunding(false)} />}
    </div>
  );
}

function ActionButton({
  icon: Icon,
  label,
  onClick,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-3 px-4 py-3 bg-surface/50 border border-border-subtle rounded-lg text-sm text-text-secondary hover:text-text-primary hover:border-brand-green/30 transition-colors"
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  );
}
