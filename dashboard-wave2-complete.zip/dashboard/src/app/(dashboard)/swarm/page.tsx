'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useAgents } from '@/hooks/useAgents';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useAgentStore } from '@/stores/agent.store';
import { useSwarmStore } from '@/stores/swarm.store';
import { SwarmControlBar } from '@/components/swarm/SwarmControlBar';
import { AgentGrid } from '@/components/swarm/AgentGrid';
import { AgentEditModal } from '@/components/swarm/AgentEditModal';
import { ManualTradePanel } from '@/components/swarm/ManualTradePanel';
import { SwarmVisualizer, type SwarmVisualizerHandle } from '@/components/swarm/SwarmVisualizer';
import { PhaseTimeline } from '@/components/swarm/PhaseTimeline';
import { relativeTime, formatNumber } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import type { DashboardEvent, TradeExecutedData } from '@/types';

interface RecentTrade {
  id: string;
  agentId: string;
  agentLabel: string;
  direction: 'buy' | 'sell';
  solAmount: number;
  tokenAmount: number;
  signature: string;
  timestamp: number;
}

export default function SwarmPage() {
  const agents = useAgentStore((s) => s.agents);
  const [editingAgentId, setEditingAgentId] = useState<string | null>(null);
  const [preselectedWallet, setPreselectedWallet] = useState<string | undefined>();
  const [recentTrades, setRecentTrades] = useState<RecentTrade[]>([]);
  const [agentTradeMap, setAgentTradeMap] = useState<Record<string, Array<{ direction: 'buy' | 'sell'; timestamp: number }>>>({});
  const visualizerRef = useRef<SwarmVisualizerHandle>(null);
  const { subscribe } = useWebSocket();

  useAgents();

  useEffect(() => {
    const unsubs: Array<() => void> = [];

    unsubs.push(subscribe('trade:executed', (event: DashboardEvent) => {
      const data = event.data as unknown as TradeExecutedData;
      const trade: RecentTrade = {
        id: `${Date.now()}-${Math.random()}`,
        agentId: data.agentId,
        agentLabel: data.agentLabel ?? data.agentId,
        direction: data.direction,
        solAmount: data.solAmount,
        tokenAmount: data.tokenAmount,
        signature: data.signature ?? '',
        timestamp: Date.now(),
      };

      setRecentTrades((prev) => [trade, ...prev].slice(0, 30));
      setAgentTradeMap((prev) => {
        const list = prev[data.agentId] ?? [];
        return { ...prev, [data.agentId]: [{ direction: data.direction, timestamp: Date.now() }, ...list].slice(0, 60) };
      });
      visualizerRef.current?.triggerPulse(data.agentId, data.direction);
    }));

    unsubs.push(subscribe('pnl:updated', (event: DashboardEvent) => {
      const pnl = (event.data as { totalPnlSol?: number }).totalPnlSol;
      if (typeof pnl === 'number') useSwarmStore.getState().updatePnl(pnl);
    }));

    unsubs.push(subscribe('phase:changed', (event: DashboardEvent) => {
      const phase = (event.data as { newPhase?: string }).newPhase;
      if (phase) useSwarmStore.getState().setPhase(phase as 'idle');
    }));

    return () => unsubs.forEach((u) => u());
  }, [subscribe]);

  return (
    <div className="space-y-4">
      <SwarmControlBar />
      <PhaseTimeline />

      <div className="flex gap-4">
        <div className="flex-1 min-w-0">
          <AgentGrid
            onEditAgent={setEditingAgentId}
            onManualTrade={(addr) => setPreselectedWallet(addr)}
            agentTradeMap={agentTradeMap}
          />
        </div>

        <div className="w-[380px] flex-shrink-0 space-y-4">
          <ManualTradePanel preselectedWallet={preselectedWallet} />

          <div className="bg-surface/50 border border-border-subtle rounded-lg p-4 max-h-[300px] overflow-y-auto">
            <h4 className="text-xs font-semibold text-text-secondary uppercase tracking-wider mb-3">Live Trades</h4>
            {recentTrades.length === 0 ? (
              <div className="text-xs text-text-muted text-center py-4">Waiting for trades...</div>
            ) : (
              <div className="space-y-1">
                {recentTrades.map((t) => (
                  <div
                    key={t.id}
                    className={cn(
                      'flex items-center gap-2 text-[11px] font-mono py-1 px-2 rounded border-l-2',
                      t.direction === 'buy' ? 'border-l-brand-green bg-brand-green/5' : 'border-l-brand-red bg-brand-red/5',
                    )}
                  >
                    <span className="text-text-muted w-16 truncate">{t.agentLabel}</span>
                    <span className={cn('font-bold w-7', t.direction === 'buy' ? 'text-brand-green' : 'text-brand-red')}>
                      {t.direction === 'buy' ? 'BUY' : 'SELL'}
                    </span>
                    <span className="text-text-primary">{t.solAmount.toFixed(4)}</span>
                    <span className="text-text-muted">→</span>
                    <span className="text-text-secondary">{formatNumber(Math.round(t.tokenAmount))}</span>
                    <span className="text-text-muted ml-auto">{relativeTime(t.timestamp)}</span>
                    {t.signature && (
                      <a href={`https://solscan.io/tx/${t.signature}`} target="_blank" rel="noopener noreferrer" className="text-text-muted hover:text-brand-green">🔗</a>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <SwarmVisualizer ref={visualizerRef} agents={agents} />

      {editingAgentId && (
        <AgentEditModal agentId={editingAgentId} onClose={() => setEditingAgentId(null)} />
      )}
    </div>
  );
}
