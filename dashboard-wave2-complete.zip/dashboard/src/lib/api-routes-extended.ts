/**
 * Dashboard Extended API Routes — Wave 2 endpoints
 *
 * Adds: session management, chart data, templates, bursts,
 * manual trades, GMGN scraping, wallet tracking, analytics.
 */

import { Hono } from 'hono';
import type { Context as HonoContext } from 'hono';
import { cors } from 'hono/cors';
import { createCipheriv, createDecipheriv, scryptSync, randomBytes } from 'node:crypto';

import {
  getDb,
  uuid,
  now,
  createSession as dbCreateSession,
  getActiveSession,
  listSessions as dbListSessions,
  updateSession,
  insertTrade,
  getTradesPaginated as dbGetTradesPaginated,
  getCandles,
  updateCandlesFromTrade,
  getTemplates as dbGetTemplates,
  createTemplate as dbCreateTemplate,
  deleteTemplate as dbDeleteTemplate,
  getBurstEvents as dbGetBurstEvents,
  createBurstEvent as dbCreateBurstEvent,
  markBurstTriggered,
  getTrackedWallets as dbGetTrackedWallets,
  addTrackedWallet,
  removeTrackedWallet,
} from './db.js';

const SERVER_SECRET = process.env.SERVER_ENCRYPTION_SECRET ?? 'default-change-me-32-chars-long!';

// ─── Helpers ─────────────────────────────────────────────────

function ok<T>(data: T) {
  return { success: true, data, timestamp: Date.now() };
}

function fail(error: string, status = 400) {
  return { success: false, data: null, timestamp: Date.now(), error };
}

function getWalletPubkey(c: HonoContext): string {
  return c.req.header('X-Wallet-Pubkey') ?? 'anonymous';
}

function encryptPrivateKey(privateKeyBase58: string, walletPubkey: string): string {
  const encryptionKey = scryptSync(`${walletPubkey}:${SERVER_SECRET}`, 'swarm-salt-v1', 32);
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', encryptionKey, iv);
  const encrypted = Buffer.concat([cipher.update(privateKeyBase58, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
}

function decryptPrivateKey(encrypted: string, walletPubkey: string): string {
  const [ivHex, tagHex, dataHex] = encrypted.split(':');
  const encryptionKey = scryptSync(`${walletPubkey}:${SERVER_SECRET}`, 'swarm-salt-v1', 32);
  const decipher = createDecipheriv('aes-256-gcm', encryptionKey, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  return decipher.update(Buffer.from(dataHex, 'hex')) + decipher.final('utf8');
}

// GMGN cache
const gmgnCache = new Map<string, { data: unknown; expiresAt: number }>();

// ─── Route Registration ──────────────────────────────────────

export function registerExtendedRoutes(app: Hono): void {
  // CORS
  app.use('/api/*', cors({
    origin: ['http://localhost:3000', 'http://127.0.0.1:3000'],
    credentials: true,
  }));

  const db = getDb();

  // ── Session ───────────────────────────────────────────────

  app.post('/api/session', async (c: HonoContext) => {
    try {
      const { walletAddress } = await c.req.json<{ walletAddress: string }>();
      const existing = getActiveSession(db, walletAddress);
      if (existing) return c.json(ok(existing));

      const id = dbCreateSession(db, walletAddress, 'New Session', '{}');
      const session = db.prepare('SELECT * FROM sessions WHERE id = ?').get(id);
      return c.json(ok(session));
    } catch (err) {
      return c.json(fail(err instanceof Error ? err.message : String(err)), 500);
    }
  });

  app.get('/api/session/list', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const sessions = dbListSessions(db, pubkey);
      return c.json(ok(sessions));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.post('/api/session/save', async (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const { name } = await c.req.json<{ name: string }>();
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(fail('No active session'), 404);

      updateSession(db, session.id, { name, updated_at: now() });
      return c.json(ok({ sessionId: session.id }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  // ── Chart Data ────────────────────────────────────────────

  app.get('/api/chart/history', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(ok([]));

      const resolution = Number(c.req.query('resolution') ?? '60');
      const from = c.req.query('from') ? Number(c.req.query('from')) : undefined;
      const to = c.req.query('to') ? Number(c.req.query('to')) : undefined;

      const candles = getCandles(db, session.id, resolution, from, to).map((row: any) => ({
        time: row.open_time,
        open: Number(row.open),
        high: Number(row.high),
        low: Number(row.low),
        close: Number(row.close),
        volume: Number(row.volume),
        trades: row.trades,
      }));

      return c.json(ok(candles));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.get('/api/chart/latest', (c: HonoContext) => {
    try {
      return c.json(ok({ price: 0, marketCapSol: 0, volume24h: 0 }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  // ── Templates ─────────────────────────────────────────────

  app.get('/api/templates', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const templates = dbGetTemplates(db, pubkey).map((t: any) => ({
        ...t,
        config: JSON.parse(t.config_json),
      }));
      return c.json(ok(templates));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.post('/api/templates', async (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const { name, description, config } = await c.req.json<{ name: string; description: string; config: unknown }>();
      const id = dbCreateTemplate(db, pubkey, name, description ?? '', JSON.stringify(config));
      const template = db.prepare('SELECT * FROM templates WHERE id = ?').get(id);
      return c.json(ok(template));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.delete('/api/templates/:id', (c: HonoContext) => {
    try {
      dbDeleteTemplate(db, c.req.param('id'));
      return c.json(ok({ deleted: true }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  // ── Burst Events ──────────────────────────────────────────

  app.get('/api/bursts', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(ok([]));

      const bursts = dbGetBurstEvents(db, session.id).map((b: any) => ({
        ...b,
        walletAddresses: JSON.parse(b.wallet_addresses),
        amountPerWalletLamports: b.amount_per_wallet,
        simultaneous: !!b.simultaneous,
        executedAt: b.executed_at,
        createdAt: b.created_at,
        triggerType: b.trigger_type,
        triggerValue: Number(b.trigger_value),
      }));
      return c.json(ok(bursts));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.post('/api/bursts', async (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(fail('No active session'), 404);

      const body = await c.req.json();
      const id = dbCreateBurstEvent(db, session.id, {
        triggerType: body.triggerType,
        triggerValue: String(body.triggerValue),
        walletAddresses: body.walletAddresses,
        amountPerWallet: body.amountPerWalletLamports,
        simultaneous: body.simultaneous,
      });
      return c.json(ok({ id }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.post('/api/bursts/:id/trigger', (c: HonoContext) => {
    try {
      markBurstTriggered(db, c.req.param('id'));
      return c.json(ok({ triggered: true }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  // ── Manual Trade ──────────────────────────────────────────

  app.post('/api/trades/manual', async (c: HonoContext) => {
    try {
      const body = await c.req.json<{
        walletAddress: string;
        direction: 'buy' | 'sell';
        amountLamports: string;
        slippageBps?: number;
        priorityFeeMicroLamports?: number;
        useJito?: boolean;
      }>();

      // In production: execute trade via TraderAgent or SDK
      // For now: record and return mock result
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);

      const tradeId = session ? insertTrade(db, {
        sessionId: session.id,
        agentId: 'manual',
        walletAddress: body.walletAddress,
        direction: body.direction,
        amountLamports: body.amountLamports,
        tokensAmount: '0',
        executionPrice: '0',
        feesPaid: '0',
        signature: `manual-${uuid().slice(0, 8)}`,
        executedAt: now(),
      }) : uuid();

      return c.json(ok({
        success: true,
        signature: `manual-${tradeId.slice(0, 8)}`,
        solAmount: Number(body.amountLamports) / 1e9,
        tokenAmount: 0,
        price: 0,
      }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.post('/api/trades/multi', async (c: HonoContext) => {
    try {
      const body = await c.req.json<{
        wallets: string[];
        direction: 'buy' | 'sell';
        amounts: string[];
        useJito: boolean;
        staggerMs?: number;
      }>();

      const results = body.wallets.map((addr, i) => ({
        walletAddress: addr,
        success: true,
        signature: `multi-${uuid().slice(0, 8)}`,
      }));

      return c.json(ok({ results }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  // ── GMGN ──────────────────────────────────────────────────

  app.get('/api/gmgn/wallets', async (c: HonoContext) => {
    try {
      const mint = c.req.query('mint');
      if (!mint) return c.json(fail('mint required'), 400);

      const cacheKey = `gmgn:${mint}`;
      const cached = gmgnCache.get(cacheKey);
      if (cached && cached.expiresAt > Date.now()) {
        return c.json(ok(cached.data));
      }

      // In production: scrape GMGN or call undocumented API
      // For now: return empty array (scraping requires server-side fetch)
      const data: unknown[] = [];
      gmgnCache.set(cacheKey, { data, expiresAt: Date.now() + 30_000 });

      return c.json(ok(data));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  // ── Wallet Tracking ───────────────────────────────────────

  app.get('/api/wallets/tracked', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(ok([]));
      return c.json(ok(dbGetTrackedWallets(db, session.id)));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.post('/api/wallets/track', async (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(fail('No session'), 404);

      const { address, label } = await c.req.json<{ address: string; label: string }>();
      const id = addTrackedWallet(db, session.id, address, label, 'manual');
      return c.json(ok({ id }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.delete('/api/wallets/track/:address', (c: HonoContext) => {
    try {
      removeTrackedWallet(db, c.req.param('address'));
      return c.json(ok({ deleted: true }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  // ── Analytics ─────────────────────────────────────────────

  app.get('/api/analytics/pnl/timeseries', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(ok([]));

      // Sample P&L from trades
      const trades = db.prepare(
        `SELECT * FROM trades WHERE session_id = ? ORDER BY executed_at ASC`,
      ).all(session.id) as any[];

      let cumPnl = 0;
      const points = trades.map((t: any) => {
        const sol = Number(t.amount_lamports) / 1e9;
        cumPnl += t.direction === 'sell' ? sol : -sol;
        return {
          timestamp: Math.floor(t.executed_at / 1000),
          realizedSol: t.direction === 'sell' ? sol : 0,
          unrealizedSol: 0,
          totalSol: cumPnl,
        };
      });

      return c.json(ok(points));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.get('/api/analytics/agents', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(ok([]));

      const rows = db.prepare(`
        SELECT agent_id,
          SUM(CASE WHEN direction = 'buy' THEN CAST(amount_lamports AS REAL) / 1e9 ELSE 0 END) as sol_spent,
          SUM(CASE WHEN direction = 'sell' THEN CAST(amount_lamports AS REAL) / 1e9 ELSE 0 END) as sol_received,
          COUNT(*) as trade_count,
          SUM(CASE WHEN direction = 'sell' THEN 1 ELSE 0 END) as sell_count
        FROM trades WHERE session_id = ?
        GROUP BY agent_id
      `).all(session.id) as any[];

      const agents = rows.map((r: any) => ({
        agentId: r.agent_id,
        role: 'trader',
        solSpent: r.sol_spent,
        solReceived: r.sol_received,
        realizedPnl: r.sol_received - r.sol_spent,
        unrealizedPnl: 0,
        totalPnl: r.sol_received - r.sol_spent,
        winRate: r.trade_count > 0 ? (r.sell_count / r.trade_count) * 100 : 0,
        tradeCount: r.trade_count,
      }));

      return c.json(ok(agents));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.get('/api/analytics/volume/hourly', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(ok([]));

      const rows = db.prepare(`
        SELECT
          strftime('%H:00', executed_at / 1000, 'unixepoch') as hour,
          SUM(CASE WHEN direction = 'buy' THEN CAST(amount_lamports AS REAL) / 1e9 ELSE 0 END) as buy_volume,
          SUM(CASE WHEN direction = 'sell' THEN CAST(amount_lamports AS REAL) / 1e9 ELSE 0 END) as sell_volume,
          COUNT(*) as trade_count
        FROM trades WHERE session_id = ?
        GROUP BY hour ORDER BY hour
      `).all(session.id) as any[];

      const hourly = rows.map((r: any) => ({
        hour: r.hour,
        buyVolume: r.buy_volume,
        sellVolume: r.sell_volume,
        totalVolume: r.buy_volume + r.sell_volume,
        tradeCount: r.trade_count,
      }));

      return c.json(ok(hourly));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.get('/api/analytics/costs', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(ok({
        gasFeesSol: 0, jitoTipsSol: 0, totalExposureSol: 0,
        projectedGas1hr: 0, projectedJito1hr: 0, projectedCapital1hr: 0,
      }));

      const fees = db.prepare(`SELECT SUM(CAST(fees_paid AS REAL) / 1e9) as total_fees FROM trades WHERE session_id = ?`).get(session.id) as any;
      const exposure = db.prepare(`
        SELECT SUM(CASE WHEN direction = 'buy' THEN CAST(amount_lamports AS REAL) / 1e9 ELSE -CAST(amount_lamports AS REAL) / 1e9 END) as net
        FROM trades WHERE session_id = ?
      `).get(session.id) as any;

      return c.json(ok({
        gasFeesSol: fees?.total_fees ?? 0,
        jitoTipsSol: 0,
        totalExposureSol: Math.max(0, exposure?.net ?? 0),
        projectedGas1hr: (fees?.total_fees ?? 0) * 0.5,
        projectedJito1hr: 0,
        projectedCapital1hr: Math.max(0, exposure?.net ?? 0) * 0.3,
      }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.get('/api/analytics/trades', (c: HonoContext) => {
    try {
      const pubkey = getWalletPubkey(c);
      const session = getActiveSession(db, pubkey);
      if (!session) return c.json(ok({ trades: [], total: 0, page: 1, totalPages: 1 }));

      const page = Number(c.req.query('page') ?? '1');
      const limit = Number(c.req.query('limit') ?? '50');
      const direction = c.req.query('direction') || undefined;
      const agent = c.req.query('agent') || undefined;

      const result = dbGetTradesPaginated(db, session.id, page, limit, { direction, agentId: agent });
      const trades = (result.trades as any[]).map((t) => ({
        id: t.id,
        timestamp: t.executed_at,
        agentId: t.agent_id,
        direction: t.direction,
        solAmount: Number(t.amount_lamports) / 1e9,
        tokenAmount: Number(t.tokens_amount),
        price: Number(t.execution_price),
        signature: t.signature,
        success: true,
      }));

      return c.json(ok({ trades, total: result.total, page: result.page, totalPages: result.totalPages }));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });

  app.get('/api/analytics/holdings', (c: HonoContext) => {
    try {
      // Placeholder — in production reads from wallet balances
      return c.json(ok([]));
    } catch (err) {
      return c.json(fail(String(err)), 500);
    }
  });
}
