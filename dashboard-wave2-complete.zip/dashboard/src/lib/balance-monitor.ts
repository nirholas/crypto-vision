/**
 * Balance Monitor — Polls wallet balances and emits low-balance warnings
 */

export interface BalanceMonitorConfig {
  thresholdLamports: number;
  pollIntervalMs: number;
}

const DEFAULT_CONFIG: BalanceMonitorConfig = {
  thresholdLamports: 50_000_000, // 0.05 SOL
  pollIntervalMs: 30_000,
};

export interface WalletBalance {
  address: string;
  label: string;
  balanceLamports: number;
}

export type BalanceAlertHandler = (wallet: WalletBalance) => void;

export class BalanceMonitor {
  private config: BalanceMonitorConfig;
  private timer: ReturnType<typeof setInterval> | null = null;
  private alertHandler: BalanceAlertHandler | null = null;
  private getWallets: (() => Promise<WalletBalance[]>) | null = null;

  constructor(config?: Partial<BalanceMonitorConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  setWalletProvider(fn: () => Promise<WalletBalance[]>): void {
    this.getWallets = fn;
  }

  onLowBalance(handler: BalanceAlertHandler): void {
    this.alertHandler = handler;
  }

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => this.check(), this.config.pollIntervalMs);
    this.check();
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private async check(): Promise<void> {
    if (!this.getWallets || !this.alertHandler) return;

    try {
      const wallets = await this.getWallets();
      for (const wallet of wallets) {
        if (wallet.balanceLamports < this.config.thresholdLamports) {
          this.alertHandler(wallet);
        }
      }
    } catch {
      // Silently retry next interval
    }
  }
}
