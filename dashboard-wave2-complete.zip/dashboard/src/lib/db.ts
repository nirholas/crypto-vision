/**
 * Dashboard SQLite Database — Persistence for sessions, wallets, trades, candles, templates
 *
 * Uses better-sqlite3 for synchronous operations.
 * Database file: data/swarm.db
 */

import Database from 'better-sqlite3';
import { randomUUID } from 'node:crypto';
import { mkdirSync, existsSync } from 'node:fs';
import { dirname } from 'node:path';

const DB_PATH = process.env.DATABASE_PATH ?? './data/swarm.db';

let _db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (_db) return _db;

  const dir = dirname(DB_PATH);
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });

  _db = new Database(DB_PATH);
  _db.pragma('journal_mode = WAL');
  _db.pragma('foreign_keys = ON');

  initSchema(_db);
  return _db;
}

function initSchema(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      wallet_pubkey TEXT NOT NULL,
      name TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      phase TEXT NOT NULL DEFAULT 'idle',
      elapsed_seconds INTEGER NOT NULL DEFAULT 0,
      mint TEXT,
      config_json TEXT NOT NULL DEFAULT '{}',
      is_active INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS wallets (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      address TEXT NOT NULL,
      label TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'unassigned',
      encrypted_key TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (session_id) REFERENCES sessions(id)
    );

    CREATE INDEX IF NOT EXISTS idx_wallets_session ON wallets(session_id);
    CREATE INDEX IF NOT EXISTS idx_wallets_address ON wallets(address);

    CREATE TABLE IF NOT EXISTS trades (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      agent_id TEXT NOT NULL,
      wallet_address TEXT NOT NULL,
      direction TEXT NOT NULL,
      amount_lamports TEXT NOT NULL,
      tokens_amount TEXT NOT NULL,
      execution_price TEXT NOT NULL,
      fees_paid TEXT NOT NULL DEFAULT '0',
      signature TEXT NOT NULL,
      executed_at INTEGER NOT NULL,
      FOREIGN KEY (session_id) REFERENCES sessions(id)
    );

    CREATE INDEX IF NOT EXISTS idx_trades_session ON trades(session_id);
    CREATE INDEX IF NOT EXISTS idx_trades_agent ON trades(agent_id);
    CREATE INDEX IF NOT EXISTS idx_trades_time ON trades(executed_at);

    CREATE TABLE IF NOT EXISTS candles (
      session_id TEXT NOT NULL,
      resolution INTEGER NOT NULL,
      open_time INTEGER NOT NULL,
      open TEXT NOT NULL,
      high TEXT NOT NULL,
      low TEXT NOT NULL,
      close TEXT NOT NULL,
      volume TEXT NOT NULL,
      trades INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (session_id, resolution, open_time)
    );

    CREATE TABLE IF NOT EXISTS templates (
      id TEXT PRIMARY KEY,
      wallet_pubkey TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT,
      config_json TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_templates_wallet ON templates(wallet_pubkey);

    CREATE TABLE IF NOT EXISTS burst_events (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      trigger_type TEXT NOT NULL,
      trigger_value TEXT,
      wallet_addresses TEXT NOT NULL,
      amount_per_wallet TEXT NOT NULL,
      simultaneous INTEGER NOT NULL DEFAULT 1,
      executed_at INTEGER,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS tracked_wallets (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      address TEXT NOT NULL,
      label TEXT NOT NULL,
      color TEXT NOT NULL,
      source TEXT NOT NULL DEFAULT 'manual',
      added_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS price_alerts (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      alert_type TEXT NOT NULL,
      value TEXT NOT NULL,
      triggered_at INTEGER,
      created_at INTEGER NOT NULL
    );
  `);
}

// ─── Helpers ─────────────────────────────────────────────────

export function uuid(): string {
  return randomUUID();
}

export function now(): number {
  return Date.now();
}

// ─── Session Repository ──────────────────────────────────────

export function createSession(db: Database.Database, walletPubkey: string, name: string, configJson: string): string {
  const id = uuid();
  const ts = now();
  db.prepare(`INSERT INTO sessions (id, wallet_pubkey, name, created_at, updated_at, config_json, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)`)
    .run(id, walletPubkey, name, ts, ts, configJson);
  return id;
}

export function getActiveSession(db: Database.Database, walletPubkey: string) {
  return db.prepare(`SELECT * FROM sessions WHERE wallet_pubkey = ? AND is_active = 1 ORDER BY updated_at DESC LIMIT 1`).get(walletPubkey) as any;
}

export function listSessions(db: Database.Database, walletPubkey: string) {
  return db.prepare(`SELECT * FROM sessions WHERE wallet_pubkey = ? ORDER BY updated_at DESC`).all(walletPubkey) as any[];
}

export function updateSession(db: Database.Database, id: string, updates: Record<string, unknown>) {
  const fields = Object.keys(updates).map((k) => `${k} = ?`).join(', ');
  const values = Object.values(updates);
  db.prepare(`UPDATE sessions SET ${fields}, updated_at = ? WHERE id = ?`).run(...values, now(), id);
}

// ─── Trade Repository ────────────────────────────────────────

export function insertTrade(db: Database.Database, trade: {
  sessionId: string; agentId: string; walletAddress: string; direction: string;
  amountLamports: string; tokensAmount: string; executionPrice: string;
  feesPaid: string; signature: string; executedAt: number;
}): string {
  const id = uuid();
  db.prepare(`INSERT INTO trades (id, session_id, agent_id, wallet_address, direction, amount_lamports, tokens_amount, execution_price, fees_paid, signature, executed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(id, trade.sessionId, trade.agentId, trade.walletAddress, trade.direction, trade.amountLamports, trade.tokensAmount, trade.executionPrice, trade.feesPaid, trade.signature, trade.executedAt);
  return id;
}

export function getTradesPaginated(db: Database.Database, sessionId: string, page: number, limit: number, filters?: { direction?: string; agentId?: string }) {
  let where = `WHERE session_id = ?`;
  const params: unknown[] = [sessionId];
  if (filters?.direction) { where += ` AND direction = ?`; params.push(filters.direction); }
  if (filters?.agentId) { where += ` AND agent_id LIKE ?`; params.push(`%${filters.agentId}%`); }

  const total = (db.prepare(`SELECT COUNT(*) as cnt FROM trades ${where}`).get(...params) as any).cnt;
  const offset = (page - 1) * limit;
  const trades = db.prepare(`SELECT * FROM trades ${where} ORDER BY executed_at DESC LIMIT ? OFFSET ?`).all(...params, limit, offset);

  return { trades, total, page, totalPages: Math.ceil(total / limit) };
}

// ─── Candle Repository ───────────────────────────────────────

export function upsertCandle(db: Database.Database, sessionId: string, resolution: number, priceSol: number, volumeSol: number) {
  const candleTime = Math.floor(Date.now() / 1000 / resolution) * resolution;

  db.prepare(`
    INSERT INTO candles (session_id, resolution, open_time, open, high, low, close, volume, trades)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
    ON CONFLICT (session_id, resolution, open_time) DO UPDATE SET
      high = MAX(CAST(high AS REAL), ?),
      low  = MIN(CAST(low AS REAL), ?),
      close = ?,
      volume = CAST(volume AS REAL) + ?,
      trades = trades + 1
  `).run(
    sessionId, resolution, candleTime,
    priceSol, priceSol, priceSol, priceSol, volumeSol,
    priceSol, priceSol, priceSol, volumeSol,
  );
}

export function getCandles(db: Database.Database, sessionId: string, resolution: number, from?: number, to?: number) {
  let sql = `SELECT * FROM candles WHERE session_id = ? AND resolution = ?`;
  const params: unknown[] = [sessionId, resolution];
  if (from) { sql += ` AND open_time >= ?`; params.push(from); }
  if (to) { sql += ` AND open_time <= ?`; params.push(to); }
  sql += ` ORDER BY open_time ASC`;
  return db.prepare(sql).all(...params) as any[];
}

// ─── Template Repository ─────────────────────────────────────

export function getTemplates(db: Database.Database, walletPubkey: string) {
  return db.prepare(`SELECT * FROM templates WHERE wallet_pubkey = ? ORDER BY updated_at DESC`).all(walletPubkey) as any[];
}

export function createTemplate(db: Database.Database, walletPubkey: string, name: string, description: string, configJson: string): string {
  const id = uuid();
  const ts = now();
  db.prepare(`INSERT INTO templates (id, wallet_pubkey, name, description, config_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run(id, walletPubkey, name, description, configJson, ts, ts);
  return id;
}

export function deleteTemplate(db: Database.Database, id: string) {
  db.prepare(`DELETE FROM templates WHERE id = ?`).run(id);
}

// ─── Burst Events Repository ─────────────────────────────────

export function getBurstEvents(db: Database.Database, sessionId: string) {
  return db.prepare(`SELECT * FROM burst_events WHERE session_id = ? ORDER BY created_at DESC`).all(sessionId) as any[];
}

export function createBurstEvent(db: Database.Database, sessionId: string, event: {
  triggerType: string; triggerValue: string; walletAddresses: string[]; amountPerWallet: string; simultaneous: boolean;
}): string {
  const id = uuid();
  db.prepare(`INSERT INTO burst_events (id, session_id, trigger_type, trigger_value, wallet_addresses, amount_per_wallet, simultaneous, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(id, sessionId, event.triggerType, event.triggerValue, JSON.stringify(event.walletAddresses), event.amountPerWallet, event.simultaneous ? 1 : 0, now());
  return id;
}

export function markBurstTriggered(db: Database.Database, id: string) {
  db.prepare(`UPDATE burst_events SET executed_at = ? WHERE id = ?`).run(now(), id);
}

// ─── Tracked Wallets Repository ──────────────────────────────

const COLORS = ['#00bfff', '#ff8c00', '#9333ea', '#14b8a6', '#f43f5e', '#eab308', '#3b82f6', '#ec4899'];

export function getTrackedWallets(db: Database.Database, sessionId: string) {
  return db.prepare(`SELECT * FROM tracked_wallets WHERE session_id = ? ORDER BY added_at DESC`).all(sessionId) as any[];
}

export function addTrackedWallet(db: Database.Database, sessionId: string, address: string, label: string, source: string): string {
  const id = uuid();
  const existing = db.prepare(`SELECT COUNT(*) as cnt FROM tracked_wallets WHERE session_id = ?`).get(sessionId) as any;
  const color = COLORS[existing.cnt % COLORS.length];
  db.prepare(`INSERT INTO tracked_wallets (id, session_id, address, label, color, source, added_at) VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run(id, sessionId, address, label, color, source, now());
  return id;
}

export function removeTrackedWallet(db: Database.Database, address: string) {
  db.prepare(`DELETE FROM tracked_wallets WHERE address = ?`).run(address);
}

// ─── OHLCV Synthesis ─────────────────────────────────────────

const RESOLUTIONS = [1, 5, 15, 60, 300, 900, 3600];

export function updateCandlesFromTrade(db: Database.Database, sessionId: string, priceSol: number, volumeSol: number) {
  for (const res of RESOLUTIONS) {
    upsertCandle(db, sessionId, res, priceSol, volumeSol);
  }
}
