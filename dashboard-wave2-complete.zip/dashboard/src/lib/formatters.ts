const LAMPORTS_PER_SOL = 1_000_000_000;

/** Convert lamport string to SOL number */
export function lamportsToSol(lamports: string | number): number {
  const raw = typeof lamports === 'string' ? Number(lamports) : lamports;
  return raw / LAMPORTS_PER_SOL;
}

/** Convert SOL number to lamport string */
export function solToLamports(sol: number): string {
  return Math.round(sol * LAMPORTS_PER_SOL).toString();
}

/** Format SOL amount with 4 decimal places */
export function formatSol(sol: number, decimals = 4): string {
  return `${sol.toFixed(decimals)} SOL`;
}

/** Format lamport string as SOL display */
export function formatLamportsAsSol(lamports: string | number, decimals = 4): string {
  return formatSol(lamportsToSol(lamports), decimals);
}

/** Format USD amount */
export function formatUsd(usd: number): string {
  if (Math.abs(usd) >= 1_000_000) {
    return `$${(usd / 1_000_000).toFixed(2)}M`;
  }
  if (Math.abs(usd) >= 1_000) {
    return `$${(usd / 1_000).toFixed(2)}K`;
  }
  return `$${usd.toFixed(2)}`;
}

/** Format a number with commas */
export function formatNumber(n: number): string {
  return n.toLocaleString('en-US');
}

/** Format a large number compactly */
export function formatCompact(n: number): string {
  if (Math.abs(n) >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(2)}B`;
  if (Math.abs(n) >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (Math.abs(n) >= 1_000) return `${(n / 1_000).toFixed(2)}K`;
  return n.toFixed(2);
}

/** Truncate address: first 4...last 4 */
export function truncateAddress(address: string, chars = 4): string {
  if (address.length <= chars * 2 + 3) return address;
  return `${address.slice(0, chars)}...${address.slice(-chars)}`;
}

/** Truncate address: first 6...last 6 */
export function truncateAddressLong(address: string): string {
  return truncateAddress(address, 6);
}

/** Relative time: "2s ago", "1m ago", "3h ago", "2d ago" */
export function relativeTime(timestampMs: number): string {
  const now = Date.now();
  const diffMs = now - timestampMs;
  const diffSeconds = Math.floor(diffMs / 1000);

  if (diffSeconds < 0) return 'just now';
  if (diffSeconds < 60) return `${diffSeconds}s ago`;
  const diffMinutes = Math.floor(diffSeconds / 60);
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d ago`;
}

/** Format elapsed time as HH:MM:SS */
export function formatElapsed(seconds: number): string {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  return [
    hrs.toString().padStart(2, '0'),
    mins.toString().padStart(2, '0'),
    secs.toString().padStart(2, '0'),
  ].join(':');
}

/** Format duration in ms to human-readable */
export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const seconds = ms / 1000;
  if (seconds < 60) return `${seconds.toFixed(1)}s`;
  const minutes = seconds / 60;
  if (minutes < 60) return `${minutes.toFixed(1)}m`;
  const hours = minutes / 60;
  return `${hours.toFixed(1)}h`;
}

/** Format a percentage */
export function formatPercent(value: number, decimals = 1): string {
  return `${value.toFixed(decimals)}%`;
}

/** Phase display name */
export function formatPhase(phase: string): string {
  const map: Record<string, string> = {
    idle: 'IDLE',
    scouting: 'SCOUTING',
    creating: 'CREATING',
    bundling: 'BUNDLING',
    trading: 'TRADING',
    exiting: 'EXITING',
    paused: 'PAUSED',
    done: 'DONE',
  };
  return map[phase] ?? phase.toUpperCase();
}

/** Phase color class */
export function phaseColor(phase: string): string {
  const map: Record<string, string> = {
    idle: 'text-zinc-400',
    scouting: 'text-blue-400',
    creating: 'text-yellow-400',
    bundling: 'text-yellow-400',
    trading: 'text-brand-green',
    exiting: 'text-brand-red',
    paused: 'text-warning',
    done: 'text-zinc-500',
  };
  return map[phase] ?? 'text-zinc-400';
}

/** Phase background color for pills */
export function phaseBgColor(phase: string): string {
  const map: Record<string, string> = {
    idle: 'bg-zinc-700/50',
    scouting: 'bg-blue-900/50',
    creating: 'bg-yellow-900/50',
    bundling: 'bg-yellow-900/50',
    trading: 'bg-brand-green/10',
    exiting: 'bg-brand-red/10',
    paused: 'bg-warning/10',
    done: 'bg-zinc-800/50',
  };
  return map[phase] ?? 'bg-zinc-700/50';
}

/** Status badge color */
export function statusColor(status: string): string {
  const map: Record<string, string> = {
    active: 'bg-brand-green/20 text-brand-green',
    paused: 'bg-warning/20 text-warning',
    idle: 'bg-zinc-700/50 text-zinc-400',
    error: 'bg-brand-red/20 text-brand-red',
    stopped: 'bg-zinc-700/50 text-zinc-500',
  };
  return map[status] ?? 'bg-zinc-700/50 text-zinc-400';
}

/** Role display */
export function formatRole(role: string): string {
  const map: Record<string, string> = {
    creator: 'Creator',
    trader: 'Trader',
    'market-maker': 'Market Maker',
    volume: 'Volume',
    accumulator: 'Accumulator',
    sniper: 'Sniper',
    'exit-only': 'Exit Only',
    unassigned: 'Unassigned',
  };
  return map[role] ?? role;
}
