import type {
  ApiResponse,
  SwarmStatus,
  Agent,
  AgentDetail,
  WalletInfo,
  PnLData,
  Analytics,
  TradeResult,
  TradeEntry,
  Template,
  TradingStrategy,
  HealthReport,
  SupplyDistribution,
  TimelineEvent,
  SwarmConfig,
  Session,
  FundingTarget,
  ManualTradeOptions,
} from '@/types';

const BASE_URL = '/api';

// ─── Core Fetch Wrapper ──────────────────────────────────────

async function apiFetch<T>(
  path: string,
  options?: RequestInit,
): Promise<T> {
  const url = `${BASE_URL}${path}`;
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    throw new ApiError(
      (body as { error?: string }).error ?? `HTTP ${res.status}`,
      res.status,
    );
  }

  const envelope = (await res.json()) as ApiResponse<T>;
  if (!envelope.success) {
    throw new ApiError(envelope.error ?? 'Unknown API error', res.status);
  }

  return envelope.data;
}

async function apiPost<T>(path: string, body?: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: 'POST',
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
}

async function apiPut<T>(path: string, body: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: 'PUT',
    body: JSON.stringify(body),
  });
}

async function apiPatch<T>(path: string, body: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: 'PATCH',
    body: JSON.stringify(body),
  });
}

async function apiDelete<T>(path: string): Promise<T> {
  return apiFetch<T>(path, { method: 'DELETE' });
}

// ─── Error Class ─────────────────────────────────────────────

export class ApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

// ─── Swarm Control ───────────────────────────────────────────

export async function getSwarmStatus(): Promise<SwarmStatus> {
  return apiFetch<SwarmStatus>('/status');
}

export async function pauseSwarm(): Promise<void> {
  await apiPost('/actions/pause');
}

export async function resumeSwarm(): Promise<void> {
  await apiPost('/actions/resume');
}

export async function triggerExit(): Promise<void> {
  await apiPost('/actions/exit');
}

export async function emergencyStop(): Promise<void> {
  await apiPost('/actions/emergency-stop');
}

export async function startSwarm(config: Partial<SwarmConfig>): Promise<void> {
  await apiPost('/swarm/start', config);
}

export async function updateSwarmStrategy(
  strategy: Partial<TradingStrategy>,
): Promise<void> {
  await apiPut('/config', { strategy });
}

// ─── Agents ──────────────────────────────────────────────────

export async function getAgents(): Promise<Agent[]> {
  return apiFetch<Agent[]>('/agents');
}

export async function getAgent(id: string): Promise<AgentDetail> {
  return apiFetch<AgentDetail>(`/agents/${id}`);
}

export async function updateAgent(
  id: string,
  patch: Partial<AgentDetail>,
): Promise<void> {
  await apiPatch(`/agents/${id}`, patch);
}

export async function pauseAgent(id: string): Promise<void> {
  await apiPost(`/agents/${id}/pause`);
}

export async function resumeAgent(id: string): Promise<void> {
  await apiPost(`/agents/${id}/resume`);
}

export async function stopAgent(id: string): Promise<void> {
  await apiPost(`/agents/${id}/stop`);
}

// ─── Wallets ─────────────────────────────────────────────────

export async function getWallets(): Promise<WalletInfo[]> {
  return apiFetch<WalletInfo[]>('/wallets');
}

export async function createWallets(
  count: number,
  options?: { prefix?: string; randomNames?: boolean },
): Promise<WalletInfo[]> {
  return apiPost<WalletInfo[]>('/wallets/create', { count, ...options });
}

export async function importWallets(keys: string[]): Promise<WalletInfo[]> {
  return apiPost<WalletInfo[]>('/wallets/import', { keys });
}

export async function updateWalletLabel(
  address: string,
  label: string,
): Promise<void> {
  await apiPatch(`/wallets/${address}/label`, { label });
}

export async function fundWallet(
  address: string,
  lamports: string,
): Promise<string> {
  const result = await apiPost<{ txSignature: string }>('/wallets/fund', {
    address,
    lamports,
  });
  return result.txSignature;
}

export async function splitFunding(
  sourceAddress: string,
  totalLamports: string,
  targets: FundingTarget[],
): Promise<string[]> {
  const result = await apiPost<{ signatures: string[] }>('/wallets/split-fund', {
    sourceAddress,
    totalLamports,
    targets,
  });
  return result.signatures;
}

export async function getWalletHistory(
  address: string,
): Promise<{ transactions: Array<{ signature: string; timestamp: number; direction: 'in' | 'out'; amountLamports: string; counterparty: string }> }> {
  return apiFetch(`/wallets/${address}/history`);
}

export async function exportWallets(
  format: 'json' | 'csv' | 'csv-full',
): Promise<Blob> {
  const res = await fetch(`${BASE_URL}/wallets/export?format=${format}`);
  if (!res.ok) throw new ApiError('Export failed', res.status);
  return res.blob();
}

// ─── Trades ──────────────────────────────────────────────────

export async function getTrades(options?: {
  limit?: number;
  offset?: number;
  agent?: string;
  direction?: 'buy' | 'sell';
}): Promise<{ trades: TradeEntry[]; total: number; hasMore: boolean }> {
  const params = new URLSearchParams();
  if (options?.limit) params.set('limit', String(options.limit));
  if (options?.offset) params.set('offset', String(options.offset));
  if (options?.agent) params.set('agent', options.agent);
  if (options?.direction) params.set('direction', options.direction);
  return apiFetch(`/trades?${params.toString()}`);
}

export async function manualTrade(
  walletAddress: string,
  direction: 'buy' | 'sell',
  amountLamports: string,
  opts?: { slippageBps?: number; priorityFeeMicroLamports?: number; useJito?: boolean },
): Promise<TradeResult> {
  return apiPost<TradeResult>('/trades/manual', {
    walletAddress,
    direction,
    amountLamports,
    slippageBps: opts?.slippageBps ?? 500,
    priorityFeeMicroLamports: opts?.priorityFeeMicroLamports ?? 100000,
    useJito: opts?.useJito ?? false,
  });
}

export async function multiTrade(request: {
  wallets: string[];
  direction: 'buy' | 'sell';
  amounts: string[];
  useJito: boolean;
  staggerMs?: number;
}): Promise<{ results: Array<{ walletAddress: string; success: boolean; signature?: string; error?: string }> }> {
  return apiPost('/trades/multi', request);
}

// ─── Chart Data ──────────────────────────────────────────────

export async function getChartHistory(options: {
  mint: string;
  resolution: number;
  from?: number;
  to?: number;
}): Promise<Array<{ time: number; open: number; high: number; low: number; close: number; volume: number; trades: number }>> {
  const params = new URLSearchParams();
  params.set('mint', options.mint);
  params.set('resolution', String(options.resolution));
  if (options.from) params.set('from', String(options.from));
  if (options.to) params.set('to', String(options.to));
  return apiFetch(`/chart/history?${params.toString()}`);
}

export async function getChartLatest(mint: string): Promise<{ price: number; marketCapSol: number; volume24h: number }> {
  return apiFetch(`/chart/latest?mint=${mint}`);
}

// ─── GMGN ────────────────────────────────────────────────────

export async function getGmgnWallets(mint: string): Promise<Array<{ address: string; score: number; lastDirection: 'buy' | 'sell'; lastAmountSol: number; lastTimestamp: number }>> {
  return apiFetch(`/gmgn/wallets?mint=${mint}`);
}

// ─── Wallet Tracking ─────────────────────────────────────────

export async function trackWallet(address: string, label: string): Promise<{ id: string }> {
  return apiPost('/wallets/track', { address, label });
}

export async function untrackWallet(address: string): Promise<void> {
  await apiDelete(`/wallets/track/${address}`);
}

export async function getTrackedWallets(): Promise<Array<{ id: string; address: string; label: string; color: string; source: string; addedAt: number }>> {
  return apiFetch('/wallets/tracked');
}

// ─── Burst Events ────────────────────────────────────────────

export async function getBurstEvents(): Promise<Array<{ id: string; triggerType: string; triggerValue: number; walletAddresses: string[]; amountPerWalletLamports: string; simultaneous: boolean; executedAt: number | null; createdAt: number }>> {
  return apiFetch('/bursts');
}

export async function createBurstEvent(event: {
  triggerType: string;
  triggerValue: number;
  walletAddresses: string[];
  amountPerWalletLamports: string;
  simultaneous: boolean;
}): Promise<{ id: string }> {
  return apiPost('/bursts', event);
}

export async function triggerBurstEvent(id: string): Promise<void> {
  await apiPost(`/bursts/${id}/trigger`);
}

// ─── Analytics Extended ──────────────────────────────────────

export async function getPnLTimeSeries(options?: { from?: number; to?: number; interval?: number }): Promise<Array<{ timestamp: number; realizedSol: number; unrealizedSol: number; totalSol: number }>> {
  const params = new URLSearchParams();
  if (options?.from) params.set('from', String(options.from));
  if (options?.to) params.set('to', String(options.to));
  if (options?.interval) params.set('interval', String(options.interval));
  return apiFetch(`/analytics/pnl/timeseries?${params.toString()}`);
}

export async function getAgentAnalytics(): Promise<Array<{ agentId: string; role: string; solSpent: number; solReceived: number; realizedPnl: number; unrealizedPnl: number; totalPnl: number; winRate: number; tradeCount: number }>> {
  return apiFetch('/analytics/agents');
}

export async function getVolumeHourly(): Promise<Array<{ hour: string; buyVolume: number; sellVolume: number; totalVolume: number; tradeCount: number }>> {
  return apiFetch('/analytics/volume/hourly');
}

export async function getCostBreakdown(): Promise<{ gasFeesSol: number; jitoTipsSol: number; totalExposureSol: number; projectedGas1hr: number; projectedJito1hr: number; projectedCapital1hr: number }> {
  return apiFetch('/analytics/costs');
}

export async function getTradesPaginated(options: {
  page: number;
  limit: number;
  direction?: 'buy' | 'sell';
  role?: string;
  agent?: string;
}): Promise<{ trades: TradeEntry[]; total: number; page: number; totalPages: number }> {
  const params = new URLSearchParams();
  params.set('page', String(options.page));
  params.set('limit', String(options.limit));
  if (options.direction) params.set('direction', options.direction);
  if (options.role) params.set('role', options.role);
  if (options.agent) params.set('agent', options.agent);
  return apiFetch(`/analytics/trades?${params.toString()}`);
}

export async function getWalletHoldings(): Promise<Array<{ address: string; label: string; solBalance: number; tokensHeld: number; supplyPercent: number; currentValueSol: number; entryCostSol: number; unrealizedPnl: number }>> {
  return apiFetch('/analytics/holdings');
}

// ─── Session Extended ────────────────────────────────────────

export async function saveCurrentSession(name: string): Promise<{ sessionId: string }> {
  return apiPost('/session/save', { name });
}

export async function listSessions(): Promise<Array<{ id: string; name: string; createdAt: number; phase: string; mint: string | null; totalTrades: number; pnlSol: number }>> {
  return apiFetch('/session/list');
}

export async function resumeSession(id: string): Promise<void> {
  await apiPost(`/session/${id}/resume`);
}

// ─── Analytics & P&L ─────────────────────────────────────────

export async function getAnalytics(): Promise<Analytics> {
  return apiFetch<Analytics>('/analytics');
}

export async function getPnL(): Promise<PnLData> {
  return apiFetch<PnLData>('/pnl');
}

export async function getSupplyDistribution(): Promise<SupplyDistribution> {
  return apiFetch<SupplyDistribution>('/supply');
}

// ─── Health ──────────────────────────────────────────────────

export async function getHealth(): Promise<HealthReport> {
  return apiFetch<HealthReport>('/health');
}

// ─── Events ──────────────────────────────────────────────────

export async function getEvents(options?: {
  limit?: number;
  offset?: number;
  category?: string;
  severity?: string;
  agent?: string;
}): Promise<{ events: TimelineEvent[]; total: number }> {
  const params = new URLSearchParams();
  if (options?.limit) params.set('limit', String(options.limit));
  if (options?.offset) params.set('offset', String(options.offset));
  if (options?.category) params.set('category', options.category);
  if (options?.severity) params.set('severity', options.severity);
  if (options?.agent) params.set('agent', options.agent);
  return apiFetch(`/events?${params.toString()}`);
}

// ─── Config ──────────────────────────────────────────────────

export async function getConfig(): Promise<{ config: SwarmConfig; schema: unknown }> {
  return apiFetch('/config');
}

export async function updateConfig(config: Partial<SwarmConfig>): Promise<{
  success: boolean;
  config: SwarmConfig;
  changes: string[];
  warnings: string[];
  errors: string[];
  requiresRestart: boolean;
}> {
  return apiPut('/config', config);
}

// ─── Templates ───────────────────────────────────────────────

export async function getTemplates(): Promise<Template[]> {
  return apiFetch<Template[]>('/templates');
}

export async function saveTemplate(
  template: Omit<Template, 'id' | 'createdAt' | 'updatedAt'>,
): Promise<Template> {
  return apiPost<Template>('/templates', template);
}

export async function loadTemplate(id: string): Promise<Template> {
  return apiFetch<Template>(`/templates/${id}`);
}

export async function deleteTemplate(id: string): Promise<void> {
  await apiDelete(`/templates/${id}`);
}

// ─── Session ─────────────────────────────────────────────────

export async function createSession(walletAddress: string): Promise<Session> {
  return apiPost<Session>('/session', { walletAddress });
}

export async function getSession(): Promise<Session | null> {
  try {
    return await apiFetch<Session>('/session');
  } catch {
    return null;
  }
}

// ─── Export ──────────────────────────────────────────────────

export async function exportAll(): Promise<Blob> {
  const res = await fetch(`${BASE_URL}/export/full`);
  if (!res.ok) throw new ApiError('Export failed', res.status);
  return res.blob();
}

// ─── Metadata ────────────────────────────────────────────────

export async function uploadMetadataImage(file: File): Promise<{ uri: string }> {
  const formData = new FormData();
  formData.append('image', file);
  const res = await fetch(`${BASE_URL}/metadata/upload`, {
    method: 'POST',
    body: formData,
  });
  if (!res.ok) throw new ApiError('Upload failed', res.status);
  const envelope = (await res.json()) as ApiResponse<{ uri: string }>;
  return envelope.data;
}

export async function generateNarrative(
  name: string,
  symbol: string,
  description: string,
): Promise<{ narrative: string }> {
  return apiPost<{ narrative: string }>('/narrative/generate', {
    name,
    symbol,
    description,
  });
}
