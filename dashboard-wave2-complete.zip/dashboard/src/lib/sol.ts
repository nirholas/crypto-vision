/** Bonding curve constants for Pump.fun */
export const BONDING_CURVE = {
  INITIAL_VIRTUAL_TOKEN_RESERVES: 1_073_000_000,
  INITIAL_VIRTUAL_SOL_RESERVES: 30,
  GRADUATION_THRESHOLD_SOL: 85,
  TOTAL_SUPPLY: 1_000_000_000,
} as const;

/** Estimate tokens received for a given SOL buy amount on bonding curve */
export function estimateTokensFromSol(
  solAmount: number,
  currentVirtualSolReserves = BONDING_CURVE.INITIAL_VIRTUAL_SOL_RESERVES,
  currentVirtualTokenReserves = BONDING_CURVE.INITIAL_VIRTUAL_TOKEN_RESERVES,
): number {
  // Constant product: k = x * y
  const k = currentVirtualSolReserves * currentVirtualTokenReserves;
  const newSolReserves = currentVirtualSolReserves + solAmount;
  const newTokenReserves = k / newSolReserves;
  return currentVirtualTokenReserves - newTokenReserves;
}

/** Estimate market cap in SOL given current virtual reserves */
export function estimateMarketCapSol(
  currentVirtualSolReserves = BONDING_CURVE.INITIAL_VIRTUAL_SOL_RESERVES,
  currentVirtualTokenReserves = BONDING_CURVE.INITIAL_VIRTUAL_TOKEN_RESERVES,
): number {
  const price = currentVirtualSolReserves / currentVirtualTokenReserves;
  return price * BONDING_CURVE.TOTAL_SUPPLY;
}

/** Estimate token price in SOL */
export function estimateTokenPrice(
  currentVirtualSolReserves = BONDING_CURVE.INITIAL_VIRTUAL_SOL_RESERVES,
  currentVirtualTokenReserves = BONDING_CURVE.INITIAL_VIRTUAL_TOKEN_RESERVES,
): number {
  return currentVirtualSolReserves / currentVirtualTokenReserves;
}

/** Calculate graduation progress (0-100) */
export function graduationProgress(currentVirtualSolReserves: number): number {
  const progress =
    ((currentVirtualSolReserves - BONDING_CURVE.INITIAL_VIRTUAL_SOL_RESERVES) /
      (BONDING_CURVE.GRADUATION_THRESHOLD_SOL - BONDING_CURVE.INITIAL_VIRTUAL_SOL_RESERVES)) *
    100;
  return Math.min(100, Math.max(0, progress));
}

/**
 * Simulate sequential buys on the bonding curve and return
 * the state after each buy (for bundle planner preview).
 */
export function simulateSequentialBuys(
  buys: Array<{ label: string; solAmount: number }>,
): Array<{
  label: string;
  solAmount: number;
  tokensReceived: number;
  marketCapSolAfter: number;
  priceAfter: number;
  virtualSolAfter: number;
  virtualTokenAfter: number;
}> {
  let solReserves = BONDING_CURVE.INITIAL_VIRTUAL_SOL_RESERVES;
  let tokenReserves = BONDING_CURVE.INITIAL_VIRTUAL_TOKEN_RESERVES;

  return buys.map((buy) => {
    const k = solReserves * tokenReserves;
    const newSolReserves = solReserves + buy.solAmount;
    const newTokenReserves = k / newSolReserves;
    const tokensReceived = tokenReserves - newTokenReserves;

    solReserves = newSolReserves;
    tokenReserves = newTokenReserves;

    return {
      label: buy.label,
      solAmount: buy.solAmount,
      tokensReceived,
      marketCapSolAfter: estimateMarketCapSol(solReserves, tokenReserves),
      priceAfter: estimateTokenPrice(solReserves, tokenReserves),
      virtualSolAfter: solReserves,
      virtualTokenAfter: tokenReserves,
    };
  });
}
