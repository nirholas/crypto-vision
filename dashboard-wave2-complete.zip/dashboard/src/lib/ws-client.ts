import type { DashboardEvent, DashboardEventType } from '@/types';

type EventHandler = (event: DashboardEvent) => void;

interface Subscription {
  id: string;
  eventType: DashboardEventType | '*';
  handler: EventHandler;
}

interface WSClientOptions {
  url: string;
  maxReconnectAttempts: number;
  initialReconnectDelayMs: number;
  maxReconnectDelayMs: number;
  heartbeatIntervalMs: number;
}

const DEFAULT_OPTIONS: WSClientOptions = {
  url: typeof window !== 'undefined'
    ? `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}/ws`
    : 'ws://localhost:3001/ws',
  maxReconnectAttempts: 50,
  initialReconnectDelayMs: 1000,
  maxReconnectDelayMs: 30000,
  heartbeatIntervalMs: 25000,
};

export class WSClient {
  private ws: WebSocket | null = null;
  private subscriptions: Map<string, Subscription> = new Map();
  private subCounter = 0;
  private reconnectAttempts = 0;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private options: WSClientOptions;
  private intentionalClose = false;
  private _isConnected = false;
  private connectionListeners: Set<(connected: boolean) => void> = new Set();

  constructor(options?: Partial<WSClientOptions>) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
  }

  get isConnected(): boolean {
    return this._isConnected;
  }

  connect(): void {
    if (this.ws?.readyState === WebSocket.OPEN) return;

    this.intentionalClose = false;

    try {
      this.ws = new WebSocket(this.options.url);
    } catch {
      this.scheduleReconnect();
      return;
    }

    this.ws.onopen = () => {
      this.reconnectAttempts = 0;
      this._isConnected = true;
      this.notifyConnectionListeners(true);
      this.startHeartbeat();

      // Subscribe to all event types we care about
      const eventTypes = this.getActiveEventTypes();
      if (eventTypes.length > 0) {
        this.sendMessage({ type: 'subscribe', events: eventTypes });
      }
    };

    this.ws.onmessage = (event: MessageEvent) => {
      this.handleMessage(event);
    };

    this.ws.onclose = () => {
      this._isConnected = false;
      this.notifyConnectionListeners(false);
      this.stopHeartbeat();
      if (!this.intentionalClose) {
        this.scheduleReconnect();
      }
    };

    this.ws.onerror = () => {
      // onclose will fire after this
    };
  }

  disconnect(): void {
    this.intentionalClose = true;
    this._isConnected = false;
    this.notifyConnectionListeners(false);

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.stopHeartbeat();

    if (this.ws) {
      this.ws.close(1000, 'Client disconnect');
      this.ws = null;
    }
  }

  on(eventType: DashboardEventType | '*', handler: EventHandler): string {
    const id = `sub_${++this.subCounter}`;
    this.subscriptions.set(id, { id, eventType, handler });
    return id;
  }

  off(subscriptionId: string): void {
    this.subscriptions.delete(subscriptionId);
  }

  onConnectionChange(listener: (connected: boolean) => void): () => void {
    this.connectionListeners.add(listener);
    return () => {
      this.connectionListeners.delete(listener);
    };
  }

  private handleMessage(event: MessageEvent): void {
    let parsed: DashboardEvent | { type: 'ping' };
    try {
      parsed = JSON.parse(event.data as string);
    } catch {
      return;
    }

    if ('type' in parsed && parsed.type === 'ping') {
      this.sendMessage({ type: 'pong' });
      return;
    }

    const dashboardEvent = parsed as DashboardEvent;

    for (const sub of this.subscriptions.values()) {
      if (sub.eventType === '*' || sub.eventType === dashboardEvent.type) {
        try {
          sub.handler(dashboardEvent);
        } catch (err) {
          console.error('[WSClient] Handler error:', err);
        }
      }
    }
  }

  private sendMessage(msg: Record<string, unknown>): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
    }
  }

  private getActiveEventTypes(): string[] {
    const types = new Set<string>();
    for (const sub of this.subscriptions.values()) {
      if (sub.eventType !== '*') {
        types.add(sub.eventType);
      }
    }
    return Array.from(types);
  }

  private scheduleReconnect(): void {
    if (this.reconnectAttempts >= this.options.maxReconnectAttempts) {
      console.error('[WSClient] Max reconnect attempts reached');
      return;
    }

    const delay = Math.min(
      this.options.initialReconnectDelayMs * Math.pow(2, this.reconnectAttempts),
      this.options.maxReconnectDelayMs,
    );

    // Add jitter: ±25%
    const jitter = delay * 0.25 * (Math.random() * 2 - 1);
    const finalDelay = Math.round(delay + jitter);

    this.reconnectTimer = setTimeout(() => {
      this.reconnectAttempts++;
      this.connect();
    }, finalDelay);
  }

  private startHeartbeat(): void {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      this.sendMessage({ type: 'pong' });
    }, this.options.heartbeatIntervalMs);
  }

  private stopHeartbeat(): void {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  private notifyConnectionListeners(connected: boolean): void {
    for (const listener of this.connectionListeners) {
      try {
        listener(connected);
      } catch (err) {
        console.error('[WSClient] Connection listener error:', err);
      }
    }
  }
}

// ─── Singleton ───────────────────────────────────────────────

let _instance: WSClient | null = null;

export function getWSClient(): WSClient {
  if (!_instance) {
    _instance = new WSClient();
  }
  return _instance;
}
