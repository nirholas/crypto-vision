import type { TradingStrategy, PresetStrategy } from '@/types';

const LAMPORTS_PER_SOL = 1_000_000_000;
const sol = (n: number) => (n * LAMPORTS_PER_SOL).toString();

export const STRATEGY_ORGANIC: TradingStrategy = {
  id: 'organic',
  name: 'Organic Growth',
  minIntervalSeconds: 30,
  maxIntervalSeconds: 120,
  minTradeSizeLamports: sol(0.01),
  maxTradeSizeLamports: sol(0.05),
  buySellRatio: 1.4,
  maxTotalBudgetLamports: sol(2),
  useJitoBundles: false,
  priorityFeeMicroLamports: 5000,
};

export const STRATEGY_VOLUME: TradingStrategy = {
  id: 'volume',
  name: 'Volume Boost',
  minIntervalSeconds: 5,
  maxIntervalSeconds: 20,
  minTradeSizeLamports: sol(0.02),
  maxTradeSizeLamports: sol(0.1),
  buySellRatio: 1.0,
  maxTotalBudgetLamports: sol(5),
  useJitoBundles: true,
  priorityFeeMicroLamports: 10000,
};

export const STRATEGY_GRADUATION: TradingStrategy = {
  id: 'graduation',
  name: 'Graduation Push',
  minIntervalSeconds: 3,
  maxIntervalSeconds: 10,
  minTradeSizeLamports: sol(0.1),
  maxTradeSizeLamports: sol(0.5),
  buySellRatio: 9.0,
  maxTotalBudgetLamports: sol(20),
  useJitoBundles: true,
  priorityFeeMicroLamports: 50000,
};

export const STRATEGY_EXIT: TradingStrategy = {
  id: 'exit',
  name: 'Exit Strategy',
  minIntervalSeconds: 10,
  maxIntervalSeconds: 30,
  minTradeSizeLamports: sol(0.05),
  maxTradeSizeLamports: sol(0.3),
  buySellRatio: 0.1,
  maxTotalBudgetLamports: sol(0),
  useJitoBundles: false,
  priorityFeeMicroLamports: 20000,
};

export const PRESET_STRATEGIES: PresetStrategy[] = [
  {
    name: 'organic',
    label: 'Organic Growth',
    description: 'Slow and natural 70/30 buy/sell ratio. Small trades, long intervals.',
    strategy: STRATEGY_ORGANIC,
  },
  {
    name: 'volume',
    label: 'Volume Boost',
    description: 'Balanced 50/50 buy/sell with Jito bundles. Fast intervals.',
    strategy: STRATEGY_VOLUME,
  },
  {
    name: 'graduation',
    label: 'Graduation Push',
    description: '90% buy pressure to push toward AMM graduation.',
    strategy: STRATEGY_GRADUATION,
  },
  {
    name: 'custom',
    label: 'Custom',
    description: 'Configure every parameter manually.',
    strategy: STRATEGY_ORGANIC,
  },
];

export function getPresetStrategy(name: string): TradingStrategy {
  const found = PRESET_STRATEGIES.find((p) => p.name === name);
  return found?.strategy ?? STRATEGY_ORGANIC;
}
