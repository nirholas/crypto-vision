'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useWallet } from '@solana/wallet-adapter-react';
import {
  Home,
  Waves,
  Wallet,
  Settings,
  BarChart3,
  TrendingUp,
  LogOut,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { truncateAddress, formatLamportsAsSol } from '@/lib/formatters';
import { useWalletStore } from '@/stores/wallet.store';

const navItems = [
  { href: '/dashboard', label: 'Overview', icon: Home },
  { href: '/dashboard/swarm', label: 'Swarm Control', icon: Waves },
  { href: '/dashboard/wallets', label: 'Wallets', icon: Wallet },
  { href: '/dashboard/configure', label: 'Configure', icon: Settings },
  { href: '/dashboard/charts', label: 'Charts', icon: BarChart3 },
  { href: '/dashboard/analytics', label: 'Analytics', icon: TrendingUp },
];

export function Sidebar() {
  const pathname = usePathname();
  const { disconnect, publicKey } = useWallet();
  const balance = useWalletStore((s) => s.connectedWalletBalanceLamports);

  const walletAddress = publicKey?.toBase58() ?? '';

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-60 bg-sidebar border-r border-border-subtle flex flex-col">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-border-subtle">
        <div className="flex items-center gap-2">
          <span className="text-xl font-mono font-bold text-text-primary tracking-tighter">
            SWARM
          </span>
          <span className="text-xl font-mono font-bold text-brand-green">
            OS
          </span>
          <span className="w-2 h-5 bg-brand-green animate-pulse rounded-sm" />
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive =
            pathname === item.href ||
            (item.href !== '/dashboard' && pathname.startsWith(item.href));

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors',
                isActive
                  ? 'bg-brand-green/10 text-brand-green border-l-2 border-brand-green'
                  : 'text-text-secondary hover:text-text-primary hover:bg-surface/50',
              )}
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* Wallet info */}
      <div className="px-4 py-4 border-t border-border-subtle space-y-3">
        {walletAddress && (
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-brand-green animate-pulse" />
            <span className="text-xs font-mono text-text-secondary">
              {truncateAddress(walletAddress)}
            </span>
          </div>
        )}
        <div className="text-xs text-text-muted">
          {formatLamportsAsSol(balance, 2)}
        </div>
        <button
          onClick={() => disconnect()}
          className="flex items-center gap-2 text-xs text-text-muted hover:text-brand-red transition-colors w-full"
        >
          <LogOut className="w-3 h-3" />
          Disconnect
        </button>
      </div>
    </aside>
  );
}
