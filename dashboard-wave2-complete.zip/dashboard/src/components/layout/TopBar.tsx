'use client';

import { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { AlertTriangle, ExternalLink, OctagonX } from 'lucide-react';
import { useSwarmStore } from '@/stores/swarm.store';
import { useWalletStore } from '@/stores/wallet.store';
import {
  formatPhase,
  phaseColor,
  phaseBgColor,
  formatElapsed,
  formatSol,
  truncateAddress,
} from '@/lib/formatters';
import { emergencyStop } from '@/lib/api';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const routeNames: Record<string, string> = {
  '/dashboard': 'Overview',
  '/dashboard/swarm': 'Swarm Control',
  '/dashboard/wallets': 'Wallets',
  '/dashboard/configure': 'Configure',
  '/dashboard/charts': 'Charts',
  '/dashboard/analytics': 'Analytics',
};

export function TopBar() {
  const pathname = usePathname();
  const phase = useSwarmStore((s) => s.phase);
  const isRunning = useSwarmStore((s) => s.isRunning);
  const pnl = useSwarmStore((s) => s.currentPnlSol);
  const mint = useSwarmStore((s) => s.mint);
  const uptime = useSwarmStore((s) => s.uptime);
  const lowWallets = useWalletStore((s) => s.getLowBalanceWallets());

  const [elapsed, setElapsed] = useState(uptime);

  useEffect(() => {
    setElapsed(uptime);
    if (!isRunning) return;

    const interval = setInterval(() => {
      setElapsed((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [uptime, isRunning]);

  const handleEmergencyStop = async () => {
    if (!confirm('EMERGENCY STOP: This will immediately halt ALL trading activity. Continue?')) return;
    try {
      await emergencyStop();
      toast.success('Emergency stop executed');
    } catch {
      toast.error('Failed to execute emergency stop');
    }
  };

  const breadcrumb = routeNames[pathname] ?? 'Dashboard';

  return (
    <header className="fixed top-0 left-60 right-0 z-30 h-14 bg-sidebar/95 backdrop-blur-sm border-b border-border-subtle flex items-center justify-between px-6">
      {/* Left: Breadcrumb */}
      <div className="text-sm font-medium text-text-secondary">{breadcrumb}</div>

      {/* Center: Phase pill */}
      <div className="flex items-center gap-3">
        <div
          className={cn(
            'flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono font-semibold',
            phaseBgColor(phase),
            phaseColor(phase),
          )}
        >
          <span
            className={cn(
              'w-2 h-2 rounded-full',
              phase === 'trading' || phase === 'creating'
                ? 'animate-pulse'
                : '',
              phase === 'trading'
                ? 'bg-brand-green'
                : phase === 'creating' || phase === 'bundling'
                  ? 'bg-yellow-400'
                  : phase === 'exiting'
                    ? 'bg-brand-red'
                    : phase === 'paused'
                      ? 'bg-warning'
                      : 'bg-zinc-500',
            )}
          />
          {formatPhase(phase)}
          {isRunning && (
            <span className="text-text-muted ml-1">
              {formatElapsed(elapsed)}
            </span>
          )}
        </div>
      </div>

      {/* Right: Mint, P&L, alerts, emergency */}
      <div className="flex items-center gap-4">
        {mint && (
          <a
            href={`https://dexscreener.com/solana/${mint}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-xs font-mono text-text-muted hover:text-brand-green transition-colors"
          >
            {truncateAddress(mint, 4)}
            <ExternalLink className="w-3 h-3" />
          </a>
        )}

        <div
          className={cn(
            'text-sm font-mono font-semibold',
            pnl >= 0 ? 'text-brand-green' : 'text-brand-red',
          )}
        >
          {pnl >= 0 ? '+' : ''}
          {formatSol(pnl)} {pnl >= 0 ? '↑' : '↓'}
        </div>

        {lowWallets.length > 0 && (
          <div className="relative">
            <AlertTriangle className="w-4 h-4 text-warning" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-warning text-bg text-[8px] font-bold rounded-full flex items-center justify-center">
              {lowWallets.length}
            </span>
          </div>
        )}

        {isRunning && (
          <button
            onClick={handleEmergencyStop}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-brand-red/20 hover:bg-brand-red/30 text-brand-red text-xs font-semibold rounded-md transition-colors"
          >
            <OctagonX className="w-3.5 h-3.5" />
            STOP
          </button>
        )}
      </div>
    </header>
  );
}
