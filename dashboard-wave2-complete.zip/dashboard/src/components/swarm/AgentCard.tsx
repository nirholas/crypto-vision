'use client';

import { useRef, useEffect, useCallback } from 'react';
import { Pause, Play, Settings, ArrowUpDown, MoreHorizontal } from 'lucide-react';
import { pauseAgent, resumeAgent } from '@/lib/api';
import { formatSol, truncateAddress, relativeTime, statusColor, formatPercent } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import type { Agent, AgentType } from '@/types';

const agentTypeIcons: Record<string, string> = {
  creator: '🏗️', trader: '📈', 'market-maker': '⚖️', volume: '🔊',
  accumulator: '🧲', exit: '🚪', sentinel: '🛡️', scanner: '🔍',
  narrative: '📝', sniper: '🎯', stability: '⚙️',
};

interface Props {
  agent: Agent;
  onEdit: (id: string) => void;
  onManualTrade: (walletAddress: string) => void;
  recentTrades?: Array<{ direction: 'buy' | 'sell'; timestamp: number }>;
}

export function AgentCard({ agent, onEdit, onManualTrade, recentTrades = [] }: Props) {
  const sparkRef = useRef<HTMLCanvasElement>(null);

  // Draw activity sparkline
  useEffect(() => {
    const canvas = sparkRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const now = Date.now();
    const windowMs = 60_000; // last 60s
    const buckets = 30;
    const bucketMs = windowMs / buckets;
    const counts = new Array(buckets).fill(0);
    const dirs: Array<'buy' | 'sell' | null> = new Array(buckets).fill(null);

    for (const t of recentTrades) {
      const age = now - t.timestamp;
      if (age > windowMs || age < 0) continue;
      const idx = Math.min(buckets - 1, Math.floor((windowMs - age) / bucketMs));
      counts[idx]++;
      dirs[idx] = t.direction;
    }

    const maxCount = Math.max(1, ...counts);
    const barW = w / buckets;

    for (let i = 0; i < buckets; i++) {
      if (counts[i] === 0) continue;
      const barH = (counts[i] / maxCount) * h;
      ctx.fillStyle = dirs[i] === 'sell' ? '#ff336680' : '#00ff8880';
      ctx.fillRect(i * barW, h - barH, barW - 1, barH);
    }
  }, [recentTrades]);

  const handlePauseResume = useCallback(async () => {
    try {
      if (agent.status === 'active') {
        await pauseAgent(agent.id);
        toast.success(`${agent.id} paused`);
      } else if (agent.status === 'paused') {
        await resumeAgent(agent.id);
        toast.success(`${agent.id} resumed`);
      }
    } catch {
      toast.error('Failed to update agent');
    }
  }, [agent.id, agent.status]);

  const balanceColor =
    agent.solBalance > 0.1 ? 'text-brand-green' :
    agent.solBalance > 0.05 ? 'text-warning' : 'text-brand-red';

  const borderColor =
    agent.status === 'active' ? 'border-brand-green/20 glow-green' :
    agent.status === 'paused' ? 'border-warning/30' :
    agent.status === 'error' ? 'border-brand-red/30' : 'border-border-subtle';

  return (
    <div className={cn(
      'relative bg-bg border rounded-lg p-4 transition-all',
      borderColor,
      agent.status === 'paused' && 'opacity-70',
    )}>
      {agent.status === 'paused' && (
        <div className="absolute top-2 right-2 bg-warning/20 text-warning text-[10px] font-bold px-1.5 py-0.5 rounded">PAUSED</div>
      )}

      {/* Header */}
      <div className="flex items-center gap-2 mb-3">
        <span className="text-lg">{agentTypeIcons[agent.type] ?? '🤖'}</span>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-mono font-semibold text-text-primary truncate">{agent.id}</div>
          <div className="text-[10px] text-text-muted font-mono">{truncateAddress(agent.walletAddress, 6)}</div>
        </div>
        <span className={cn('w-2 h-2 rounded-full flex-shrink-0',
          agent.status === 'active' ? 'bg-brand-green animate-pulse' :
          agent.status === 'paused' ? 'bg-warning' :
          agent.status === 'error' ? 'bg-brand-red animate-pulse' : 'bg-zinc-600'
        )} />
      </div>

      {/* Metrics grid */}
      <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs mb-3">
        <MetricRow label="SOL" value={formatSol(agent.solBalance)} valueClass={balanceColor} />
        <MetricRow label="Tokens" value={agent.tokenBalance.toLocaleString()} />
        <MetricRow label="Trades" value={String(agent.tradeCount)} />
        <MetricRow
          label="P&L"
          value={`${agent.pnl >= 0 ? '+' : ''}${agent.pnl.toFixed(4)}`}
          valueClass={agent.pnl >= 0 ? 'text-brand-green' : 'text-brand-red'}
        />
      </div>

      {/* Last action */}
      {agent.lastAction && (
        <div className="text-[10px] text-text-muted mb-2 truncate">
          Last: {agent.lastAction}
        </div>
      )}

      {/* Activity sparkline */}
      <canvas
        ref={sparkRef}
        width={180}
        height={20}
        className="w-full h-5 rounded bg-surface/50 mb-3"
      />

      {/* Controls */}
      <div className="flex items-center gap-1.5">
        <button
          onClick={handlePauseResume}
          className={cn(
            'flex items-center gap-1 px-2 py-1 text-[10px] font-semibold rounded transition-colors',
            agent.status === 'active'
              ? 'bg-warning/20 text-warning hover:bg-warning/30'
              : 'bg-brand-green/20 text-brand-green hover:bg-brand-green/30',
          )}
        >
          {agent.status === 'active' ? <><Pause className="w-3 h-3" /> Pause</> : <><Play className="w-3 h-3" /> Resume</>}
        </button>
        <button
          onClick={() => onEdit(agent.id)}
          className="flex items-center gap-1 px-2 py-1 text-[10px] text-text-muted hover:text-text-primary rounded bg-surface hover:bg-surface/80 transition-colors"
        >
          <Settings className="w-3 h-3" /> Edit
        </button>
        <button
          onClick={() => onManualTrade(agent.walletAddress)}
          className="flex items-center gap-1 px-2 py-1 text-[10px] text-text-muted hover:text-text-primary rounded bg-surface hover:bg-surface/80 transition-colors"
        >
          <ArrowUpDown className="w-3 h-3" /> Trade
        </button>
      </div>
    </div>
  );
}

function MetricRow({ label, value, valueClass }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-text-muted">{label}</span>
      <span className={cn('font-mono', valueClass ?? 'text-text-secondary')}>{value}</span>
    </div>
  );
}
