'use client';

import { useState, useEffect, useCallback } from 'react';
import { X } from 'lucide-react';
import { getAgent, updateAgent, pauseAgent, stopAgent } from '@/lib/api';
import { useAgentStore } from '@/stores/agent.store';
import { formatSol, truncateAddress, formatPercent, formatElapsed, statusColor } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import type { AgentDetail, TraderPersonality } from '@/types';

interface Props {
  agentId: string;
  onClose: () => void;
}

export function AgentEditModal({ agentId, onClose }: Props) {
  const [tab, setTab] = useState<'strategy' | 'personality' | 'risk' | 'info'>('personality');
  const [detail, setDetail] = useState<AgentDetail | null>(null);
  const [personality, setPersonality] = useState<TraderPersonality>({
    aggression: 0.5, timingVariance: 0.5, sizeVariance: 0.5,
    trendFollowing: 0.5, maxPositionPercent: 50, naturalSizing: true,
  });
  const [minInterval, setMinInterval] = useState(30);
  const [maxInterval, setMaxInterval] = useState(120);
  const [buySellRatio, setBuySellRatio] = useState(1.4);
  const [stopLossSol, setStopLossSol] = useState('');
  const [maxTrades, setMaxTrades] = useState('');
  const setAgentDetail = useAgentStore((s) => s.setAgentDetail);

  useEffect(() => {
    getAgent(agentId).then((d) => {
      setDetail(d);
      setPersonality(d.personality);
    }).catch(() => toast.error('Failed to load agent'));
  }, [agentId]);

  const handleApply = useCallback(async () => {
    try {
      await updateAgent(agentId, { personality } as Partial<AgentDetail>);
      if (detail) {
        const updated = { ...detail, personality };
        setAgentDetail(agentId, updated);
      }
      toast.success('Changes applied');
    } catch {
      toast.error('Failed to apply changes');
    }
  }, [agentId, personality, detail, setAgentDetail]);

  const handlePause = useCallback(async () => {
    try { await pauseAgent(agentId); toast.success('Agent paused'); } catch { toast.error('Failed'); }
  }, [agentId]);

  const handleStop = useCallback(async () => {
    if (!confirm(`Stop agent ${agentId}? This cannot be undone.`)) return;
    try { await stopAgent(agentId); toast.success('Agent stopped'); onClose(); } catch { toast.error('Failed'); }
  }, [agentId, onClose]);

  if (!detail) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
        <div className="bg-surface border border-border-subtle rounded-xl p-8">
          <div className="text-sm text-text-muted">Loading agent...</div>
        </div>
      </div>
    );
  }

  const nextTradeMin = Math.round(minInterval * (1 - personality.timingVariance * 0.3));
  const nextTradeMax = Math.round(maxInterval * (1 + personality.timingVariance * 0.3));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-surface border border-border-subtle rounded-xl w-full max-w-2xl mx-4 max-h-[85vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border-subtle sticky top-0 bg-surface z-10">
          <div className="flex items-center gap-3">
            <span className="text-lg font-mono font-bold text-text-primary">{detail.id}</span>
            <span className={cn('text-xs px-2 py-0.5 rounded-full', statusColor(detail.status))}>{detail.status}</span>
          </div>
          <button onClick={onClose} className="text-text-muted hover:text-text-primary"><X className="w-5 h-5" /></button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 px-6 pt-4">
          {(['personality', 'strategy', 'risk', 'info'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn('px-4 py-2 text-sm font-medium rounded-md capitalize', tab === t ? 'bg-brand-green/10 text-brand-green' : 'text-text-muted hover:text-text-secondary')}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="px-6 py-5 space-y-5">
          {tab === 'personality' && (
            <>
              <PersonalitySlider label="Aggression" sublabel="Conservative → Aggressive" value={personality.aggression} onChange={(v) => setPersonality({ ...personality, aggression: v })} />
              <PersonalitySlider label="Timing Variance" sublabel="Consistent → Random" value={personality.timingVariance} onChange={(v) => setPersonality({ ...personality, timingVariance: v })} />
              <PersonalitySlider label="Size Variance" sublabel="Fixed sizes → Random sizes" value={personality.sizeVariance} onChange={(v) => setPersonality({ ...personality, sizeVariance: v })} />
              <PersonalitySlider label="Trend Following" sublabel="Contrarian → Momentum" value={personality.trendFollowing} onChange={(v) => setPersonality({ ...personality, trendFollowing: v })} />
              <PersonalitySlider label="Max Position %" sublabel="% of budget" value={personality.maxPositionPercent / 100} onChange={(v) => setPersonality({ ...personality, maxPositionPercent: Math.round(v * 100) })} />
              <label className="flex items-center gap-2 text-sm text-text-secondary">
                <input type="checkbox" checked={personality.naturalSizing} onChange={() => setPersonality({ ...personality, naturalSizing: !personality.naturalSizing })} className="rounded accent-brand-green" />
                Natural Sizing (avoid round numbers)
              </label>
              <div className="bg-bg rounded-md p-3 text-xs text-text-muted">
                At current settings, next trade expected in {nextTradeMin}–{nextTradeMax}s
              </div>
            </>
          )}

          {tab === 'strategy' && (
            <div className="space-y-4">
              <SliderField label="Min Interval (s)" value={minInterval} onChange={setMinInterval} min={1} max={600} />
              <SliderField label="Max Interval (s)" value={maxInterval} onChange={setMaxInterval} min={1} max={600} />
              <SliderField label="Buy/Sell Ratio" value={buySellRatio} onChange={setBuySellRatio} min={0.1} max={9} step={0.1} />
            </div>
          )}

          {tab === 'risk' && (
            <div className="space-y-4">
              <div>
                <label className="text-sm text-text-secondary block mb-1">Stop if P&L drops below (SOL)</label>
                <input value={stopLossSol} onChange={(e) => setStopLossSol(e.target.value)} placeholder="-1.0" className="input-field" />
              </div>
              <div>
                <label className="text-sm text-text-secondary block mb-1">Max trades (stop after)</label>
                <input value={maxTrades} onChange={(e) => setMaxTrades(e.target.value)} placeholder="500" className="input-field" />
              </div>
            </div>
          )}

          {tab === 'info' && (
            <div className="space-y-3 text-sm">
              <InfoRow label="Wallet" value={detail.walletAddress} mono />
              <InfoRow label="Role" value={detail.role} />
              <InfoRow label="Trades" value={String(detail.tradeCount)} />
              <InfoRow label="Total P&L" value={formatSol(detail.pnl)} color={detail.pnl >= 0 ? 'text-brand-green' : 'text-brand-red'} />
              <InfoRow label="Win Rate" value={formatPercent(detail.performance.winRate)} />
              <InfoRow label="Max Drawdown" value={formatPercent(detail.performance.maxDrawdown)} />
              <InfoRow label="Sharpe Ratio" value={detail.performance.sharpeRatio.toFixed(2)} />
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 px-6 py-4 border-t border-border-subtle sticky bottom-0 bg-surface">
          <button onClick={handleApply} className="px-4 py-2 bg-brand-green text-bg text-sm font-semibold rounded-md hover:bg-brand-green/90 transition-colors">Apply Changes</button>
          <button onClick={handlePause} className="px-4 py-2 bg-warning/20 text-warning text-sm font-semibold rounded-md hover:bg-warning/30 transition-colors">Pause</button>
          <button onClick={handleStop} className="px-4 py-2 bg-brand-red/20 text-brand-red text-sm font-semibold rounded-md hover:bg-brand-red/30 transition-colors">Stop</button>
          <button onClick={onClose} className="ml-auto px-4 py-2 text-sm text-text-muted hover:text-text-primary transition-colors">Cancel</button>
        </div>
      </div>
    </div>
  );
}

function PersonalitySlider({ label, sublabel, value, onChange }: { label: string; sublabel: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="text-sm text-text-secondary">{label}</span>
        <span className="text-sm font-mono text-text-primary">{value.toFixed(2)}</span>
      </div>
      <input type="range" min={0} max={1} step={0.01} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full accent-brand-green" />
      <div className="text-[10px] text-text-muted mt-0.5">{sublabel}</div>
    </div>
  );
}

function SliderField({ label, value, onChange, min, max, step }: { label: string; value: number; onChange: (v: number) => void; min: number; max: number; step?: number }) {
  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="text-sm text-text-secondary">{label}</span>
        <span className="text-sm font-mono text-text-primary">{value}</span>
      </div>
      <input type="range" min={min} max={max} step={step ?? 1} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full accent-brand-green" />
    </div>
  );
}

function InfoRow({ label, value, mono, color }: { label: string; value: string; mono?: boolean; color?: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-text-muted">{label}</span>
      <span className={cn(mono && 'font-mono text-xs', color ?? 'text-text-primary')}>{value}</span>
    </div>
  );
}
