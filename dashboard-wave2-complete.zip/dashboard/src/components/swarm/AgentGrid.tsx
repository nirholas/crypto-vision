'use client';

import { useState, useMemo } from 'react';
import { useAgentStore } from '@/stores/agent.store';
import { AgentCard } from './AgentCard';
import type { Agent } from '@/types';

type SortKey = 'pnl' | 'activity' | 'balance' | 'role' | 'status';

interface Props {
  onEditAgent: (id: string) => void;
  onManualTrade: (walletAddress: string) => void;
  agentTradeMap: Record<string, Array<{ direction: 'buy' | 'sell'; timestamp: number }>>;
}

export function AgentGrid({ onEditAgent, onManualTrade, agentTradeMap }: Props) {
  const agents = useAgentStore((s) => s.agents);
  const [sortKey, setSortKey] = useState<SortKey>('status');

  const sorted = useMemo(() => {
    const arr = [...agents];
    switch (sortKey) {
      case 'pnl': arr.sort((a, b) => b.pnl - a.pnl); break;
      case 'activity': arr.sort((a, b) => b.tradeCount - a.tradeCount); break;
      case 'balance': arr.sort((a, b) => b.solBalance - a.solBalance); break;
      case 'role': arr.sort((a, b) => a.type.localeCompare(b.type)); break;
      case 'status': {
        const order: Record<string, number> = { active: 0, paused: 1, error: 2, idle: 3, stopped: 4 };
        arr.sort((a, b) => (order[a.status] ?? 9) - (order[b.status] ?? 9));
        break;
      }
    }
    return arr;
  }, [agents, sortKey]);

  const sortButtons: Array<{ key: SortKey; label: string }> = [
    { key: 'status', label: 'Status' },
    { key: 'pnl', label: 'P&L' },
    { key: 'activity', label: 'Activity' },
    { key: 'balance', label: 'Balance' },
    { key: 'role', label: 'Role' },
  ];

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <span className="text-xs text-text-muted">Sort by:</span>
        {sortButtons.map((btn) => (
          <button
            key={btn.key}
            onClick={() => setSortKey(btn.key)}
            className={`text-xs px-2 py-1 rounded transition-colors ${
              sortKey === btn.key ? 'bg-brand-green/10 text-brand-green' : 'text-text-muted hover:text-text-secondary'
            }`}
          >
            {btn.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {sorted.map((agent) => (
          <AgentCard
            key={agent.id}
            agent={agent}
            onEdit={onEditAgent}
            onManualTrade={onManualTrade}
            recentTrades={agentTradeMap[agent.id] ?? []}
          />
        ))}
      </div>

      {agents.length === 0 && (
        <div className="text-sm text-text-muted text-center py-12">
          No agents running. Configure and launch the swarm to see agents here.
        </div>
      )}
    </div>
  );
}
