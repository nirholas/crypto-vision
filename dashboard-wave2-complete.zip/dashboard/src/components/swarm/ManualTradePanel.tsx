'use client';

import { useState, useMemo, useCallback } from 'react';
import { AlertTriangle } from 'lucide-react';
import { useWalletStore } from '@/stores/wallet.store';
import { manualTrade, multiTrade, triggerBurstEvent, getBurstEvents } from '@/lib/api';
import { formatSol, formatLamportsAsSol, solToLamports, lamportsToSol } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import type { BurstEventRuntime } from '@/types';

interface Props {
  preselectedWallet?: string;
}

type Tab = 'single' | 'multi' | 'burst' | 'emergency';

export function ManualTradePanel({ preselectedWallet }: Props) {
  const [tab, setTab] = useState<Tab>('single');
  const wallets = useWalletStore((s) => s.wallets);

  return (
    <div className="bg-surface/50 border border-border-subtle rounded-lg overflow-hidden h-full flex flex-col">
      <div className="flex border-b border-border-subtle">
        {(['single', 'multi', 'burst', 'emergency'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              'flex-1 py-2 text-xs font-medium transition-colors capitalize',
              tab === t ? 'bg-brand-green/10 text-brand-green border-b-2 border-brand-green' : 'text-text-muted hover:text-text-secondary',
              t === 'emergency' && 'text-brand-red',
            )}
          >
            {t === 'emergency' ? '⚠ Sell All' : t}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {tab === 'single' && <SingleTradeTab wallets={wallets} preselected={preselectedWallet} />}
        {tab === 'multi' && <MultiTradeTab wallets={wallets} />}
        {tab === 'burst' && <BurstTab />}
        {tab === 'emergency' && <EmergencySellTab wallets={wallets} />}
      </div>
    </div>
  );
}

function SingleTradeTab({ wallets, preselected }: { wallets: Array<{ address: string; label: string; balanceLamports: string }>; preselected?: string }) {
  const [wallet, setWallet] = useState(preselected ?? wallets[0]?.address ?? '');
  const [direction, setDirection] = useState<'buy' | 'sell'>('buy');
  const [amountSol, setAmountSol] = useState('0.05');
  const [slippage, setSlippage] = useState(500);
  const [isExecuting, setIsExecuting] = useState(false);

  const handleExecute = useCallback(async () => {
    setIsExecuting(true);
    try {
      const result = await manualTrade(wallet, direction, solToLamports(parseFloat(amountSol)), { slippageBps: slippage });
      if (result.success) {
        toast.success(`${direction.toUpperCase()} executed: ${result.signature.slice(0, 8)}...`);
      } else {
        toast.error(result.error ?? 'Trade failed');
      }
    } catch {
      toast.error('Trade execution failed');
    } finally {
      setIsExecuting(false);
    }
  }, [wallet, direction, amountSol, slippage]);

  return (
    <div className="space-y-4">
      <h4 className="text-xs font-semibold text-text-secondary uppercase tracking-wider">Manual Trade</h4>
      <div>
        <label className="text-xs text-text-muted block mb-1">Wallet</label>
        <select value={wallet} onChange={(e) => setWallet(e.target.value)} className="input-field text-xs">
          {wallets.map((w) => (
            <option key={w.address} value={w.address}>{w.label} ({formatLamportsAsSol(w.balanceLamports, 2)})</option>
          ))}
        </select>
      </div>
      <div className="flex gap-2">
        <button onClick={() => setDirection('buy')} className={cn('flex-1 py-2 text-xs font-bold rounded', direction === 'buy' ? 'bg-brand-green/20 text-brand-green' : 'bg-bg text-text-muted')}>BUY</button>
        <button onClick={() => setDirection('sell')} className={cn('flex-1 py-2 text-xs font-bold rounded', direction === 'sell' ? 'bg-brand-red/20 text-brand-red' : 'bg-bg text-text-muted')}>SELL</button>
      </div>
      <div>
        <label className="text-xs text-text-muted block mb-1">Amount (SOL)</label>
        <input value={amountSol} onChange={(e) => setAmountSol(e.target.value)} type="number" step="0.01" className="input-field text-xs font-mono" />
      </div>
      <div>
        <label className="text-xs text-text-muted block mb-1">Slippage (bps)</label>
        <input value={slippage} onChange={(e) => setSlippage(Number(e.target.value))} type="number" className="input-field text-xs font-mono" />
      </div>
      <button
        onClick={handleExecute}
        disabled={isExecuting}
        className={cn(
          'w-full py-2.5 text-sm font-bold rounded-lg transition-colors',
          direction === 'buy' ? 'bg-brand-green text-bg hover:bg-brand-green/90' : 'bg-brand-red text-white hover:bg-brand-red/90',
          isExecuting && 'opacity-50 cursor-not-allowed',
        )}
      >
        {isExecuting ? 'Executing...' : `EXECUTE ${direction.toUpperCase()}`}
      </button>
    </div>
  );
}

function MultiTradeTab({ wallets }: { wallets: Array<{ address: string; label: string; balanceLamports: string }> }) {
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [direction, setDirection] = useState<'buy' | 'sell'>('buy');
  const [totalSol, setTotalSol] = useState('1.0');
  const [useJito, setUseJito] = useState(true);
  const [isExecuting, setIsExecuting] = useState(false);

  const toggle = (addr: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(addr) ? next.delete(addr) : next.add(addr);
      return next;
    });
  };

  const perWallet = selected.size > 0 ? (parseFloat(totalSol) / selected.size) : 0;

  const handleExecute = useCallback(async () => {
    if (selected.size === 0) { toast.error('Select wallets first'); return; }
    setIsExecuting(true);
    try {
      const addrs = Array.from(selected);
      const amounts = addrs.map(() => solToLamports(perWallet));
      const result = await multiTrade({ wallets: addrs, direction, amounts, useJito });
      const successCount = result.results.filter((r) => r.success).length;
      toast.success(`${successCount}/${addrs.length} trades executed`);
    } catch {
      toast.error('Multi-trade failed');
    } finally {
      setIsExecuting(false);
    }
  }, [selected, direction, perWallet, useJito]);

  return (
    <div className="space-y-4">
      <h4 className="text-xs font-semibold text-text-secondary uppercase tracking-wider">Multi-Wallet Trade</h4>
      <div className="max-h-32 overflow-y-auto space-y-1 bg-bg rounded-md p-2">
        {wallets.map((w) => (
          <label key={w.address} className="flex items-center gap-2 text-xs cursor-pointer">
            <input type="checkbox" checked={selected.has(w.address)} onChange={() => toggle(w.address)} className="rounded accent-brand-green" />
            <span className="text-text-secondary">{w.label}</span>
            <span className="text-text-muted font-mono ml-auto">{formatLamportsAsSol(w.balanceLamports, 2)}</span>
          </label>
        ))}
      </div>
      <div className="flex gap-2">
        <button onClick={() => setDirection('buy')} className={cn('flex-1 py-1.5 text-xs font-bold rounded', direction === 'buy' ? 'bg-brand-green/20 text-brand-green' : 'bg-bg text-text-muted')}>BUY</button>
        <button onClick={() => setDirection('sell')} className={cn('flex-1 py-1.5 text-xs font-bold rounded', direction === 'sell' ? 'bg-brand-red/20 text-brand-red' : 'bg-bg text-text-muted')}>SELL</button>
      </div>
      <div>
        <label className="text-xs text-text-muted block mb-1">Total (SOL) — {selected.size} wallets × {perWallet.toFixed(4)} each</label>
        <input value={totalSol} onChange={(e) => setTotalSol(e.target.value)} type="number" step="0.1" className="input-field text-xs font-mono" />
      </div>
      <label className="flex items-center gap-2 text-xs text-text-secondary">
        <input type="checkbox" checked={useJito} onChange={() => setUseJito(!useJito)} className="rounded accent-brand-green" />
        Jito Bundle (simultaneous)
      </label>
      <button onClick={handleExecute} disabled={isExecuting || selected.size === 0} className="w-full py-2 bg-brand-green text-bg text-sm font-bold rounded-lg disabled:opacity-50">
        {isExecuting ? 'Executing...' : `Execute ${selected.size} Trades`}
      </button>
    </div>
  );
}

function BurstTab() {
  const [bursts, setBursts] = useState<BurstEventRuntime[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useState(() => {
    getBurstEvents().then((b) => setBursts(b)).catch(() => {}).finally(() => setIsLoading(false));
  });

  const handleTrigger = useCallback(async (id: string) => {
    try {
      await triggerBurstEvent(id);
      toast.success('Burst triggered');
      setBursts((prev) => prev.map((b) => b.id === id ? { ...b, executedAt: Date.now() } : b));
    } catch {
      toast.error('Failed to trigger burst');
    }
  }, []);

  return (
    <div className="space-y-4">
      <h4 className="text-xs font-semibold text-text-secondary uppercase tracking-wider">Burst Events</h4>
      {isLoading ? (
        <div className="text-xs text-text-muted text-center py-4">Loading...</div>
      ) : bursts.length === 0 ? (
        <div className="text-xs text-text-muted text-center py-4">No burst events configured. Add them in the Configure → Bundle tab.</div>
      ) : (
        <div className="space-y-2">
          {bursts.map((b) => (
            <div key={b.id} className="bg-bg rounded-md p-3 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <div className="text-xs text-text-primary">{b.triggerType}: {b.triggerValue}</div>
                <div className="text-[10px] text-text-muted">{b.walletAddresses.length} wallets × {formatLamportsAsSol(b.amountPerWalletLamports, 2)}</div>
              </div>
              {b.executedAt ? (
                <span className="text-[10px] text-text-muted">Triggered</span>
              ) : (
                <button onClick={() => handleTrigger(b.id)} className="px-2 py-1 bg-brand-green/20 text-brand-green text-[10px] font-bold rounded">TRIGGER NOW</button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function EmergencySellTab({ wallets }: { wallets: Array<{ address: string; label: string }> }) {
  const [confirmText, setConfirmText] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);

  const handleEmergencySell = useCallback(async () => {
    if (confirmText !== 'CONFIRM') { toast.error('Type CONFIRM to proceed'); return; }
    setIsExecuting(true);
    try {
      const addrs = wallets.map((w) => w.address);
      const amounts = addrs.map(() => '0'); // sell all = 0 means server sells all tokens
      await multiTrade({ wallets: addrs, direction: 'sell', amounts, useJito: true });
      toast.success('Emergency sell initiated');
    } catch {
      toast.error('Emergency sell failed');
    } finally {
      setIsExecuting(false);
    }
  }, [confirmText, wallets]);

  return (
    <div className="space-y-4">
      <div className="bg-brand-red/10 border border-brand-red/20 rounded-lg p-4 flex gap-3">
        <AlertTriangle className="w-5 h-5 text-brand-red flex-shrink-0" />
        <div>
          <div className="text-sm font-semibold text-brand-red">Emergency Sell</div>
          <div className="text-xs text-brand-red/80 mt-1">
            This will immediately sell ALL tokens across ALL {wallets.length} active wallets.
          </div>
        </div>
      </div>
      <div>
        <label className="text-xs text-text-muted block mb-1">Type &quot;CONFIRM&quot; to enable</label>
        <input value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="CONFIRM" className="input-field text-xs font-mono" />
      </div>
      <button
        onClick={handleEmergencySell}
        disabled={confirmText !== 'CONFIRM' || isExecuting}
        className="w-full py-2.5 bg-brand-red text-white text-sm font-bold rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isExecuting ? 'Selling...' : 'SELL ALL TOKENS FROM ALL WALLETS'}
      </button>
    </div>
  );
}
