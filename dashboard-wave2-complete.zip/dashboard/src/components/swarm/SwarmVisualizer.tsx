'use client';

import { useRef, useEffect, useCallback, forwardRef, useImperativeHandle } from 'react';
import type { Agent, DashboardEvent } from '@/types';

interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  targetX: number;
  targetY: number;
  pulses: Array<{ radius: number; maxRadius: number; alpha: number; color: string }>;
  echoes: Array<{ x: number; y: number; alpha: number; color: string; vy: number }>;
}

export interface SwarmVisualizerHandle {
  triggerPulse: (agentId: string, direction: 'buy' | 'sell') => void;
}

interface Props {
  agents: Agent[];
}

export const SwarmVisualizer = forwardRef<SwarmVisualizerHandle, Props>(
  function SwarmVisualizer({ agents }, ref) {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const particlesRef = useRef<Map<string, Particle>>(new Map());
    const animFrameRef = useRef<number>(0);

    useImperativeHandle(ref, () => ({
      triggerPulse(agentId: string, direction: 'buy' | 'sell') {
        const p = particlesRef.current.get(agentId);
        if (!p) return;
        const color = direction === 'buy' ? '#00ff88' : '#ff3366';
        p.pulses.push({ radius: p.radius, maxRadius: 40, alpha: 0.6, color });
        p.echoes.push({ x: p.x, y: p.y, alpha: 0.8, color, vy: -0.5 });
        // Nudge toward/away from center
        const canvas = canvasRef.current;
        if (!canvas) return;
        const cx = canvas.width / 2;
        const cy = canvas.height / 2;
        const dx = cx - p.x;
        const dy = cy - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const nudge = direction === 'buy' ? 2 : -2;
        p.vx += (dx / dist) * nudge;
        p.vy += (dy / dist) * nudge;
      },
    }));

    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const resize = () => {
        canvas.width = canvas.clientWidth * window.devicePixelRatio;
        canvas.height = canvas.clientHeight * window.devicePixelRatio;
        ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      };
      resize();
      window.addEventListener('resize', resize);

      // Sync particles with agents
      const existing = particlesRef.current;
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;

      for (const agent of agents) {
        if (!existing.has(agent.id)) {
          existing.set(agent.id, {
            id: agent.id,
            x: w * 0.2 + Math.random() * w * 0.6,
            y: h * 0.2 + Math.random() * h * 0.6,
            vx: (Math.random() - 0.5) * 0.3,
            vy: (Math.random() - 0.5) * 0.3,
            radius: Math.max(3, Math.min(10, 3 + Math.log1p(agent.solBalance * 10))),
            color: agent.pnl >= 0 ? '#00ff88' : '#ff3366',
            targetX: w / 2 + (Math.random() - 0.5) * w * 0.5,
            targetY: h / 2 + (Math.random() - 0.5) * h * 0.5,
            pulses: [],
            echoes: [],
          });
        } else {
          const p = existing.get(agent.id)!;
          p.color = agent.pnl >= 0 ? '#00ff88' : '#ff3366';
          p.radius = Math.max(3, Math.min(10, 3 + Math.log1p(agent.solBalance * 10)));
        }
      }

      let time = 0;

      function animate() {
        if (!ctx || !canvas) return;
        const cw = canvas.clientWidth;
        const ch = canvas.clientHeight;
        ctx.clearRect(0, 0, cw, ch);
        time += 0.016;

        for (const p of existing.values()) {
          // Gentle sine drift
          p.vx += Math.sin(time * 0.5 + p.x * 0.01) * 0.002;
          p.vy += Math.cos(time * 0.5 + p.y * 0.01) * 0.002;

          // Soft center attraction
          const dx = cw / 2 - p.x;
          const dy = ch / 2 - p.y;
          p.vx += dx * 0.00005;
          p.vy += dy * 0.00005;

          // Boundary repulsion
          if (p.x < 30) p.vx += 0.1;
          if (p.x > cw - 30) p.vx -= 0.1;
          if (p.y < 30) p.vy += 0.1;
          if (p.y > ch - 30) p.vy -= 0.1;

          // Damping
          p.vx *= 0.98;
          p.vy *= 0.98;

          p.x += p.vx;
          p.y += p.vy;

          // Draw particle
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.globalAlpha = 0.8;
          ctx.fill();

          // Glow
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius + 3, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.globalAlpha = 0.15;
          ctx.fill();

          // Pulses
          for (let i = p.pulses.length - 1; i >= 0; i--) {
            const pulse = p.pulses[i];
            pulse.radius += 1.5;
            pulse.alpha -= 0.015;
            if (pulse.alpha <= 0) { p.pulses.splice(i, 1); continue; }
            ctx.beginPath();
            ctx.arc(p.x, p.y, pulse.radius, 0, Math.PI * 2);
            ctx.strokeStyle = pulse.color;
            ctx.globalAlpha = pulse.alpha;
            ctx.lineWidth = 2;
            ctx.stroke();
          }

          // Echoes
          for (let i = p.echoes.length - 1; i >= 0; i--) {
            const echo = p.echoes[i];
            echo.y += echo.vy;
            echo.vy -= 0.005;
            echo.alpha -= 0.01;
            if (echo.alpha <= 0) { p.echoes.splice(i, 1); continue; }
            ctx.beginPath();
            ctx.arc(echo.x, echo.y, 2, 0, Math.PI * 2);
            ctx.fillStyle = echo.color;
            ctx.globalAlpha = echo.alpha;
            ctx.fill();
          }
        }

        ctx.globalAlpha = 1;

        // Legend
        ctx.font = '10px monospace';
        ctx.fillStyle = '#52525b';
        ctx.fillText('● Active agent    ● Buy pulse    ● Sell pulse', 10, ch - 10);

        animFrameRef.current = requestAnimationFrame(animate);
      }

      animFrameRef.current = requestAnimationFrame(animate);

      return () => {
        cancelAnimationFrame(animFrameRef.current);
        window.removeEventListener('resize', resize);
      };
    }, [agents]);

    return (
      <canvas
        ref={canvasRef}
        className="w-full h-[300px] bg-bg rounded-lg border border-border-subtle"
        style={{ imageRendering: 'auto' }}
      />
    );
  },
);
