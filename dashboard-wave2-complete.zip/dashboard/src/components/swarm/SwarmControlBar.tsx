'use client';

import { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  Square,
  OctagonX,
  Copy,
  ExternalLink,
  ChevronDown,
} from 'lucide-react';
import { useSwarmStore } from '@/stores/swarm.store';
import {
  pauseSwarm,
  resumeSwarm,
  emergencyStop,
  triggerExit,
  startSwarm,
} from '@/lib/api';
import {
  formatPhase,
  phaseColor,
  phaseBgColor,
  formatElapsed,
  formatSol,
  formatNumber,
  formatCompact,
  truncateAddress,
} from '@/lib/formatters';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

export function SwarmControlBar() {
  const phase = useSwarmStore((s) => s.phase);
  const isRunning = useSwarmStore((s) => s.isRunning);
  const isPaused = useSwarmStore((s) => s.isPaused);
  const mint = useSwarmStore((s) => s.mint);
  const uptime = useSwarmStore((s) => s.uptime);
  const activeAgentCount = useSwarmStore((s) => s.activeAgentCount);
  const totalAgentCount = useSwarmStore((s) => s.totalAgentCount);
  const totalTrades = useSwarmStore((s) => s.totalTrades);
  const totalVolumeSol = useSwarmStore((s) => s.totalVolumeSol);
  const currentPnlSol = useSwarmStore((s) => s.currentPnlSol);

  const [elapsed, setElapsed] = useState(uptime);
  const [showPhaseControl, setShowPhaseControl] = useState(false);

  useEffect(() => {
    setElapsed(uptime);
    if (!isRunning && !isPaused) return;
    const interval = setInterval(() => setElapsed((p) => p + 1), 1000);
    return () => clearInterval(interval);
  }, [uptime, isRunning, isPaused]);

  const handleStart = async () => {
    try {
      await startSwarm({});
      toast.success('Swarm started');
    } catch {
      toast.error('Failed to start swarm');
    }
  };

  const handlePause = async () => {
    try {
      await pauseSwarm();
      toast.success('Swarm paused');
    } catch {
      toast.error('Failed to pause');
    }
  };

  const handleResume = async () => {
    try {
      await resumeSwarm();
      toast.success('Swarm resumed');
    } catch {
      toast.error('Failed to resume');
    }
  };

  const handleStop = async () => {
    if (!confirm('Stop the swarm? This will trigger the exit strategy.')) return;
    try {
      await triggerExit();
      toast.success('Exit strategy triggered');
    } catch {
      toast.error('Failed to trigger exit');
    }
  };

  const handleEmergencyStop = async () => {
    if (!confirm('EMERGENCY STOP: All trading halts immediately. Continue?')) return;
    try {
      await emergencyStop();
      toast.success('Emergency stop executed');
    } catch {
      toast.error('Failed to execute emergency stop');
    }
  };

  const copyMint = () => {
    if (mint) {
      navigator.clipboard.writeText(mint);
      toast.success('Mint address copied');
    }
  };

  return (
    <div className="bg-surface/80 border border-border-subtle rounded-lg px-5 py-3 flex items-center gap-4">
      {/* Left: Phase + elapsed + mint */}
      <div className="flex items-center gap-3 min-w-0">
        <div
          className={cn(
            'flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono font-bold',
            phaseBgColor(phase),
            phaseColor(phase),
          )}
        >
          <span
            className={cn(
              'w-2 h-2 rounded-full',
              (phase === 'trading' || phase === 'creating') && 'animate-pulse',
              phase === 'trading' ? 'bg-brand-green' : phase === 'exiting' ? 'bg-brand-red' : phase === 'paused' ? 'bg-warning' : 'bg-zinc-500',
            )}
          />
          {formatPhase(phase)}
        </div>
        {(isRunning || isPaused) && (
          <span className="text-xs font-mono text-text-muted">{formatElapsed(elapsed)}</span>
        )}
        {mint && (
          <div className="flex items-center gap-1 text-xs font-mono text-text-muted">
            <span>{truncateAddress(mint, 4)}</span>
            <button onClick={copyMint} className="hover:text-text-primary"><Copy className="w-3 h-3" /></button>
            <a href={`https://dexscreener.com/solana/${mint}`} target="_blank" rel="noopener noreferrer" className="hover:text-brand-green"><ExternalLink className="w-3 h-3" /></a>
          </div>
        )}
      </div>

      {/* Center: Controls */}
      <div className="flex items-center gap-2 flex-shrink-0">
        {phase === 'idle' && (
          <ControlBtn onClick={handleStart} color="green" icon={Play} label="START" />
        )}
        {isRunning && !isPaused && (
          <ControlBtn onClick={handlePause} color="yellow" icon={Pause} label="PAUSE ALL" />
        )}
        {isPaused && (
          <ControlBtn onClick={handleResume} color="green" icon={Play} label="RESUME ALL" />
        )}
        {(isRunning || isPaused) && (
          <>
            <ControlBtn onClick={handleStop} color="red-outline" icon={Square} label="STOP" />
            <ControlBtn onClick={handleEmergencyStop} color="red" icon={OctagonX} label="EMERGENCY" flash />
          </>
        )}
        <div className="relative">
          <button
            onClick={() => setShowPhaseControl(!showPhaseControl)}
            className="flex items-center gap-1 px-2 py-1.5 text-[10px] text-text-muted hover:text-text-secondary rounded border border-border-subtle"
          >
            Phase <ChevronDown className="w-3 h-3" />
          </button>
          {showPhaseControl && (
            <div className="absolute top-full mt-1 right-0 bg-surface border border-border-subtle rounded-md shadow-xl z-20 py-1 min-w-[140px]">
              {(['trading', 'exiting', 'done'] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => { setShowPhaseControl(false); toast('Phase override: not connected to backend phase controller yet'); }}
                  className="w-full text-left px-3 py-1.5 text-xs text-text-secondary hover:bg-brand-green/5 hover:text-text-primary"
                >
                  Force → {formatPhase(p)}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right: Live metrics */}
      <div className="flex items-center gap-5 ml-auto text-xs font-mono">
        <Metric label="Agents" value={`${activeAgentCount}/${totalAgentCount}`} />
        <Metric label="Trades" value={formatNumber(totalTrades)} />
        <Metric label="Vol" value={`${totalVolumeSol.toFixed(1)} SOL`} />
        <Metric
          label="P&L"
          value={`${currentPnlSol >= 0 ? '+' : ''}${currentPnlSol.toFixed(2)} SOL`}
          valueClass={currentPnlSol >= 0 ? 'text-brand-green' : 'text-brand-red'}
        />
      </div>
    </div>
  );
}

function ControlBtn({ onClick, color, icon: Icon, label, flash }: {
  onClick: () => void;
  color: 'green' | 'yellow' | 'red' | 'red-outline';
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  flash?: boolean;
}) {
  const colors = {
    green: 'bg-brand-green/20 text-brand-green hover:bg-brand-green/30',
    yellow: 'bg-warning/20 text-warning hover:bg-warning/30',
    red: 'bg-brand-red/20 text-brand-red hover:bg-brand-red/30',
    'red-outline': 'border border-brand-red/40 text-brand-red hover:bg-brand-red/10',
  };

  return (
    <button
      onClick={onClick}
      className={cn(
        'flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors',
        colors[color],
        flash && 'animate-pulse',
      )}
    >
      <Icon className="w-3.5 h-3.5" />
      {label}
    </button>
  );
}

function Metric({ label, value, valueClass }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-text-muted">{label}:</span>
      <span className={valueClass ?? 'text-text-primary'}>{value}</span>
    </div>
  );
}
