'use client';

import { useSwarmStore } from '@/stores/swarm.store';
import { formatPhase, phaseColor } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import { Check } from 'lucide-react';
import type { SwarmPhase } from '@/types';

const PHASE_ORDER: SwarmPhase[] = ['idle', 'creating', 'bundling', 'trading', 'exiting', 'done'];

export function PhaseTimeline() {
  const currentPhase = useSwarmStore((s) => s.phase);
  const currentIdx = PHASE_ORDER.indexOf(currentPhase === 'paused' ? 'trading' : currentPhase);

  return (
    <div className="flex items-center gap-0 bg-surface/50 border border-border-subtle rounded-lg px-4 py-2.5 overflow-x-auto">
      {PHASE_ORDER.map((phase, idx) => {
        const isPast = idx < currentIdx;
        const isCurrent = idx === currentIdx;
        const isFuture = idx > currentIdx;

        return (
          <div key={phase} className="flex items-center">
            <div className={cn(
              'flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-semibold transition-all',
              isPast && 'bg-brand-green/10 text-brand-green/60',
              isCurrent && 'bg-brand-green/20 text-brand-green glow-green',
              isFuture && 'bg-bg text-text-muted',
            )}>
              {isPast && <Check className="w-3 h-3" />}
              {isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-brand-green animate-pulse" />}
              {formatPhase(phase)}
            </div>
            {idx < PHASE_ORDER.length - 1 && (
              <div className={cn(
                'w-8 h-px mx-1',
                idx < currentIdx ? 'bg-brand-green/40' : 'bg-border-subtle',
              )} />
            )}
          </div>
        );
      })}
    </div>
  );
}
