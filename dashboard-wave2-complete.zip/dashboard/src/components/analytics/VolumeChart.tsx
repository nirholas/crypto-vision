'use client';

import { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { getVolumeHourly, getAnalytics } from '@/lib/api';
import { formatSol } from '@/lib/formatters';
import type { VolumeHourly } from '@/types';

const COLORS = ['#00ff88', '#ff3366', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

export function VolumeChart() {
  const [hourly, setHourly] = useState<VolumeHourly[]>([]);
  const [analytics, setAnalytics] = useState<{ totalVolumeSol: number; avgTradeSize: number; buyCount: number; sellCount: number } | null>(null);

  useEffect(() => {
    getVolumeHourly().then(setHourly).catch(() => {});
    getAnalytics().then(setAnalytics).catch(() => {});
    const interval = setInterval(() => {
      getVolumeHourly().then(setHourly).catch(() => {});
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const volumePerHour = hourly.length > 0 ? hourly[hourly.length - 1]?.totalVolume ?? 0 : 0;

  return (
    <div className="space-y-6">
      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        <StatCard label="Total Volume" value={formatSol(analytics?.totalVolumeSol ?? 0)} />
        <StatCard label="Volume / Hour" value={formatSol(volumePerHour)} />
        <StatCard label="Avg Trade Size" value={formatSol(analytics?.avgTradeSize ?? 0)} />
      </div>

      {/* Hourly Bar Chart */}
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-4">
        <h4 className="text-sm font-semibold text-text-primary mb-4">Volume by Hour</h4>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={hourly}>
            <XAxis dataKey="hour" stroke="#52525b" tick={{ fontSize: 10 }} />
            <YAxis stroke="#52525b" tick={{ fontSize: 10 }} />
            <Tooltip
              contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #2a2a3e', fontSize: 12 }}
              formatter={(v: number, name: string) => [`${v.toFixed(4)} SOL`, name]}
            />
            <Bar dataKey="buyVolume" stackId="a" fill="#00ff88" name="Buy" />
            <Bar dataKey="sellVolume" stackId="a" fill="#ff3366" name="Sell" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Buy/Sell distribution */}
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-4">
        <h4 className="text-sm font-semibold text-text-primary mb-4">Buy vs Sell</h4>
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie
              data={[
                { name: 'Buys', value: analytics?.buyCount ?? 0 },
                { name: 'Sells', value: analytics?.sellCount ?? 0 },
              ]}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={80}
              dataKey="value"
            >
              <Cell fill="#00ff88" />
              <Cell fill="#ff3366" />
            </Pie>
            <Legend
              formatter={(value: string) => <span className="text-xs text-text-secondary">{value}</span>}
            />
            <Tooltip contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #2a2a3e', fontSize: 12 }} />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-surface/50 border border-border-subtle rounded-lg p-4">
      <div className="text-xs text-text-muted mb-1">{label}</div>
      <div className="text-xl font-mono font-bold text-text-primary">{value}</div>
    </div>
  );
}
