'use client';

import { useEffect, useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { usePnL } from '@/hooks/usePnL';
import { getPnLTimeSeries, getAgentAnalytics } from '@/lib/api';
import { formatSol, formatUsd, formatPercent } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import type { PnLTimeSeriesPoint, AgentPnLRow } from '@/types';

export function PnLCard() {
  const { data: pnlData } = usePnL();
  const [timeSeries, setTimeSeries] = useState<PnLTimeSeriesPoint[]>([]);
  const [agents, setAgents] = useState<AgentPnLRow[]>([]);
  const [sortKey, setSortKey] = useState<'totalPnl' | 'tradeCount'>('totalPnl');

  useEffect(() => {
    getPnLTimeSeries({ interval: 10 }).then(setTimeSeries).catch(() => {});
    getAgentAnalytics().then(setAgents).catch(() => {});
    const interval = setInterval(() => {
      getPnLTimeSeries({ interval: 10 }).then(setTimeSeries).catch(() => {});
      getAgentAnalytics().then(setAgents).catch(() => {});
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const snapshot = pnlData?.current;
  const totalPnl = snapshot?.totalPnlSol ?? 0;
  const totalCost = snapshot?.totalCostSol ?? 0;
  const pnlPercent = totalCost > 0 ? (totalPnl / totalCost) * 100 : 0;

  const breakEvenPercent = totalPnl >= 0 ? 0 : Math.abs(totalPnl / (totalCost || 1)) * 100;

  const sortedAgents = [...agents].sort((a, b) => {
    if (sortKey === 'totalPnl') return b.totalPnl - a.totalPnl;
    return b.tradeCount - a.tradeCount;
  });

  return (
    <div className="space-y-6">
      {/* Hero Stats */}
      <div className="grid grid-cols-4 gap-4">
        <HeroStat
          label="Total P&L"
          value={formatSol(totalPnl)}
          sub={`${pnlPercent >= 0 ? '+' : ''}${pnlPercent.toFixed(1)}%`}
          color={totalPnl >= 0 ? 'text-brand-green' : 'text-brand-red'}
        />
        <HeroStat
          label="Realized P&L"
          value={formatSol(snapshot?.realizedPnlSol ?? 0)}
          color={(snapshot?.realizedPnlSol ?? 0) >= 0 ? 'text-brand-green' : 'text-brand-red'}
        />
        <HeroStat
          label="Unrealized P&L"
          value={formatSol(snapshot?.unrealizedPnlSol ?? 0)}
          color={(snapshot?.unrealizedPnlSol ?? 0) >= 0 ? 'text-brand-green' : 'text-brand-red'}
        />
        <HeroStat
          label="Break-Even"
          value={totalPnl >= 0 ? 'In profit ✓' : `Need ${breakEvenPercent.toFixed(1)}% more`}
          color={totalPnl >= 0 ? 'text-brand-green' : 'text-warning'}
        />
      </div>

      {/* P&L Timeline Chart */}
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-4">
        <h4 className="text-sm font-semibold text-text-primary mb-4">P&L Over Time</h4>
        <ResponsiveContainer width="100%" height={250}>
          <AreaChart data={timeSeries}>
            <defs>
              <linearGradient id="pnlGreen" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00ff88" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#00ff88" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="pnlRed" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#ff3366" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#ff3366" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="timestamp"
              tickFormatter={(t) => new Date(t * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              stroke="#52525b"
              tick={{ fontSize: 10 }}
            />
            <YAxis stroke="#52525b" tick={{ fontSize: 10 }} tickFormatter={(v) => `${v.toFixed(2)}`} />
            <Tooltip
              contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #2a2a3e', fontSize: 12 }}
              labelFormatter={(t) => new Date((t as number) * 1000).toLocaleTimeString()}
              formatter={(v: number) => [`${v.toFixed(4)} SOL`, 'P&L']}
            />
            <ReferenceLine y={0} stroke="#52525b" strokeDasharray="3 3" />
            <Area
              type="monotone"
              dataKey="totalSol"
              stroke="#00ff88"
              fill="url(#pnlGreen)"
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Per-Agent Table */}
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-sm font-semibold text-text-primary">Per-Agent P&L</h4>
          <div className="flex gap-2">
            <button onClick={() => setSortKey('totalPnl')} className={cn('text-xs', sortKey === 'totalPnl' ? 'text-brand-green' : 'text-text-muted')}>By P&L</button>
            <button onClick={() => setSortKey('tradeCount')} className={cn('text-xs', sortKey === 'tradeCount' ? 'text-brand-green' : 'text-text-muted')}>By Trades</button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border-subtle text-text-muted">
                <th className="text-left py-2">Agent</th>
                <th className="text-left">Role</th>
                <th className="text-right">Spent</th>
                <th className="text-right">Received</th>
                <th className="text-right">Realized</th>
                <th className="text-right">Unrealized</th>
                <th className="text-right">Total</th>
                <th className="text-right">Win Rate</th>
                <th className="text-right">Trades</th>
              </tr>
            </thead>
            <tbody>
              {sortedAgents.map((a) => (
                <tr key={a.agentId} className="border-b border-border-subtle/50 hover:bg-surface/50">
                  <td className="py-1.5 font-mono">{a.agentId}</td>
                  <td>{a.role}</td>
                  <td className="text-right font-mono">{a.solSpent.toFixed(4)}</td>
                  <td className="text-right font-mono">{a.solReceived.toFixed(4)}</td>
                  <td className={cn('text-right font-mono', a.realizedPnl >= 0 ? 'text-brand-green' : 'text-brand-red')}>{a.realizedPnl.toFixed(4)}</td>
                  <td className={cn('text-right font-mono', a.unrealizedPnl >= 0 ? 'text-brand-green' : 'text-brand-red')}>{a.unrealizedPnl.toFixed(4)}</td>
                  <td className={cn('text-right font-mono font-semibold', a.totalPnl >= 0 ? 'text-brand-green' : 'text-brand-red')}>{a.totalPnl.toFixed(4)}</td>
                  <td className="text-right">{formatPercent(a.winRate)}</td>
                  <td className="text-right">{a.tradeCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function HeroStat({ label, value, sub, color }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <div className="bg-surface/50 border border-border-subtle rounded-lg p-4">
      <div className="text-xs text-text-muted mb-1">{label}</div>
      <div className={cn('text-xl font-mono font-bold', color ?? 'text-text-primary')}>{value}</div>
      {sub && <div className="text-xs text-text-muted mt-0.5">{sub}</div>}
    </div>
  );
}
