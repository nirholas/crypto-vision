'use client';

import { useEffect, useState } from 'react';
import { getCostBreakdown } from '@/lib/api';
import { formatSol } from '@/lib/formatters';
import type { CostBreakdown } from '@/types';

export function CostVsProfit() {
  const [costs, setCosts] = useState<CostBreakdown | null>(null);

  useEffect(() => {
    const fetch = () => getCostBreakdown().then(setCosts).catch(() => {});
    fetch();
    const interval = setInterval(fetch, 10000);
    return () => clearInterval(interval);
  }, []);

  if (!costs) {
    return (
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-6 text-center text-sm text-text-muted">
        Loading cost data...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-5">
        <h4 className="text-sm font-semibold text-text-primary mb-4">Running Costs (this session)</h4>
        <div className="space-y-2">
          <CostRow label="Gas / priority fees paid" value={formatSol(costs.gasFeesSol)} />
          <CostRow label="Jito tips paid" value={formatSol(costs.jitoTipsSol)} />
          <CostRow label="Total SOL in active trades" value={formatSol(costs.totalExposureSol)} highlight />
          <div className="text-[10px] text-text-muted pl-4 -mt-1">↳ This is your current exposure</div>
        </div>
      </div>

      <div className="bg-surface/50 border border-border-subtle rounded-lg p-5">
        <h4 className="text-sm font-semibold text-text-primary mb-4">Projected Costs (+1 hour)</h4>
        <div className="space-y-2">
          <CostRow label="Additional gas" value={`~${formatSol(costs.projectedGas1hr)}`} />
          <CostRow label="Additional Jito tips" value={`~${formatSol(costs.projectedJito1hr)}`} />
          <CostRow label="Additional trade capital" value={`~${formatSol(costs.projectedCapital1hr)}`} />
          <div className="border-t border-border-subtle pt-2 mt-2">
            <CostRow
              label="Est. total 1hr cost"
              value={`~${formatSol(costs.projectedGas1hr + costs.projectedJito1hr + costs.projectedCapital1hr)}`}
              highlight
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function CostRow({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex justify-between text-xs">
      <span className="text-text-muted">{label}</span>
      <span className={highlight ? 'text-text-primary font-semibold font-mono' : 'text-text-secondary font-mono'}>{value}</span>
    </div>
  );
}
