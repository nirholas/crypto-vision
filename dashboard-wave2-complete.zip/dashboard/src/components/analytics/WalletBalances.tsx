'use client';

import { useEffect, useState } from 'react';
import { Treemap, ResponsiveContainer, Tooltip } from 'recharts';
import { getWalletHoldings } from '@/lib/api';
import { formatSol, formatNumber, formatPercent, truncateAddress } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import type { WalletHolding } from '@/types';

export function WalletBalances() {
  const [holdings, setHoldings] = useState<WalletHolding[]>([]);

  useEffect(() => {
    getWalletHoldings().then(setHoldings).catch(() => {});
    const interval = setInterval(() => {
      getWalletHoldings().then(setHoldings).catch(() => {});
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const treemapData = holdings.map((h) => ({
    name: h.label,
    size: Math.max(0.001, h.solBalance),
    fill: h.solBalance > 0.1 ? '#00ff88' : h.solBalance > 0.05 ? '#f59e0b' : '#ff3366',
  }));

  const totalTokens = holdings.reduce((s, h) => s + h.tokensHeld, 0);
  const totalValue = holdings.reduce((s, h) => s + h.currentValueSol, 0);
  const totalUnrealized = holdings.reduce((s, h) => s + h.unrealizedPnl, 0);

  return (
    <div className="space-y-6">
      {/* Treemap */}
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-4">
        <h4 className="text-sm font-semibold text-text-primary mb-4">Wallet Balance Overview</h4>
        {holdings.length === 0 ? (
          <div className="h-[200px] flex items-center justify-center text-sm text-text-muted">No wallet data available</div>
        ) : (
          <ResponsiveContainer width="100%" height={200}>
            <Treemap
              data={treemapData}
              dataKey="size"
              nameKey="name"
              stroke="#0a0a0f"
              content={({ x, y, width, height, name, fill }: any) => (
                <g>
                  <rect x={x} y={y} width={width} height={height} fill={fill} opacity={0.7} rx={2} />
                  {width > 40 && height > 20 && (
                    <text x={x + width / 2} y={y + height / 2} textAnchor="middle" fill="#e4e4e7" fontSize={9} fontFamily="monospace">
                      {name}
                    </text>
                  )}
                </g>
              )}
            />
          </ResponsiveContainer>
        )}
      </div>

      {/* Holdings Table */}
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-4">
        <h4 className="text-sm font-semibold text-text-primary mb-4">Token Holdings</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border-subtle text-text-muted">
                <th className="text-left py-2">Wallet</th>
                <th className="text-right">SOL</th>
                <th className="text-right">Tokens</th>
                <th className="text-right">% Supply</th>
                <th className="text-right">Value (SOL)</th>
                <th className="text-right">Entry Cost</th>
                <th className="text-right">Unrealized P&L</th>
              </tr>
            </thead>
            <tbody>
              {holdings.map((h) => (
                <tr key={h.address} className="border-b border-border-subtle/50">
                  <td className="py-1.5">
                    <div className="text-text-primary">{h.label}</div>
                    <div className="text-[10px] text-text-muted font-mono">{truncateAddress(h.address, 4)}</div>
                  </td>
                  <td className={cn('text-right font-mono', h.solBalance < 0.05 ? 'text-brand-red' : 'text-text-secondary')}>
                    {h.solBalance.toFixed(4)}
                  </td>
                  <td className="text-right font-mono text-text-secondary">{formatNumber(h.tokensHeld)}</td>
                  <td className="text-right text-text-muted">{formatPercent(h.supplyPercent)}</td>
                  <td className="text-right font-mono text-text-secondary">{h.currentValueSol.toFixed(4)}</td>
                  <td className="text-right font-mono text-text-muted">{h.entryCostSol.toFixed(4)}</td>
                  <td className={cn('text-right font-mono font-semibold', h.unrealizedPnl >= 0 ? 'text-brand-green' : 'text-brand-red')}>
                    {h.unrealizedPnl >= 0 ? '+' : ''}{h.unrealizedPnl.toFixed(4)}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t border-border-subtle font-semibold">
                <td className="py-2 text-text-primary">Total</td>
                <td className="text-right font-mono">{holdings.reduce((s, h) => s + h.solBalance, 0).toFixed(4)}</td>
                <td className="text-right font-mono">{formatNumber(totalTokens)}</td>
                <td className="text-right">{formatPercent(holdings.reduce((s, h) => s + h.supplyPercent, 0))}</td>
                <td className="text-right font-mono">{totalValue.toFixed(4)}</td>
                <td className="text-right font-mono">{holdings.reduce((s, h) => s + h.entryCostSol, 0).toFixed(4)}</td>
                <td className={cn('text-right font-mono', totalUnrealized >= 0 ? 'text-brand-green' : 'text-brand-red')}>
                  {totalUnrealized >= 0 ? '+' : ''}{totalUnrealized.toFixed(4)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}
