'use client';

import { useState, useEffect, useCallback } from 'react';
import { Download, Search, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { getTradesPaginated, exportAll } from '@/lib/api';
import { relativeTime, formatNumber } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import type { TradeEntry } from '@/types';

export function TradeHistory() {
  const [trades, setTrades] = useState<TradeEntry[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filterDirection, setFilterDirection] = useState<'buy' | 'sell' | ''>('');
  const [filterAgent, setFilterAgent] = useState('');
  const limit = 50;

  const fetchTrades = useCallback(async () => {
    try {
      const result = await getTradesPaginated({
        page,
        limit,
        direction: filterDirection || undefined,
        agent: filterAgent || undefined,
      });
      setTrades(result.trades);
      setTotal(result.total);
      setTotalPages(result.totalPages);
    } catch {}
  }, [page, filterDirection, filterAgent]);

  useEffect(() => { fetchTrades(); }, [fetchTrades]);

  const handleExportCsv = useCallback(async () => {
    try {
      const blob = await exportAll();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'trade-history.json';
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Export downloaded');
    } catch {
      toast.error('Export failed');
    }
  }, []);

  const clearFilters = () => {
    setFilterDirection('');
    setFilterAgent('');
    setPage(1);
  };

  return (
    <div className="space-y-4">
      {/* Filter bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-text-muted" />
          <input
            value={filterAgent}
            onChange={(e) => { setFilterAgent(e.target.value); setPage(1); }}
            placeholder="Search agent..."
            className="input-field text-xs pl-8"
          />
        </div>
        <select
          value={filterDirection}
          onChange={(e) => { setFilterDirection(e.target.value as '' | 'buy' | 'sell'); setPage(1); }}
          className="input-field text-xs w-auto"
        >
          <option value="">All Directions</option>
          <option value="buy">Buy</option>
          <option value="sell">Sell</option>
        </select>
        {(filterDirection || filterAgent) && (
          <button onClick={clearFilters} className="flex items-center gap-1 text-xs text-text-muted hover:text-text-primary">
            <X className="w-3 h-3" /> Clear
          </button>
        )}
        <button onClick={handleExportCsv} className="flex items-center gap-1.5 px-3 py-1.5 bg-surface border border-border-subtle text-xs text-text-secondary rounded hover:text-text-primary transition-colors">
          <Download className="w-3.5 h-3.5" /> Export
        </button>
      </div>

      {/* Table */}
      <div className="bg-surface/50 border border-border-subtle rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border-subtle text-text-muted">
                <th className="text-left px-3 py-2">Time</th>
                <th className="text-left">Agent</th>
                <th className="text-center">Dir</th>
                <th className="text-right">Amount (SOL)</th>
                <th className="text-right">Tokens</th>
                <th className="text-right">Price (SOL/T)</th>
                <th className="text-right">Tx</th>
              </tr>
            </thead>
            <tbody>
              {trades.map((t) => (
                <tr
                  key={t.id}
                  className={cn(
                    'border-b border-border-subtle/50',
                    t.direction === 'buy' ? 'bg-brand-green/[0.02]' : 'bg-brand-red/[0.02]',
                  )}
                >
                  <td className="px-3 py-1.5 text-text-muted">{relativeTime(t.timestamp)}</td>
                  <td className="font-mono">{t.agentId}</td>
                  <td className="text-center">
                    <span className={cn('font-bold', t.direction === 'buy' ? 'text-brand-green' : 'text-brand-red')}>
                      {t.direction.toUpperCase()}
                    </span>
                  </td>
                  <td className="text-right font-mono">{t.solAmount.toFixed(4)}</td>
                  <td className="text-right font-mono">{formatNumber(Math.round(t.tokenAmount))}</td>
                  <td className="text-right font-mono text-text-muted">{t.price > 0 ? t.price.toFixed(9) : '—'}</td>
                  <td className="text-right">
                    <a
                      href={`https://solscan.io/tx/${t.signature}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-text-muted hover:text-brand-green"
                    >
                      🔗
                    </a>
                  </td>
                </tr>
              ))}
              {trades.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-text-muted">No trades found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-3 py-2 border-t border-border-subtle">
          <span className="text-xs text-text-muted">
            Showing {(page - 1) * limit + 1}–{Math.min(page * limit, total)} of {total}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="p-1 text-text-muted hover:text-text-primary disabled:opacity-30"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs text-text-secondary">{page} / {totalPages}</span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="p-1 text-text-muted hover:text-text-primary disabled:opacity-30"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
