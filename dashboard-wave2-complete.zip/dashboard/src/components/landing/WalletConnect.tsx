'use client';

import { useEffect } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { createSession } from '@/lib/api';
import { useWalletStore } from '@/stores/wallet.store';

export function WalletConnect() {
  const { publicKey, connected } = useWallet();
  const router = useRouter();
  const setConnectedWallet = useWalletStore((s) => s.setConnectedWallet);

  useEffect(() => {
    if (connected && publicKey) {
      const address = publicKey.toBase58();
      setConnectedWallet(address);

      createSession(address)
        .then(() => {
          router.push('/dashboard');
        })
        .catch(() => {
          toast.error('Failed to create session. Backend may be offline.');
        });
    } else {
      setConnectedWallet(null);
    }
  }, [connected, publicKey, router, setConnectedWallet]);

  return (
    <div className="wallet-connect-wrapper">
      <WalletMultiButton
        style={{
          backgroundColor: 'transparent',
          border: '2px solid #00ff88',
          borderRadius: '12px',
          padding: '14px 32px',
          fontSize: '16px',
          fontFamily: 'var(--font-display)',
          fontWeight: 600,
          color: '#00ff88',
          boxShadow: '0 0 20px rgba(0, 255, 136, 0.15), 0 0 60px rgba(0, 255, 136, 0.05)',
          transition: 'all 0.2s ease',
        }}
      />
    </div>
  );
}
