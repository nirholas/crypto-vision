'use client';

import { useRef, useEffect, useState, useCallback } from 'react';
import { createChart, type IChartApi, type ISeriesApi, CrosshairMode, type Time, type SeriesMarker } from 'lightweight-charts';
import { useSwarmStore } from '@/stores/swarm.store';
import { useWebSocket } from '@/hooks/useWebSocket';
import { getChartHistory } from '@/lib/api';
import type { DashboardEvent, TradeExecutedData, OHLCVCandle } from '@/types';

interface Props {
  resolution: number;
  showAgentMarkers: boolean;
  showGraduationLine: boolean;
}

interface CandleData {
  time: Time;
  open: number;
  high: number;
  low: number;
  close: number;
}

interface TradeMarkerData {
  time: number;
  direction: 'buy' | 'sell';
  agentLabel: string;
  amountSol: number;
  source: 'agent' | 'tracked';
}

export function PriceChart({ resolution, showAgentMarkers, showGraduationLine }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  const markersRef = useRef<TradeMarkerData[]>([]);
  const mint = useSwarmStore((s) => s.mint);
  const { subscribe } = useWebSocket();

  // Create chart
  useEffect(() => {
    if (!containerRef.current) return;

    const chart = createChart(containerRef.current, {
      layout: {
        background: { color: '#0a0a0f' } as { color: string },
        textColor: '#888',
      },
      grid: {
        vertLines: { color: '#1a1a2e' },
        horzLines: { color: '#1a1a2e' },
      },
      crosshair: { mode: CrosshairMode.Normal },
      rightPriceScale: { borderColor: '#1a1a2e' },
      timeScale: { borderColor: '#1a1a2e', timeVisible: true, secondsVisible: true },
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
    });

    const candleSeries = chart.addCandlestickSeries({
      upColor: '#00ff88',
      downColor: '#ff3366',
      borderUpColor: '#00ff88',
      borderDownColor: '#ff3366',
      wickUpColor: '#00ff8880',
      wickDownColor: '#ff336680',
    });

    const volumeSeries = chart.addHistogramSeries({
      color: '#00ff8840',
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
    });

    chart.priceScale('volume').applyOptions({
      scaleMargins: { top: 0.8, bottom: 0 },
    });

    chartRef.current = chart;
    candleSeriesRef.current = candleSeries;
    volumeSeriesRef.current = volumeSeries;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        chart.applyOptions({
          width: entry.contentRect.width,
          height: entry.contentRect.height,
        });
      }
    });
    resizeObserver.observe(containerRef.current);

    return () => {
      resizeObserver.disconnect();
      chart.remove();
    };
  }, []);

  // Load historical data
  useEffect(() => {
    if (!mint || !candleSeriesRef.current) return;

    getChartHistory({ mint, resolution }).then((candles) => {
      if (!candleSeriesRef.current || !volumeSeriesRef.current) return;
      const candleData = candles.map((c) => ({
        time: c.time as Time,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }));
      const volumeData = candles.map((c) => ({
        time: c.time as Time,
        value: c.volume,
        color: c.close >= c.open ? '#00ff8840' : '#ff336640',
      }));
      candleSeriesRef.current.setData(candleData);
      volumeSeriesRef.current.setData(volumeData);
    }).catch(() => {});
  }, [mint, resolution]);

  // Live WebSocket updates + markers
  useEffect(() => {
    const unsub = subscribe('trade:executed', (event: DashboardEvent) => {
      const data = event.data as unknown as TradeExecutedData;
      if (!candleSeriesRef.current) return;

      const time = Math.floor(Date.now() / 1000 / resolution) * resolution;
      candleSeriesRef.current.update({
        time: time as Time,
        open: data.price,
        high: data.price,
        low: data.price,
        close: data.price,
      });

      if (showAgentMarkers) {
        markersRef.current.push({
          time: time,
          direction: data.direction,
          agentLabel: data.agentLabel ?? data.agentId,
          amountSol: data.solAmount,
          source: 'agent',
        });

        const markers: SeriesMarker<Time>[] = markersRef.current.map((m) => ({
          time: m.time as Time,
          position: m.direction === 'buy' ? 'belowBar' : 'aboveBar',
          color: m.source === 'agent'
            ? m.direction === 'buy' ? '#00ff88' : '#ff3366'
            : m.direction === 'buy' ? '#00bfff' : '#ff8c00',
          shape: m.source === 'agent'
            ? m.direction === 'buy' ? 'arrowUp' : 'arrowDown'
            : 'circle',
          text: `${m.agentLabel} ${m.direction.toUpperCase()} ${m.amountSol.toFixed(4)}`,
        }));

        candleSeriesRef.current.setMarkers(markers);
      }
    });

    return unsub;
  }, [subscribe, showAgentMarkers, resolution]);

  return (
    <div ref={containerRef} className="w-full h-full min-h-[400px]" />
  );
}
