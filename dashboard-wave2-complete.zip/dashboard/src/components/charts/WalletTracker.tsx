'use client';

import { useState, useEffect, useCallback } from 'react';
import { RefreshCw, Plus, X, Eye } from 'lucide-react';
import { useSwarmStore } from '@/stores/swarm.store';
import { getGmgnWallets, trackWallet, untrackWallet, getTrackedWallets } from '@/lib/api';
import { truncateAddress, relativeTime } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import type { GmgnWallet, TrackedWallet } from '@/types';

interface Props {
  onToggleChartOverlay?: (address: string, enabled: boolean) => void;
}

export function WalletTracker({ onToggleChartOverlay }: Props) {
  const [tab, setTab] = useState<'gmgn' | 'watching'>('gmgn');
  const mint = useSwarmStore((s) => s.mint);
  const [gmgnWallets, setGmgnWallets] = useState<GmgnWallet[]>([]);
  const [tracked, setTracked] = useState<TrackedWallet[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [addInput, setAddInput] = useState('');
  const [addLabel, setAddLabel] = useState('');

  const refreshGmgn = useCallback(async () => {
    if (!mint) return;
    setIsLoading(true);
    try {
      const wallets = await getGmgnWallets(mint);
      setGmgnWallets(wallets);
    } catch {
      // GMGN may not be available
    } finally {
      setIsLoading(false);
    }
  }, [mint]);

  const loadTracked = useCallback(async () => {
    try {
      const list = await getTrackedWallets();
      setTracked(list as TrackedWallet[]);
    } catch {}
  }, []);

  useEffect(() => { refreshGmgn(); loadTracked(); }, [refreshGmgn, loadTracked]);

  const handleTrack = useCallback(async (address: string, label: string) => {
    try {
      await trackWallet(address, label);
      toast.success('Wallet tracked');
      loadTracked();
    } catch {
      toast.error('Failed to track wallet');
    }
  }, [loadTracked]);

  const handleUntrack = useCallback(async (address: string) => {
    try {
      await untrackWallet(address);
      setTracked((prev) => prev.filter((t) => t.address !== address));
      toast.success('Wallet removed');
    } catch {
      toast.error('Failed to remove');
    }
  }, []);

  const handleAddManual = useCallback(async () => {
    if (!addInput.trim()) return;
    await handleTrack(addInput.trim(), addLabel.trim() || `manual-${Date.now()}`);
    setAddInput('');
    setAddLabel('');
  }, [addInput, addLabel, handleTrack]);

  const stars = (score: number) => '★'.repeat(Math.min(5, Math.max(1, Math.round(score))));

  return (
    <div className="bg-surface/50 border border-border-subtle rounded-lg overflow-hidden flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-border-subtle">
        <span className="text-xs font-semibold text-text-primary">Wallet Tracker</span>
        <button onClick={refreshGmgn} className="text-text-muted hover:text-text-primary">
          <RefreshCw className={cn('w-3.5 h-3.5', isLoading && 'animate-spin')} />
        </button>
      </div>

      <div className="flex border-b border-border-subtle">
        <button onClick={() => setTab('gmgn')} className={cn('flex-1 py-1.5 text-xs', tab === 'gmgn' ? 'text-brand-green bg-brand-green/5' : 'text-text-muted')}>GMGN</button>
        <button onClick={() => setTab('watching')} className={cn('flex-1 py-1.5 text-xs', tab === 'watching' ? 'text-brand-green bg-brand-green/5' : 'text-text-muted')}>Watching ({tracked.length})</button>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {tab === 'gmgn' && (
          <>
            {!mint && <p className="text-xs text-text-muted text-center py-4">Launch a token first</p>}
            {gmgnWallets.length === 0 && mint && !isLoading && (
              <p className="text-xs text-text-muted text-center py-4">No hot wallets found</p>
            )}
            {gmgnWallets.map((w) => (
              <div key={w.address} className="bg-bg rounded-md p-2.5 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-text-primary">{truncateAddress(w.address, 4)}</span>
                  <span className="text-[10px] text-yellow-400">{stars(w.score)}</span>
                </div>
                <div className="text-[10px] text-text-muted">
                  Last: <span className={w.lastDirection === 'buy' ? 'text-brand-green' : 'text-brand-red'}>
                    {w.lastDirection.toUpperCase()}
                  </span> {w.lastAmountSol.toFixed(2)} SOL · {relativeTime(w.lastTimestamp)}
                </div>
                <div className="flex gap-1.5">
                  <button onClick={() => handleTrack(w.address, `gmgn-${w.address.slice(0, 4)}`)} className="text-[10px] px-1.5 py-0.5 bg-brand-green/10 text-brand-green rounded">Track</button>
                  <button onClick={() => onToggleChartOverlay?.(w.address, true)} className="text-[10px] px-1.5 py-0.5 bg-info/10 text-info rounded flex items-center gap-0.5">
                    <Eye className="w-2.5 h-2.5" /> Chart
                  </button>
                </div>
              </div>
            ))}
          </>
        )}

        {tab === 'watching' && (
          <>
            {tracked.map((w) => (
              <div key={w.id} className="bg-bg rounded-md p-2.5 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: w.color }} />
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-mono text-text-primary truncate">{w.label}</div>
                  <div className="text-[10px] text-text-muted font-mono">{truncateAddress(w.address, 4)}</div>
                </div>
                <button onClick={() => handleUntrack(w.address)} className="text-text-muted hover:text-brand-red flex-shrink-0">
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}

            {/* Add manual wallet */}
            <div className="border-t border-border-subtle pt-2 mt-2 space-y-1.5">
              <input value={addInput} onChange={(e) => setAddInput(e.target.value)} placeholder="Wallet address" className="input-field text-[10px] font-mono py-1" />
              <input value={addLabel} onChange={(e) => setAddLabel(e.target.value)} placeholder="Label (optional)" className="input-field text-[10px] py-1" />
              <button onClick={handleAddManual} className="w-full flex items-center justify-center gap-1 py-1 text-[10px] bg-brand-green/10 text-brand-green rounded">
                <Plus className="w-3 h-3" /> Add Wallet
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
