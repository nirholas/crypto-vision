'use client';

import { ExternalLink } from 'lucide-react';
import { useSwarmStore } from '@/stores/swarm.store';

export function DexScreenerEmbed() {
  const mint = useSwarmStore((s) => s.mint);

  if (!mint) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-bg rounded-lg border border-border-subtle">
        <p className="text-sm text-text-muted">Launch a token first to see the DexScreener chart.</p>
      </div>
    );
  }

  return (
    <div className="w-full h-full relative">
      <iframe
        src={`https://dexscreener.com/solana/${mint}?embed=1&theme=dark&trades=1`}
        className="w-full h-full rounded-lg border border-border-subtle"
        sandbox="allow-same-origin allow-scripts allow-popups"
        title="DexScreener"
      />
      <a
        href={`https://dexscreener.com/solana/${mint}`}
        target="_blank"
        rel="noopener noreferrer"
        className="absolute top-3 right-3 flex items-center gap-1 px-2 py-1 bg-surface/90 text-xs text-text-secondary hover:text-brand-green rounded transition-colors"
      >
        Open Full <ExternalLink className="w-3 h-3" />
      </a>
    </div>
  );
}
