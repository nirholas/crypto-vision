'use client';

import { useState, useCallback } from 'react';
import { X, Upload, AlertCircle, Check } from 'lucide-react';
import { importWallets } from '@/lib/api';
import { useWalletStore } from '@/stores/wallet.store';
import toast from 'react-hot-toast';

interface Props {
  onClose: () => void;
}

interface ParsedKey {
  raw: string;
  valid: boolean;
  error?: string;
}

export function ImportWalletsModal({ onClose }: Props) {
  const [method, setMethod] = useState<'paste' | 'file'>('paste');
  const [keysText, setKeysText] = useState('');
  const [parsedKeys, setParsedKeys] = useState<ParsedKey[]>([]);
  const [isImporting, setIsImporting] = useState(false);

  const addWallets = useWalletStore((s) => s.addWallets);

  const parseKeys = useCallback((text: string) => {
    const lines = text
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    const parsed: ParsedKey[] = lines.map((line) => {
      // Basic base58 validation
      if (line.length < 32 || line.length > 128) {
        return { raw: line, valid: false, error: 'Invalid key length' };
      }
      const base58Regex = /^[1-9A-HJ-NP-Za-km-z]+$/;
      if (!base58Regex.test(line)) {
        return { raw: line, valid: false, error: 'Invalid base58 characters' };
      }
      return { raw: line, valid: true };
    });

    setParsedKeys(parsed);
    return parsed;
  }, []);

  const handleParse = useCallback(() => {
    parseKeys(keysText);
  }, [keysText, parseKeys]);

  const handleFileUpload = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (ev) => {
        const text = ev.target?.result as string;
        try {
          const json = JSON.parse(text);
          if (Array.isArray(json)) {
            // Could be array of keys or array of numbers (Solana CLI format)
            if (typeof json[0] === 'number') {
              setKeysText('(Solana CLI byte array detected)');
              setParsedKeys([{ raw: text, valid: true }]);
            } else {
              const keys = json.map((k: string) => k.toString());
              setKeysText(keys.join('\n'));
              parseKeys(keys.join('\n'));
            }
          } else if (json.secretKey || json.privateKey) {
            const key = json.secretKey ?? json.privateKey;
            setKeysText(key);
            parseKeys(key);
          }
        } catch {
          setKeysText(text);
          parseKeys(text);
        }
      };
      reader.readAsText(file);
    },
    [parseKeys],
  );

  const handleImport = useCallback(async () => {
    const validKeys = parsedKeys.filter((k) => k.valid).map((k) => k.raw);
    if (validKeys.length === 0) {
      toast.error('No valid keys to import');
      return;
    }

    setIsImporting(true);
    try {
      const wallets = await importWallets(validKeys);
      addWallets(wallets);
      toast.success(`${wallets.length} wallets imported`);
      onClose();
    } catch {
      toast.error('Failed to import wallets');
    } finally {
      setIsImporting(false);
    }
  }, [parsedKeys, addWallets, onClose]);

  const validCount = parsedKeys.filter((k) => k.valid).length;
  const invalidCount = parsedKeys.filter((k) => !k.valid).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-surface border border-border-subtle rounded-xl w-full max-w-lg mx-4 p-6 space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-display font-semibold text-text-primary">
            Import Wallets
          </h2>
          <button onClick={onClose} className="text-text-muted hover:text-text-primary">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Method tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setMethod('paste')}
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${
              method === 'paste'
                ? 'bg-brand-green/10 text-brand-green'
                : 'bg-bg text-text-muted hover:text-text-secondary'
            }`}
          >
            Paste Keys
          </button>
          <button
            onClick={() => setMethod('file')}
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${
              method === 'file'
                ? 'bg-brand-green/10 text-brand-green'
                : 'bg-bg text-text-muted hover:text-text-secondary'
            }`}
          >
            Upload JSON
          </button>
        </div>

        {method === 'paste' && (
          <div>
            <label className="text-xs text-text-muted block mb-1">
              Paste one private key per line (base58)
            </label>
            <textarea
              value={keysText}
              onChange={(e) => setKeysText(e.target.value)}
              rows={6}
              className="w-full bg-bg border border-border-subtle rounded-md px-3 py-2 text-xs font-mono text-text-primary focus:outline-none focus:border-brand-green resize-none"
              placeholder="5abc123..."
            />
            <button
              onClick={handleParse}
              className="mt-2 text-xs text-brand-green hover:text-brand-green/80 font-medium"
            >
              Validate Keys
            </button>
          </div>
        )}

        {method === 'file' && (
          <div className="border-2 border-dashed border-border-subtle rounded-lg p-8 text-center">
            <Upload className="w-8 h-8 text-text-muted mx-auto mb-3" />
            <p className="text-sm text-text-secondary mb-2">
              Drop a JSON file or click to browse
            </p>
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="block w-full text-sm text-text-muted file:mr-4 file:py-1 file:px-3 file:rounded file:border-0 file:text-sm file:bg-surface file:text-text-secondary hover:file:bg-brand-green/10 cursor-pointer"
            />
          </div>
        )}

        {parsedKeys.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-3 text-xs">
              {validCount > 0 && (
                <span className="flex items-center gap-1 text-brand-green">
                  <Check className="w-3 h-3" /> {validCount} valid
                </span>
              )}
              {invalidCount > 0 && (
                <span className="flex items-center gap-1 text-brand-red">
                  <AlertCircle className="w-3 h-3" /> {invalidCount} invalid
                </span>
              )}
            </div>
            <div className="max-h-32 overflow-y-auto space-y-1">
              {parsedKeys.slice(0, 10).map((k, i) => (
                <div
                  key={i}
                  className={`text-xs font-mono px-2 py-1 rounded ${
                    k.valid ? 'bg-brand-green/5 text-brand-green' : 'bg-brand-red/5 text-brand-red'
                  }`}
                >
                  {k.raw.slice(0, 8)}...{k.raw.slice(-8)}
                  {k.error && <span className="ml-2 text-[10px]">({k.error})</span>}
                </div>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={handleImport}
          disabled={validCount === 0 || isImporting}
          className="w-full py-2.5 bg-brand-green text-bg font-semibold text-sm rounded-lg hover:bg-brand-green/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isImporting ? 'Importing...' : `Import ${validCount} Wallets`}
        </button>
      </div>
    </div>
  );
}
