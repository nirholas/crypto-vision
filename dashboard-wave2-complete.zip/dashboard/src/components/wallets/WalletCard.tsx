'use client';

import { useEffect, useState } from 'react';
import { Copy, ExternalLink, Pause, Play, X } from 'lucide-react';
import QRCode from 'react-qr-code';
import { useWalletStore } from '@/stores/wallet.store';
import { getWalletHistory } from '@/lib/api';
import {
  formatLamportsAsSol,
  formatNumber,
  truncateAddress,
  relativeTime,
  formatRole,
  statusColor,
} from '@/lib/formatters';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

interface Props {
  address: string;
}

interface TxHistoryEntry {
  signature: string;
  timestamp: number;
  direction: 'in' | 'out';
  amountLamports: string;
  counterparty: string;
}

export function WalletCard({ address }: Props) {
  const wallet = useWalletStore((s) => s.getWalletByAddress(address));
  const setSelectedWallet = useWalletStore((s) => s.setSelectedWallet);
  const [history, setHistory] = useState<TxHistoryEntry[]>([]);

  useEffect(() => {
    getWalletHistory(address)
      .then((data) => setHistory(data.transactions))
      .catch(() => setHistory([]));
  }, [address]);

  if (!wallet) return null;

  const copyAddr = () => {
    navigator.clipboard.writeText(address);
    toast.success('Address copied');
  };

  return (
    <div className="bg-surface/50 border border-border-subtle rounded-lg p-5 space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-display font-semibold text-text-primary">
          {wallet.label}
        </h3>
        <button
          onClick={() => setSelectedWallet(null)}
          className="text-text-muted hover:text-text-primary"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* QR Code */}
      <div className="flex justify-center bg-white rounded-md p-3">
        <QRCode value={address} size={120} />
      </div>

      {/* Address */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-mono text-text-secondary flex-1 break-all">
          {address}
        </span>
        <button onClick={copyAddr} className="text-text-muted hover:text-text-primary flex-shrink-0">
          <Copy className="w-3.5 h-3.5" />
        </button>
        <a
          href={`https://solscan.io/account/${address}`}
          target="_blank"
          rel="noopener noreferrer"
          className="text-text-muted hover:text-brand-green flex-shrink-0"
        >
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>

      {/* Balance */}
      <div className="text-center">
        <div className="text-2xl font-mono font-bold text-brand-green">
          {formatLamportsAsSol(wallet.balanceLamports)}
        </div>
        <div className="text-xs text-text-muted mt-1">
          {formatNumber(Number(wallet.tokenBalance))} tokens
        </div>
      </div>

      {/* Role & Status */}
      <div className="flex items-center justify-center gap-3">
        <span className="text-xs px-2 py-0.5 rounded bg-bg text-text-secondary">
          {formatRole(wallet.role)}
        </span>
        <span className={cn('text-xs px-2 py-0.5 rounded-full', statusColor(wallet.status))}>
          {wallet.status}
        </span>
      </div>

      {/* Transaction History */}
      <div>
        <h4 className="text-xs text-text-muted font-medium mb-2">Recent Transactions</h4>
        <div className="space-y-1 max-h-40 overflow-y-auto">
          {history.length === 0 ? (
            <p className="text-xs text-text-muted text-center py-2">No transactions</p>
          ) : (
            history.slice(0, 10).map((tx) => (
              <div
                key={tx.signature}
                className="flex items-center gap-2 text-xs py-1"
              >
                <span
                  className={cn(
                    'w-4 text-center font-semibold',
                    tx.direction === 'in' ? 'text-brand-green' : 'text-brand-red',
                  )}
                >
                  {tx.direction === 'in' ? '↓' : '↑'}
                </span>
                <span className="text-text-primary font-mono">
                  {formatLamportsAsSol(tx.amountLamports, 3)}
                </span>
                <span className="text-text-muted ml-auto">
                  {relativeTime(tx.timestamp)}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
