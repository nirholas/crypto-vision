'use client';

import { useState, useMemo, useCallback } from 'react';
import { ExternalLink, Copy, MoreHorizontal, ChevronUp, ChevronDown } from 'lucide-react';
import { useWalletStore } from '@/stores/wallet.store';
import {
  truncateAddressLong,
  formatLamportsAsSol,
  formatNumber,
  formatRole,
  statusColor,
} from '@/lib/formatters';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import type { WalletInfo } from '@/types';

type SortField = 'index' | 'label' | 'role' | 'balance' | 'tokenBalance' | 'status';
type SortDir = 'asc' | 'desc';

export function WalletTable() {
  const wallets = useWalletStore((s) => s.wallets);
  const setSelectedWallet = useWalletStore((s) => s.setSelectedWallet);
  const selectedAddress = useWalletStore((s) => s.selectedWalletAddress);

  const [sortField, setSortField] = useState<SortField>('index');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const toggleSort = useCallback((field: SortField) => {
    setSortField((prev) => {
      if (prev === field) {
        setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
        return field;
      }
      setSortDir('asc');
      return field;
    });
  }, []);

  const sorted = useMemo(() => {
    const arr = [...wallets];
    const dir = sortDir === 'asc' ? 1 : -1;

    arr.sort((a, b) => {
      switch (sortField) {
        case 'label':
          return a.label.localeCompare(b.label) * dir;
        case 'role':
          return a.role.localeCompare(b.role) * dir;
        case 'balance':
          return (Number(a.balanceLamports) - Number(b.balanceLamports)) * dir;
        case 'tokenBalance':
          return (Number(a.tokenBalance) - Number(b.tokenBalance)) * dir;
        case 'status':
          return a.status.localeCompare(b.status) * dir;
        default:
          return 0;
      }
    });

    return arr;
  }, [wallets, sortField, sortDir]);

  const toggleSelection = useCallback((address: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(address)) {
        next.delete(address);
      } else {
        next.add(address);
      }
      return next;
    });
  }, []);

  const toggleAll = useCallback(() => {
    setSelected((prev) => {
      if (prev.size === wallets.length) return new Set();
      return new Set(wallets.map((w) => w.address));
    });
  }, [wallets]);

  const copyAddress = useCallback((address: string) => {
    navigator.clipboard.writeText(address);
    toast.success('Address copied');
  }, []);

  const isLowBalance = (w: WalletInfo) => {
    const bal = Number(w.balanceLamports);
    return w.status === 'active' && bal < 50_000_000;
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null;
    return sortDir === 'asc' ? (
      <ChevronUp className="w-3 h-3 inline ml-0.5" />
    ) : (
      <ChevronDown className="w-3 h-3 inline ml-0.5" />
    );
  };

  if (wallets.length === 0) {
    return (
      <div className="bg-surface/50 border border-border-subtle rounded-lg p-12 text-center">
        <p className="text-text-muted text-sm">
          No wallets yet. Create or import wallets to get started.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-surface/50 border border-border-subtle rounded-lg overflow-hidden">
      {selected.size > 0 && (
        <div className="flex items-center gap-3 px-4 py-2 bg-brand-green/5 border-b border-border-subtle">
          <span className="text-xs text-brand-green font-medium">
            {selected.size} selected
          </span>
          <button className="text-xs text-text-secondary hover:text-text-primary">
            Fund Selected
          </button>
          <button className="text-xs text-text-secondary hover:text-text-primary">
            Pause Selected
          </button>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border-subtle">
              <th className="px-3 py-2 text-left w-8">
                <input
                  type="checkbox"
                  checked={selected.size === wallets.length && wallets.length > 0}
                  onChange={toggleAll}
                  className="rounded border-border-subtle"
                />
              </th>
              <th
                className="px-3 py-2 text-left text-xs text-text-muted font-medium cursor-pointer select-none"
                onClick={() => toggleSort('index')}
              >
                # <SortIcon field="index" />
              </th>
              <th
                className="px-3 py-2 text-left text-xs text-text-muted font-medium cursor-pointer select-none"
                onClick={() => toggleSort('label')}
              >
                Label <SortIcon field="label" />
              </th>
              <th className="px-3 py-2 text-left text-xs text-text-muted font-medium">
                Address
              </th>
              <th
                className="px-3 py-2 text-left text-xs text-text-muted font-medium cursor-pointer select-none"
                onClick={() => toggleSort('role')}
              >
                Role <SortIcon field="role" />
              </th>
              <th
                className="px-3 py-2 text-right text-xs text-text-muted font-medium cursor-pointer select-none"
                onClick={() => toggleSort('balance')}
              >
                SOL <SortIcon field="balance" />
              </th>
              <th
                className="px-3 py-2 text-right text-xs text-text-muted font-medium cursor-pointer select-none"
                onClick={() => toggleSort('tokenBalance')}
              >
                Tokens <SortIcon field="tokenBalance" />
              </th>
              <th
                className="px-3 py-2 text-center text-xs text-text-muted font-medium cursor-pointer select-none"
                onClick={() => toggleSort('status')}
              >
                Status <SortIcon field="status" />
              </th>
              <th className="px-3 py-2 w-8" />
            </tr>
          </thead>
          <tbody>
            {sorted.map((wallet, idx) => (
              <tr
                key={wallet.address}
                onClick={() => setSelectedWallet(wallet.address)}
                className={cn(
                  'border-b border-border-subtle/50 cursor-pointer transition-colors',
                  selectedAddress === wallet.address
                    ? 'bg-brand-green/5'
                    : 'hover:bg-surface/80',
                  isLowBalance(wallet) && 'bg-brand-red/5',
                )}
              >
                <td className="px-3 py-2">
                  <input
                    type="checkbox"
                    checked={selected.has(wallet.address)}
                    onChange={() => toggleSelection(wallet.address)}
                    onClick={(e) => e.stopPropagation()}
                    className="rounded border-border-subtle"
                  />
                </td>
                <td className="px-3 py-2 text-xs text-text-muted font-mono">
                  {idx + 1}
                </td>
                <td className="px-3 py-2 text-xs text-text-primary font-medium">
                  {wallet.label}
                </td>
                <td className="px-3 py-2">
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-mono text-text-secondary">
                      {truncateAddressLong(wallet.address)}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        copyAddress(wallet.address);
                      }}
                      className="text-text-muted hover:text-text-primary"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                    <a
                      href={`https://solscan.io/account/${wallet.address}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="text-text-muted hover:text-brand-green"
                    >
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </td>
                <td className="px-3 py-2">
                  <span className="text-xs px-2 py-0.5 rounded bg-surface text-text-secondary">
                    {formatRole(wallet.role)}
                  </span>
                </td>
                <td className="px-3 py-2 text-right">
                  <span
                    className={cn(
                      'text-xs font-mono',
                      Number(wallet.balanceLamports) > 100_000_000
                        ? 'text-brand-green'
                        : Number(wallet.balanceLamports) > 50_000_000
                          ? 'text-warning'
                          : 'text-brand-red',
                    )}
                  >
                    {formatLamportsAsSol(wallet.balanceLamports)}
                  </span>
                  {isLowBalance(wallet) && (
                    <span className="ml-1 text-[10px] text-brand-red font-bold animate-pulse">
                      ⚠ Low
                    </span>
                  )}
                </td>
                <td className="px-3 py-2 text-right text-xs font-mono text-text-secondary">
                  {formatNumber(Number(wallet.tokenBalance))}
                </td>
                <td className="px-3 py-2 text-center">
                  <span
                    className={cn(
                      'text-xs px-2 py-0.5 rounded-full font-medium',
                      statusColor(wallet.status),
                    )}
                  >
                    {wallet.status}
                  </span>
                </td>
                <td className="px-3 py-2">
                  <button
                    onClick={(e) => e.stopPropagation()}
                    className="text-text-muted hover:text-text-primary"
                  >
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
