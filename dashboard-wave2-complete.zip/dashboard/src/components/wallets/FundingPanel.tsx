'use client';

import { useState, useMemo, useCallback } from 'react';
import { X, Shuffle } from 'lucide-react';
import { useWalletStore } from '@/stores/wallet.store';
import { splitFunding } from '@/lib/api';
import { formatLamportsAsSol, solToLamports, lamportsToSol } from '@/lib/formatters';
import toast from 'react-hot-toast';
import type { FundingTarget } from '@/types';

interface Props {
  onClose: () => void;
}

type FundingMode = 'equal' | 'random';

export function FundingPanel({ onClose }: Props) {
  const wallets = useWalletStore((s) => s.wallets);
  const connectedAddress = useWalletStore((s) => s.connectedWalletAddress);
  const connectedBalance = useWalletStore((s) => s.connectedWalletBalanceLamports);

  const [totalSol, setTotalSol] = useState('1.0');
  const [mode, setMode] = useState<FundingMode>('equal');
  const [randomIntensity, setRandomIntensity] = useState(3);
  const [feesReserved, setFeesReserved] = useState('0.05');
  const [selectedAddresses, setSelectedAddresses] = useState<Set<string>>(
    () => new Set(wallets.filter((w) => w.role !== 'creator').map((w) => w.address)),
  );
  const [isFunding, setIsFunding] = useState(false);
  const [randomSeed, setRandomSeed] = useState(0);

  const targetWallets = wallets.filter((w) => selectedAddresses.has(w.address));

  const splits = useMemo(() => {
    const total = parseFloat(totalSol) || 0;
    const fees = parseFloat(feesReserved) || 0;
    const distributable = Math.max(0, total - fees);
    const count = targetWallets.length;
    if (count === 0) return [];

    if (mode === 'equal') {
      const each = distributable / count;
      return targetWallets.map((w) => ({
        address: w.address,
        label: w.label,
        sol: each,
      }));
    }

    // Random mode
    const variancePercent = randomIntensity * 10; // 10%-50%
    const base = distributable / count;
    const raw = targetWallets.map((w) => {
      const variance = 1 + ((Math.random() - 0.5) * 2 * variancePercent) / 100;
      return { address: w.address, label: w.label, sol: base * variance };
    });

    // Normalize to sum to distributable
    const sum = raw.reduce((s, r) => s + r.sol, 0);
    const factor = sum > 0 ? distributable / sum : 0;
    return raw.map((r) => ({ ...r, sol: r.sol * factor }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [totalSol, feesReserved, targetWallets.length, mode, randomIntensity, randomSeed]);

  const totalDistributed = splits.reduce((s, r) => s + r.sol, 0);

  const handleFund = useCallback(async () => {
    if (!connectedAddress) {
      toast.error('No wallet connected');
      return;
    }

    const targets: FundingTarget[] = splits.map((s) => ({
      address: s.address,
      lamports: solToLamports(s.sol),
    }));

    setIsFunding(true);
    try {
      const sigs = await splitFunding(
        connectedAddress,
        solToLamports(totalDistributed),
        targets,
      );
      toast.success(`Funded ${sigs.length} wallets`);
      onClose();
    } catch {
      toast.error('Funding failed');
    } finally {
      setIsFunding(false);
    }
  }, [connectedAddress, splits, totalDistributed, onClose]);

  const toggleAddress = (address: string) => {
    setSelectedAddresses((prev) => {
      const next = new Set(prev);
      if (next.has(address)) next.delete(address);
      else next.add(address);
      return next;
    });
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-[420px] bg-surface border-l border-border-subtle shadow-2xl overflow-y-auto">
      <div className="p-6 space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-display font-semibold text-text-primary">
            Fund Wallets
          </h2>
          <button onClick={onClose} className="text-text-muted hover:text-text-primary">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Source */}
        <div>
          <label className="text-xs text-text-muted block mb-1">Source Wallet</label>
          <div className="bg-bg border border-border-subtle rounded-md px-3 py-2 text-xs font-mono text-text-secondary">
            {connectedAddress?.slice(0, 8)}...{connectedAddress?.slice(-8)}
            <span className="ml-2 text-brand-green">
              ({formatLamportsAsSol(connectedBalance, 2)})
            </span>
          </div>
        </div>

        {/* Total */}
        <div>
          <label className="text-xs text-text-muted block mb-1">Total SOL to distribute</label>
          <input
            type="number"
            step="0.1"
            value={totalSol}
            onChange={(e) => setTotalSol(e.target.value)}
            className="w-full bg-bg border border-border-subtle rounded-md px-3 py-2 text-sm text-text-primary font-mono focus:outline-none focus:border-brand-green"
          />
        </div>

        {/* Reserve fees */}
        <div>
          <label className="text-xs text-text-muted block mb-1">Reserve for fees (SOL)</label>
          <input
            type="number"
            step="0.01"
            value={feesReserved}
            onChange={(e) => setFeesReserved(e.target.value)}
            className="w-full bg-bg border border-border-subtle rounded-md px-3 py-2 text-sm text-text-primary font-mono focus:outline-none focus:border-brand-green"
          />
        </div>

        {/* Mode */}
        <div className="flex gap-2">
          <button
            onClick={() => setMode('equal')}
            className={`flex-1 py-2 text-xs font-medium rounded-md transition-colors ${
              mode === 'equal' ? 'bg-brand-green/10 text-brand-green' : 'bg-bg text-text-muted'
            }`}
          >
            Equal Split
          </button>
          <button
            onClick={() => setMode('random')}
            className={`flex-1 py-2 text-xs font-medium rounded-md transition-colors ${
              mode === 'random' ? 'bg-brand-green/10 text-brand-green' : 'bg-bg text-text-muted'
            }`}
          >
            Random Split
          </button>
        </div>

        {mode === 'random' && (
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs text-text-muted">Randomization: {randomIntensity}/5</label>
              <button
                onClick={() => setRandomSeed((s) => s + 1)}
                className="flex items-center gap-1 text-xs text-brand-green"
              >
                <Shuffle className="w-3 h-3" /> Shuffle
              </button>
            </div>
            <input
              type="range"
              min={1}
              max={5}
              value={randomIntensity}
              onChange={(e) => setRandomIntensity(Number(e.target.value))}
              className="w-full accent-brand-green"
            />
          </div>
        )}

        {/* Target selection */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs text-text-muted">
              Target wallets ({selectedAddresses.size})
            </label>
            <button
              onClick={() =>
                setSelectedAddresses(new Set(wallets.map((w) => w.address)))
              }
              className="text-[10px] text-brand-green"
            >
              Select All
            </button>
          </div>
          <div className="max-h-32 overflow-y-auto space-y-1 bg-bg rounded-md p-2">
            {wallets.map((w) => (
              <label
                key={w.address}
                className="flex items-center gap-2 text-xs cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={selectedAddresses.has(w.address)}
                  onChange={() => toggleAddress(w.address)}
                  className="rounded border-border-subtle accent-brand-green"
                />
                <span className="text-text-secondary">{w.label}</span>
                <span className="text-text-muted font-mono ml-auto">
                  {formatLamportsAsSol(w.balanceLamports, 2)}
                </span>
              </label>
            ))}
          </div>
        </div>

        {/* Preview */}
        {splits.length > 0 && (
          <div className="bg-bg rounded-md p-3 max-h-40 overflow-y-auto space-y-1">
            {splits.map((s) => (
              <div key={s.address} className="flex items-center justify-between text-xs">
                <span className="text-text-secondary">{s.label}</span>
                <span className="text-text-primary font-mono">{s.sol.toFixed(4)} SOL</span>
              </div>
            ))}
            <div className="border-t border-border-subtle pt-1 mt-2 flex items-center justify-between text-xs font-semibold">
              <span className="text-text-secondary">Total</span>
              <span className="text-brand-green font-mono">{totalDistributed.toFixed(4)} SOL</span>
            </div>
          </div>
        )}

        {/* Execute */}
        <button
          onClick={handleFund}
          disabled={isFunding || splits.length === 0}
          className="w-full py-3 bg-brand-green text-bg font-semibold text-sm rounded-lg hover:bg-brand-green/90 transition-colors disabled:opacity-50"
        >
          {isFunding ? 'Funding...' : `Execute Funding (${totalDistributed.toFixed(4)} SOL)`}
        </button>
      </div>
    </div>
  );
}
