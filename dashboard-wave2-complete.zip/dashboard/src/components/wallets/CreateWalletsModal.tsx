'use client';

import { useState, useCallback } from 'react';
import { X, Download, AlertTriangle } from 'lucide-react';
import { createWallets, exportWallets } from '@/lib/api';
import { useWalletStore } from '@/stores/wallet.store';
import toast from 'react-hot-toast';

interface Props {
  onClose: () => void;
}

export function CreateWalletsModal({ onClose }: Props) {
  const [step, setStep] = useState(1);
  const [count, setCount] = useState(5);
  const [prefix, setPrefix] = useState('bot');
  const [randomNames, setRandomNames] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [created, setCreated] = useState(false);

  const addWallets = useWalletStore((s) => s.addWallets);

  const handleCreate = useCallback(async () => {
    setIsCreating(true);
    try {
      const wallets = await createWallets(count, { prefix, randomNames });
      addWallets(wallets);
      setCreated(true);
      setStep(3);
      toast.success(`${wallets.length} wallets created`);
    } catch (err) {
      toast.error('Failed to create wallets');
    } finally {
      setIsCreating(false);
    }
  }, [count, prefix, randomNames, addWallets]);

  const handleBackup = useCallback(async () => {
    try {
      const blob = await exportWallets('json');
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'wallet-backup.json';
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Backup downloaded');
    } catch {
      toast.error('Failed to export backup');
    }
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-surface border border-border-subtle rounded-xl w-full max-w-lg mx-4 p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-display font-semibold text-text-primary">
            Create Wallets — Step {step}/3
          </h2>
          <button onClick={onClose} className="text-text-muted hover:text-text-primary">
            <X className="w-5 h-5" />
          </button>
        </div>

        {step === 1 && (
          <div className="space-y-4">
            <div>
              <label className="text-sm text-text-secondary block mb-2">
                How many wallets?
              </label>
              <input
                type="range"
                min={1}
                max={100}
                value={count}
                onChange={(e) => setCount(Number(e.target.value))}
                className="w-full accent-brand-green"
              />
              <div className="flex justify-between text-xs text-text-muted mt-1">
                <span>1</span>
                <span className="text-brand-green font-mono font-bold text-lg">
                  {count}
                </span>
                <span>100</span>
              </div>
            </div>
            <p className="text-xs text-text-muted">
              1 creator + {Math.max(0, count - 1)} trader wallets
            </p>
            <button
              onClick={() => setStep(2)}
              className="w-full py-2.5 bg-brand-green/20 text-brand-green font-semibold text-sm rounded-lg hover:bg-brand-green/30 transition-colors"
            >
              Next
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div>
              <label className="text-sm text-text-secondary block mb-2">
                Naming scheme
              </label>
              <div className="flex items-center gap-3 mb-3">
                <label className="flex items-center gap-2 text-sm text-text-secondary">
                  <input
                    type="checkbox"
                    checked={randomNames}
                    onChange={() => setRandomNames(!randomNames)}
                    className="rounded border-border-subtle accent-brand-green"
                  />
                  Randomize names
                </label>
              </div>
              {!randomNames && (
                <div>
                  <label className="text-xs text-text-muted block mb-1">
                    Custom prefix
                  </label>
                  <input
                    type="text"
                    value={prefix}
                    onChange={(e) => setPrefix(e.target.value)}
                    placeholder="bot"
                    className="w-full bg-bg border border-border-subtle rounded-md px-3 py-2 text-sm text-text-primary focus:outline-none focus:border-brand-green"
                  />
                  <p className="text-xs text-text-muted mt-1">
                    Preview: {prefix}-01, {prefix}-02, ... {prefix}-{String(count).padStart(2, '0')}
                  </p>
                </div>
              )}
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                className="flex-1 py-2.5 bg-surface border border-border-subtle text-text-secondary text-sm rounded-lg hover:text-text-primary transition-colors"
              >
                Back
              </button>
              <button
                onClick={handleCreate}
                disabled={isCreating}
                className="flex-1 py-2.5 bg-brand-green text-bg font-semibold text-sm rounded-lg hover:bg-brand-green/90 transition-colors disabled:opacity-50"
              >
                {isCreating ? 'Generating...' : `Generate ${count} Wallets`}
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <div className="bg-warning/10 border border-warning/20 rounded-lg p-4 flex gap-3">
              <AlertTriangle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
              <div className="text-sm text-warning">
                Back up your wallet vault file immediately. If you lose your private keys
                you cannot recover funds.
              </div>
            </div>
            <button
              onClick={handleBackup}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-brand-green/20 text-brand-green font-semibold text-sm rounded-lg hover:bg-brand-green/30 transition-colors"
            >
              <Download className="w-4 h-4" />
              Download Wallet Backup
            </button>
            <button
              onClick={onClose}
              className="w-full py-2.5 bg-surface border border-border-subtle text-text-secondary text-sm rounded-lg hover:text-text-primary transition-colors"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
