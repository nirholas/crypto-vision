// ─── Lamport string: all financial amounts in transit ────────

/** Lamport amounts are transmitted as strings to avoid float precision issues */
export type LamportString = string;

// ─── Swarm Phase ─────────────────────────────────────────────

export type SwarmPhase =
  | 'idle'
  | 'scouting'
  | 'creating'
  | 'bundling'
  | 'trading'
  | 'exiting'
  | 'paused'
  | 'done';

// ─── Agent Types ─────────────────────────────────────────────

export type AgentType =
  | 'creator'
  | 'trader'
  | 'market-maker'
  | 'volume'
  | 'accumulator'
  | 'exit'
  | 'sentinel'
  | 'scanner'
  | 'narrative'
  | 'sniper'
  | 'stability';

export type AgentStatus = 'active' | 'paused' | 'idle' | 'error' | 'stopped';

export type AgentRole =
  | 'creator'
  | 'trader'
  | 'market-maker'
  | 'volume'
  | 'accumulator'
  | 'sniper'
  | 'exit-only'
  | 'unassigned';

// ─── Wallet ──────────────────────────────────────────────────

export interface WalletInfo {
  address: string;
  label: string;
  role: AgentRole;
  balanceLamports: LamportString;
  tokenBalance: string;
  status: AgentStatus;
  assignedAgentId: string | null;
  createdAt: number;
}

// ─── Trader Personality ──────────────────────────────────────

export interface TraderPersonality {
  aggression: number;
  timingVariance: number;
  sizeVariance: number;
  trendFollowing: number;
  maxPositionPercent: number;
  naturalSizing: boolean;
}

// ─── Trading Strategy ────────────────────────────────────────

export interface TradingStrategy {
  id: string;
  name: string;
  minIntervalSeconds: number;
  maxIntervalSeconds: number;
  minTradeSizeLamports: LamportString;
  maxTradeSizeLamports: LamportString;
  buySellRatio: number;
  maxMarketCapSol?: number;
  minMarketCapSol?: number;
  maxTotalBudgetLamports: LamportString;
  useJitoBundles: boolean;
  priorityFeeMicroLamports: number;
  maxTrades?: number;
  maxDurationSeconds?: number;
}

// ─── Volume Config ───────────────────────────────────────────

export type VolumePattern = 'balanced' | 'cascade' | 'burst' | 'natural';

export interface VolumeConfig {
  targetVolumeSolPerHour: number;
  minTradeSize: LamportString;
  maxTradeSize: LamportString;
  minIntervalMs: number;
  maxIntervalMs: number;
  walletRotationEnabled: boolean;
  maxTradesPerWallet: number;
  balancedMode: boolean;
  naturalPatterns: boolean;
  volumePattern: VolumePattern;
  peakHoursUtc: number[];
}

// ─── Market Making Config ────────────────────────────────────

export interface MarketMakingConfig {
  spreadPercent: number;
  inventoryTarget: number;
  maxInventoryDeviation: number;
  cycleDurationMs: number;
  maxLossPerCycleSol: number;
  maxDrawdownPercent: number;
  volatilityAdjustedSpread: boolean;
}

// ─── Exit Config ─────────────────────────────────────────────

export type ExitStrategy = 'gradual' | 'staged' | 'immediate' | 'trailing-stop';

export interface ExitStage {
  priceMultiplier: number;
  sellPercent: number;
}

export interface ExitConfig {
  strategy: ExitStrategy;
  exitDurationMs: number;
  stages: ExitStage[];
  maxPriceImpactPercent: number;
  retainPercent: number;
  priorityFeeMicroLamports: number;
  slippageBps: number;
  takeProfitMultiplier?: number;
  stopLossPercent?: number;
  timeLimitSeconds?: number;
  exitOnGraduation: boolean;
  exitOnVolumeDrop?: number;
  trailingStopPercent?: number;
  trailingStopActivation?: number;
}

// ─── Token Config ────────────────────────────────────────────

export interface TokenConfig {
  name: string;
  symbol: string;
  description: string;
  imageUri: string;
  metadataUri?: string;
  vanityPrefix?: string;
  mayhemMode: boolean;
  cashback: boolean;
}

// ─── Bundle Config ───────────────────────────────────────────

export type DistributionMode = 'even' | 'weighted' | 'random' | 'stagger';

export interface BundleWalletConfig {
  walletAddress: string;
  amountLamports: LamportString;
  delayMs: number;
  useJito: boolean;
}

export interface BundleBuyConfig {
  devBuyLamports: LamportString;
  bundleWallets: BundleWalletConfig[];
  slippageBps: number;
  distributionMode: DistributionMode;
}

// ─── Giant Burst ─────────────────────────────────────────────

export type BurstTriggerType = 'at-launch' | 'mc-target' | 'time-delay' | 'manual';

export interface BurstEvent {
  id: string;
  triggerType: BurstTriggerType;
  triggerValue: number;
  walletAddresses: string[];
  amountPerWalletLamports: LamportString;
  simultaneous: boolean;
}

// ─── Launch Mode ─────────────────────────────────────────────

export interface LaunchMode {
  createToken: boolean;
  devBuy: boolean;
  devBuyAmountLamports: LamportString;
  bundleBuy: boolean;
  volumeGeneration: boolean;
  volumeStartCondition: 'immediately' | 'after-dev-buy' | 'after-bundle' | 'after-delay';
  volumeStartDelaySeconds: number;
  volumeDurationSeconds: number;
  marketMaking: boolean;
  marketMakingStartCondition: 'immediately' | 'after-dev-buy' | 'after-bundle' | 'after-delay';
  organicAccumulation: boolean;
  accumulationTargetPercent: number;
  graduationPush: boolean;
  graduationPushThreshold: number;
  snipeLaunch: boolean;
  giantBurstEvents: BurstEvent[];
  autoExit: boolean;
  consolidateProfits: boolean;
}

// ─── Swarm Config (full) ────────────────────────────────────

export interface SwarmConfig {
  rpcUrl: string;
  wsUrl?: string;
  traderCount: number;
  token: TokenConfig;
  bundle: BundleBuyConfig;
  strategy: TradingStrategy;
  volume?: VolumeConfig;
  marketMaking?: MarketMakingConfig;
  exit?: ExitConfig;
  launchMode: LaunchMode;
  agentPersonalities: Record<string, TraderPersonality>;
}

// ─── Swarm Status (from GET /api/status) ─────────────────────

export interface SwarmStatus {
  phase: SwarmPhase;
  uptime: number;
  tokenMint: string | null;
  totalAgents: number;
  activeAgents: number;
  totalTrades: number;
  totalVolumeSol: number;
  currentPnl: number;
  startedAt: number | null;
}

// ─── Agent (from GET /api/agents) ────────────────────────────

export interface Agent {
  id: string;
  type: AgentType;
  status: AgentStatus;
  walletAddress: string;
  solBalance: number;
  tokenBalance: number;
  pnl: number;
  tradeCount: number;
  lastAction: string | null;
  uptime: number;
}

export interface AgentHistoryEntry {
  timestamp: number;
  action: string;
  details: string;
  success: boolean;
}

export interface AgentPerformanceMetrics {
  totalTrades: number;
  winRate: number;
  avgTradeSize: number;
  totalVolume: number;
  profitFactor: number;
  maxDrawdown: number;
  sharpeRatio: number;
}

export interface AgentDetail extends Agent {
  personality: TraderPersonality;
  role: AgentRole;
  budgetLamports: LamportString;
  history: AgentHistoryEntry[];
  performance: AgentPerformanceMetrics;
}

// ─── Trade ───────────────────────────────────────────────────

export interface TradeEntry {
  id: string;
  timestamp: number;
  agentId: string;
  direction: 'buy' | 'sell';
  solAmount: number;
  tokenAmount: number;
  price: number;
  signature: string;
  success: boolean;
  slippage?: number;
}

export interface TradeResult {
  success: boolean;
  signature: string;
  solAmount: number;
  tokenAmount: number;
  price: number;
  error?: string;
}

// ─── P&L ─────────────────────────────────────────────────────

export interface PnLDataPoint {
  timestamp: number;
  pnlSol: number;
  pnlUsd: number;
  cumulativeVolume: number;
}

export interface PnLSnapshot {
  totalPnlSol: number;
  totalPnlUsd: number;
  unrealizedPnlSol: number;
  realizedPnlSol: number;
  totalCostSol: number;
  totalRevenueSol: number;
  tokenValue: number;
  timestamp: number;
}

export interface PnLData {
  timeSeries: PnLDataPoint[];
  current: PnLSnapshot;
}

// ─── Analytics ───────────────────────────────────────────────

export interface Analytics {
  totalTrades: number;
  totalVolumeSol: number;
  buyCount: number;
  sellCount: number;
  avgTradeSize: number;
  avgInterval: number;
  topAgentByVolume: string;
  topAgentByPnl: string;
  bondingCurveProgress: number;
  currentMarketCapSol: number;
  currentTokenPrice: number;
  estimatedUsdPrice: number;
  walletDistribution: Record<string, number>;
}

// ─── Health ──────────────────────────────────────────────────

export interface HealthReport {
  status: 'healthy' | 'degraded' | 'unhealthy';
  uptime: number;
  agents: Array<{
    id: string;
    type: string;
    status: string;
    lastHeartbeat: number;
    errorCount: number;
  }>;
  metrics: {
    cpuUsage?: number;
    memoryUsage?: number;
    rpcLatency: number;
    eventBusBacklog: number;
  };
  checks: Array<{
    name: string;
    status: 'pass' | 'warn' | 'fail';
    message: string;
  }>;
  timestamp: number;
}

// ─── Template ────────────────────────────────────────────────

export interface Template {
  id: string;
  name: string;
  description: string;
  createdAt: number;
  updatedAt: number;
  config: Partial<SwarmConfig>;
}

// ─── WebSocket Events ────────────────────────────────────────

export type DashboardEventType =
  | 'trade:executed'
  | 'agent:status'
  | 'pnl:updated'
  | 'phase:changed'
  | 'health:report'
  | 'signal:generated'
  | 'alert:created'
  | 'config:changed'
  | 'swarm:status';

export interface DashboardEvent {
  type: DashboardEventType;
  timestamp: string;
  data: Record<string, unknown>;
  agentId?: string;
}

export interface TradeExecutedData {
  agentId: string;
  agentLabel: string;
  direction: 'buy' | 'sell';
  solAmount: number;
  tokenAmount: number;
  price: number;
  signature: string;
}

export interface PhaseChangedData {
  previousPhase: SwarmPhase;
  newPhase: SwarmPhase;
  reason: string;
}

export interface PnLUpdatedData {
  totalPnlSol: number;
  unrealizedPnlSol: number;
  realizedPnlSol: number;
}

export interface AgentStatusData {
  agentId: string;
  type: AgentType;
  status: AgentStatus;
  walletAddress: string;
  solBalance: number;
  tokenBalance: number;
}

export interface AlertData {
  id: string;
  severity: 'info' | 'warning' | 'critical';
  message: string;
  agentId?: string;
}

// ─── API Response Envelope ───────────────────────────────────

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  timestamp: number;
  error?: string;
}

// ─── Funding ─────────────────────────────────────────────────

export interface FundingTarget {
  address: string;
  lamports: LamportString;
}

export interface SplitFundingRequest {
  sourceAddress: string;
  totalLamports: LamportString;
  targets: FundingTarget[];
}

// ─── Wallet History ──────────────────────────────────────────

export interface WalletTransaction {
  signature: string;
  timestamp: number;
  direction: 'in' | 'out';
  amountLamports: LamportString;
  counterparty: string;
}

// ─── Session ─────────────────────────────────────────────────

export interface Session {
  id: string;
  walletAddress: string;
  createdAt: number;
  lastActiveAt: number;
}

// ─── Preset Strategies ──────────────────────────────────────

export type PresetStrategyName = 'organic' | 'volume' | 'graduation' | 'custom';

export interface PresetStrategy {
  name: PresetStrategyName;
  label: string;
  description: string;
  strategy: TradingStrategy;
}

// ─── Cost Estimate ───────────────────────────────────────────

export interface CostEstimate {
  devBuySol: number;
  bundleBuysSol: number;
  volumeBudgetSol: number;
  transactionFeesSol: number;
  jitoTipsSol: number;
  totalSol: number;
  totalUsd: number;
  expectedSupplyPercent: number;
  breakEvenMultiplier: number;
}

// ─── Supply Distribution ─────────────────────────────────────

export interface SupplyHolder {
  address: string;
  label: string;
  balance: number;
  percentage: number;
}

export interface SupplyDistribution {
  totalSupply: number;
  holders: SupplyHolder[];
  bondingCurveHeld: number;
  updatedAt: number;
}

// ─── Event Timeline ──────────────────────────────────────────

export type EventCategory = 'trade' | 'agent' | 'phase' | 'system' | 'alert';
export type EventSeverity = 'info' | 'warning' | 'critical';

export interface TimelineEvent {
  id: string;
  timestamp: number;
  category: EventCategory;
  severity: EventSeverity;
  message: string;
  agentId?: string;
  data?: Record<string, unknown>;
}

// ─── Wave 2: Manual Trade Options ────────────────────────────

export interface ManualTradeOptions {
  slippageBps?: number;
  priorityFeeMicroLamports?: number;
  useJito?: boolean;
}

// ─── Wave 2: Multi-Wallet Trade ──────────────────────────────

export interface MultiTradeRequest {
  wallets: string[];
  direction: 'buy' | 'sell';
  amounts: LamportString[];
  useJito: boolean;
  staggerMs?: number;
}

export interface MultiTradeResult {
  results: Array<{
    walletAddress: string;
    success: boolean;
    signature?: string;
    error?: string;
  }>;
}

// ─── Wave 2: OHLCV ──────────────────────────────────────────

export interface OHLCVCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  trades: number;
}

// ─── Wave 2: Chart Marker ────────────────────────────────────

export interface ChartTradeMarker {
  time: number;
  direction: 'buy' | 'sell';
  agentLabel: string;
  amountSol: number;
  price: number;
  signature: string;
  source: 'agent' | 'tracked';
}

// ─── Wave 2: Tracked Wallet ─────────────────────────────────

export interface TrackedWallet {
  id: string;
  address: string;
  label: string;
  color: string;
  source: 'gmgn' | 'manual';
  addedAt: number;
  lastTrade?: {
    direction: 'buy' | 'sell';
    amountSol: number;
    timestamp: number;
  };
}

export interface GmgnWallet {
  address: string;
  score: number;
  lastDirection: 'buy' | 'sell';
  lastAmountSol: number;
  lastTimestamp: number;
}

// ─── Wave 2: Price Alert ─────────────────────────────────────

export type PriceAlertType = 'above' | 'below' | 'change';

export interface PriceAlert {
  id: string;
  alertType: PriceAlertType;
  value: number;
  triggered: boolean;
  triggeredAt?: number;
  createdAt: number;
}

// ─── Wave 2: Analytics Extended ──────────────────────────────

export interface PnLTimeSeriesPoint {
  timestamp: number;
  realizedSol: number;
  unrealizedSol: number;
  totalSol: number;
}

export interface AgentPnLRow {
  agentId: string;
  role: string;
  solSpent: number;
  solReceived: number;
  realizedPnl: number;
  unrealizedPnl: number;
  totalPnl: number;
  winRate: number;
  tradeCount: number;
}

export interface VolumeHourly {
  hour: string;
  buyVolume: number;
  sellVolume: number;
  totalVolume: number;
  tradeCount: number;
}

export interface AgentVolumeShare {
  agentId: string;
  label: string;
  volume: number;
  percent: number;
}

export interface CostBreakdown {
  gasFeesSol: number;
  jitoTipsSol: number;
  totalExposureSol: number;
  projectedGas1hr: number;
  projectedJito1hr: number;
  projectedCapital1hr: number;
}

export interface WalletHolding {
  address: string;
  label: string;
  solBalance: number;
  tokensHeld: number;
  supplyPercent: number;
  currentValueSol: number;
  entryCostSol: number;
  unrealizedPnl: number;
}

// ─── Wave 2: Phase Event ─────────────────────────────────────

export interface PhaseEvent {
  phase: string;
  startedAt: number;
  endedAt?: number;
  eventCount: number;
}

// ─── Wave 2: Burst Event Runtime ─────────────────────────────

export interface BurstEventRuntime {
  id: string;
  triggerType: string;
  triggerValue: number;
  walletAddresses: string[];
  amountPerWalletLamports: LamportString;
  simultaneous: boolean;
  executedAt: number | null;
  createdAt: number;
}
